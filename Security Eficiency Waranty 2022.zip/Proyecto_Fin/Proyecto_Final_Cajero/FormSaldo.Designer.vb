﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormSaldo
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LabelTítulo = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnConsultas = New System.Windows.Forms.Button()
        Me.LabelSaldo = New System.Windows.Forms.Label()
        Me.LabelMoneda = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'LabelTítulo
        '
        Me.LabelTítulo.AutoSize = True
        Me.LabelTítulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelTítulo.ForeColor = System.Drawing.Color.Gray
        Me.LabelTítulo.Location = New System.Drawing.Point(245, 9)
        Me.LabelTítulo.Name = "LabelTítulo"
        Me.LabelTítulo.Size = New System.Drawing.Size(366, 55)
        Me.LabelTítulo.TabIndex = 6
        Me.LabelTítulo.Text = "Consultar Saldo"
        Me.LabelTítulo.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.LightGray
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel3.Location = New System.Drawing.Point(0, 460)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(930, 100)
        Me.Panel3.TabIndex = 7
        '
        'btnConsultas
        '
        Me.btnConsultas.BackColor = System.Drawing.Color.DarkSlateGray
        Me.btnConsultas.FlatAppearance.BorderSize = 0
        Me.btnConsultas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnConsultas.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConsultas.ForeColor = System.Drawing.Color.LightGray
        Me.btnConsultas.Location = New System.Drawing.Point(308, 280)
        Me.btnConsultas.Name = "btnConsultas"
        Me.btnConsultas.Size = New System.Drawing.Size(145, 54)
        Me.btnConsultas.TabIndex = 33
        Me.btnConsultas.Text = "Consultas"
        Me.btnConsultas.UseVisualStyleBackColor = False
        '
        'LabelSaldo
        '
        Me.LabelSaldo.AutoSize = True
        Me.LabelSaldo.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSaldo.Location = New System.Drawing.Point(301, 164)
        Me.LabelSaldo.Name = "LabelSaldo"
        Me.LabelSaldo.Size = New System.Drawing.Size(0, 37)
        Me.LabelSaldo.TabIndex = 34
        '
        'LabelMoneda
        '
        Me.LabelMoneda.AutoSize = True
        Me.LabelMoneda.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMoneda.Location = New System.Drawing.Point(301, 199)
        Me.LabelMoneda.Name = "LabelMoneda"
        Me.LabelMoneda.Size = New System.Drawing.Size(0, 37)
        Me.LabelMoneda.TabIndex = 35
        '
        'FormSaldo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(930, 560)
        Me.Controls.Add(Me.LabelMoneda)
        Me.Controls.Add(Me.LabelSaldo)
        Me.Controls.Add(Me.btnConsultas)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.LabelTítulo)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "FormSaldo"
        Me.Text = "FormProductos"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LabelTítulo As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Protected Friend WithEvents btnConsultas As System.Windows.Forms.Button
    Friend WithEvents LabelSaldo As System.Windows.Forms.Label
    Friend WithEvents LabelMoneda As System.Windows.Forms.Label
End Class
