﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMantenimiento
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMantenimiento))
        Me.PanelLogo = New System.Windows.Forms.Panel()
        Me.LabelFuncionario = New System.Windows.Forms.Label()
        Me.btnConsultas = New System.Windows.Forms.Button()
        Me.btnEliminarCuenta = New System.Windows.Forms.Button()
        Me.btnModificarCuenta = New System.Windows.Forms.Button()
        Me.PanelAbajo = New System.Windows.Forms.Panel()
        Me.btnAltaCuenta = New System.Windows.Forms.Button()
        Me.PanelMenuSEW = New System.Windows.Forms.Panel()
        Me.PanelTransacciónMenú = New System.Windows.Forms.Panel()
        Me.btnEliminarTransacción = New System.Windows.Forms.Button()
        Me.btnModificarTransacción = New System.Windows.Forms.Button()
        Me.btnAltaTransacción = New System.Windows.Forms.Button()
        Me.btnTransacción = New System.Windows.Forms.Button()
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.PanelSucursalMenú = New System.Windows.Forms.Panel()
        Me.btnEliminarSucursal = New System.Windows.Forms.Button()
        Me.btnModificarSucursal = New System.Windows.Forms.Button()
        Me.btnAltaSucursal = New System.Windows.Forms.Button()
        Me.btnSucursal = New System.Windows.Forms.Button()
        Me.PanelClienteMenú = New System.Windows.Forms.Panel()
        Me.btnEliminarCliente = New System.Windows.Forms.Button()
        Me.btnModificarCliente = New System.Windows.Forms.Button()
        Me.btnAltaCliente = New System.Windows.Forms.Button()
        Me.btnCliente = New System.Windows.Forms.Button()
        Me.PanelCuentaMenú = New System.Windows.Forms.Panel()
        Me.btnCuenta = New System.Windows.Forms.Button()
        Me.PanelFormHijo = New System.Windows.Forms.Panel()
        Me.PictureBoxLogo = New System.Windows.Forms.PictureBox()
        Me.PanelLogo.SuspendLayout()
        Me.PanelMenuSEW.SuspendLayout()
        Me.PanelTransacciónMenú.SuspendLayout()
        Me.PanelSucursalMenú.SuspendLayout()
        Me.PanelClienteMenú.SuspendLayout()
        Me.PanelCuentaMenú.SuspendLayout()
        Me.PanelFormHijo.SuspendLayout()
        CType(Me.PictureBoxLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PanelLogo
        '
        Me.PanelLogo.Controls.Add(Me.LabelFuncionario)
        Me.PanelLogo.Controls.Add(Me.btnConsultas)
        Me.PanelLogo.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelLogo.Location = New System.Drawing.Point(0, 0)
        Me.PanelLogo.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelLogo.Name = "PanelLogo"
        Me.PanelLogo.Size = New System.Drawing.Size(327, 138)
        Me.PanelLogo.TabIndex = 0
        '
        'LabelFuncionario
        '
        Me.LabelFuncionario.AutoSize = True
        Me.LabelFuncionario.ForeColor = System.Drawing.Color.LightGray
        Me.LabelFuncionario.Location = New System.Drawing.Point(30, 9)
        Me.LabelFuncionario.Name = "LabelFuncionario"
        Me.LabelFuncionario.Size = New System.Drawing.Size(111, 24)
        Me.LabelFuncionario.TabIndex = 1
        Me.LabelFuncionario.Text = "Funcionario"
        '
        'btnConsultas
        '
        Me.btnConsultas.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.btnConsultas.FlatAppearance.BorderSize = 0
        Me.btnConsultas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnConsultas.ForeColor = System.Drawing.Color.LightGray
        Me.btnConsultas.Location = New System.Drawing.Point(34, 68)
        Me.btnConsultas.Margin = New System.Windows.Forms.Padding(4)
        Me.btnConsultas.Name = "btnConsultas"
        Me.btnConsultas.Size = New System.Drawing.Size(256, 44)
        Me.btnConsultas.TabIndex = 0
        Me.btnConsultas.Text = "Ir a Consultas"
        Me.btnConsultas.UseVisualStyleBackColor = False
        '
        'btnEliminarCuenta
        '
        Me.btnEliminarCuenta.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnEliminarCuenta.FlatAppearance.BorderSize = 0
        Me.btnEliminarCuenta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnEliminarCuenta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnEliminarCuenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEliminarCuenta.ForeColor = System.Drawing.Color.LightGray
        Me.btnEliminarCuenta.Location = New System.Drawing.Point(0, 125)
        Me.btnEliminarCuenta.Margin = New System.Windows.Forms.Padding(4)
        Me.btnEliminarCuenta.Name = "btnEliminarCuenta"
        Me.btnEliminarCuenta.Padding = New System.Windows.Forms.Padding(48, 0, 0, 0)
        Me.btnEliminarCuenta.Size = New System.Drawing.Size(327, 60)
        Me.btnEliminarCuenta.TabIndex = 2
        Me.btnEliminarCuenta.Text = "Eliminar Cuenta"
        Me.btnEliminarCuenta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnEliminarCuenta.UseVisualStyleBackColor = True
        '
        'btnModificarCuenta
        '
        Me.btnModificarCuenta.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnModificarCuenta.FlatAppearance.BorderSize = 0
        Me.btnModificarCuenta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnModificarCuenta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnModificarCuenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnModificarCuenta.ForeColor = System.Drawing.Color.LightGray
        Me.btnModificarCuenta.Location = New System.Drawing.Point(0, 65)
        Me.btnModificarCuenta.Margin = New System.Windows.Forms.Padding(4)
        Me.btnModificarCuenta.Name = "btnModificarCuenta"
        Me.btnModificarCuenta.Padding = New System.Windows.Forms.Padding(48, 0, 0, 0)
        Me.btnModificarCuenta.Size = New System.Drawing.Size(327, 60)
        Me.btnModificarCuenta.TabIndex = 1
        Me.btnModificarCuenta.Text = "Modificar Cuenta"
        Me.btnModificarCuenta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnModificarCuenta.UseVisualStyleBackColor = True
        '
        'PanelAbajo
        '
        Me.PanelAbajo.BackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(21, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.PanelAbajo.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelAbajo.Location = New System.Drawing.Point(344, 654)
        Me.PanelAbajo.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelAbajo.Name = "PanelAbajo"
        Me.PanelAbajo.Size = New System.Drawing.Size(940, 73)
        Me.PanelAbajo.TabIndex = 1
        '
        'btnAltaCuenta
        '
        Me.btnAltaCuenta.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnAltaCuenta.FlatAppearance.BorderSize = 0
        Me.btnAltaCuenta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnAltaCuenta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnAltaCuenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAltaCuenta.ForeColor = System.Drawing.Color.LightGray
        Me.btnAltaCuenta.Location = New System.Drawing.Point(0, 0)
        Me.btnAltaCuenta.Margin = New System.Windows.Forms.Padding(4)
        Me.btnAltaCuenta.Name = "btnAltaCuenta"
        Me.btnAltaCuenta.Padding = New System.Windows.Forms.Padding(48, 0, 0, 0)
        Me.btnAltaCuenta.Size = New System.Drawing.Size(327, 65)
        Me.btnAltaCuenta.TabIndex = 0
        Me.btnAltaCuenta.Text = "Ingresar Cuenta"
        Me.btnAltaCuenta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAltaCuenta.UseVisualStyleBackColor = True
        '
        'PanelMenuSEW
        '
        Me.PanelMenuSEW.AutoScroll = True
        Me.PanelMenuSEW.BackColor = System.Drawing.Color.FromArgb(CType(CType(11, Byte), Integer), CType(CType(7, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.PanelMenuSEW.Controls.Add(Me.PanelTransacciónMenú)
        Me.PanelMenuSEW.Controls.Add(Me.btnTransacción)
        Me.PanelMenuSEW.Controls.Add(Me.btnSalir)
        Me.PanelMenuSEW.Controls.Add(Me.PanelSucursalMenú)
        Me.PanelMenuSEW.Controls.Add(Me.btnSucursal)
        Me.PanelMenuSEW.Controls.Add(Me.PanelClienteMenú)
        Me.PanelMenuSEW.Controls.Add(Me.btnCliente)
        Me.PanelMenuSEW.Controls.Add(Me.PanelCuentaMenú)
        Me.PanelMenuSEW.Controls.Add(Me.btnCuenta)
        Me.PanelMenuSEW.Controls.Add(Me.PanelLogo)
        Me.PanelMenuSEW.Dock = System.Windows.Forms.DockStyle.Left
        Me.PanelMenuSEW.Location = New System.Drawing.Point(0, 0)
        Me.PanelMenuSEW.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelMenuSEW.Name = "PanelMenuSEW"
        Me.PanelMenuSEW.Size = New System.Drawing.Size(344, 727)
        Me.PanelMenuSEW.TabIndex = 0
        '
        'PanelTransacciónMenú
        '
        Me.PanelTransacciónMenú.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer))
        Me.PanelTransacciónMenú.Controls.Add(Me.btnEliminarTransacción)
        Me.PanelTransacciónMenú.Controls.Add(Me.btnModificarTransacción)
        Me.PanelTransacciónMenú.Controls.Add(Me.btnAltaTransacción)
        Me.PanelTransacciónMenú.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelTransacciónMenú.Location = New System.Drawing.Point(0, 965)
        Me.PanelTransacciónMenú.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelTransacciónMenú.Name = "PanelTransacciónMenú"
        Me.PanelTransacciónMenú.Size = New System.Drawing.Size(327, 195)
        Me.PanelTransacciónMenú.TabIndex = 11
        '
        'btnEliminarTransacción
        '
        Me.btnEliminarTransacción.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnEliminarTransacción.FlatAppearance.BorderSize = 0
        Me.btnEliminarTransacción.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnEliminarTransacción.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnEliminarTransacción.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEliminarTransacción.ForeColor = System.Drawing.Color.LightGray
        Me.btnEliminarTransacción.Location = New System.Drawing.Point(0, 120)
        Me.btnEliminarTransacción.Margin = New System.Windows.Forms.Padding(4)
        Me.btnEliminarTransacción.Name = "btnEliminarTransacción"
        Me.btnEliminarTransacción.Padding = New System.Windows.Forms.Padding(48, 0, 0, 0)
        Me.btnEliminarTransacción.Size = New System.Drawing.Size(327, 60)
        Me.btnEliminarTransacción.TabIndex = 2
        Me.btnEliminarTransacción.Text = "Eliminar Transacción"
        Me.btnEliminarTransacción.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnEliminarTransacción.UseVisualStyleBackColor = True
        '
        'btnModificarTransacción
        '
        Me.btnModificarTransacción.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnModificarTransacción.FlatAppearance.BorderSize = 0
        Me.btnModificarTransacción.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnModificarTransacción.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnModificarTransacción.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnModificarTransacción.ForeColor = System.Drawing.Color.LightGray
        Me.btnModificarTransacción.Location = New System.Drawing.Point(0, 60)
        Me.btnModificarTransacción.Margin = New System.Windows.Forms.Padding(4)
        Me.btnModificarTransacción.Name = "btnModificarTransacción"
        Me.btnModificarTransacción.Padding = New System.Windows.Forms.Padding(48, 0, 0, 0)
        Me.btnModificarTransacción.Size = New System.Drawing.Size(327, 60)
        Me.btnModificarTransacción.TabIndex = 1
        Me.btnModificarTransacción.Text = "Modificar Transacción"
        Me.btnModificarTransacción.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnModificarTransacción.UseVisualStyleBackColor = True
        '
        'btnAltaTransacción
        '
        Me.btnAltaTransacción.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnAltaTransacción.FlatAppearance.BorderSize = 0
        Me.btnAltaTransacción.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnAltaTransacción.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnAltaTransacción.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAltaTransacción.ForeColor = System.Drawing.Color.LightGray
        Me.btnAltaTransacción.Location = New System.Drawing.Point(0, 0)
        Me.btnAltaTransacción.Margin = New System.Windows.Forms.Padding(4)
        Me.btnAltaTransacción.Name = "btnAltaTransacción"
        Me.btnAltaTransacción.Padding = New System.Windows.Forms.Padding(48, 0, 0, 0)
        Me.btnAltaTransacción.Size = New System.Drawing.Size(327, 60)
        Me.btnAltaTransacción.TabIndex = 0
        Me.btnAltaTransacción.Text = "Ingresar Transacción"
        Me.btnAltaTransacción.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAltaTransacción.UseVisualStyleBackColor = True
        '
        'btnTransacción
        '
        Me.btnTransacción.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnTransacción.FlatAppearance.BorderSize = 0
        Me.btnTransacción.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(21, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.btnTransacción.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnTransacción.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTransacción.ForeColor = System.Drawing.Color.LightGray
        Me.btnTransacción.Image = CType(resources.GetObject("btnTransacción.Image"), System.Drawing.Image)
        Me.btnTransacción.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTransacción.Location = New System.Drawing.Point(0, 897)
        Me.btnTransacción.Margin = New System.Windows.Forms.Padding(4)
        Me.btnTransacción.Name = "btnTransacción"
        Me.btnTransacción.Padding = New System.Windows.Forms.Padding(7, 0, 0, 0)
        Me.btnTransacción.Size = New System.Drawing.Size(327, 68)
        Me.btnTransacción.TabIndex = 10
        Me.btnTransacción.Text = "  Transacciónes"
        Me.btnTransacción.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTransacción.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnTransacción.UseVisualStyleBackColor = True
        '
        'btnSalir
        '
        Me.btnSalir.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.btnSalir.FlatAppearance.BorderSize = 0
        Me.btnSalir.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btnSalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btnSalir.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSalir.ForeColor = System.Drawing.Color.LightGray
        Me.btnSalir.Image = CType(resources.GetObject("btnSalir.Image"), System.Drawing.Image)
        Me.btnSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSalir.Location = New System.Drawing.Point(0, 1160)
        Me.btnSalir.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Padding = New System.Windows.Forms.Padding(7, 0, 0, 0)
        Me.btnSalir.Size = New System.Drawing.Size(327, 58)
        Me.btnSalir.TabIndex = 9
        Me.btnSalir.Text = "  Salir"
        Me.btnSalir.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSalir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnSalir.UseVisualStyleBackColor = True
        '
        'PanelSucursalMenú
        '
        Me.PanelSucursalMenú.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer))
        Me.PanelSucursalMenú.Controls.Add(Me.btnEliminarSucursal)
        Me.PanelSucursalMenú.Controls.Add(Me.btnModificarSucursal)
        Me.PanelSucursalMenú.Controls.Add(Me.btnAltaSucursal)
        Me.PanelSucursalMenú.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelSucursalMenú.Location = New System.Drawing.Point(0, 702)
        Me.PanelSucursalMenú.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelSucursalMenú.Name = "PanelSucursalMenú"
        Me.PanelSucursalMenú.Size = New System.Drawing.Size(327, 195)
        Me.PanelSucursalMenú.TabIndex = 11
        '
        'btnEliminarSucursal
        '
        Me.btnEliminarSucursal.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnEliminarSucursal.FlatAppearance.BorderSize = 0
        Me.btnEliminarSucursal.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnEliminarSucursal.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnEliminarSucursal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEliminarSucursal.ForeColor = System.Drawing.Color.LightGray
        Me.btnEliminarSucursal.Location = New System.Drawing.Point(0, 120)
        Me.btnEliminarSucursal.Margin = New System.Windows.Forms.Padding(4)
        Me.btnEliminarSucursal.Name = "btnEliminarSucursal"
        Me.btnEliminarSucursal.Padding = New System.Windows.Forms.Padding(48, 0, 0, 0)
        Me.btnEliminarSucursal.Size = New System.Drawing.Size(327, 60)
        Me.btnEliminarSucursal.TabIndex = 2
        Me.btnEliminarSucursal.Text = "Eliminar Sucursal"
        Me.btnEliminarSucursal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnEliminarSucursal.UseVisualStyleBackColor = True
        '
        'btnModificarSucursal
        '
        Me.btnModificarSucursal.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnModificarSucursal.FlatAppearance.BorderSize = 0
        Me.btnModificarSucursal.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnModificarSucursal.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnModificarSucursal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnModificarSucursal.ForeColor = System.Drawing.Color.LightGray
        Me.btnModificarSucursal.Location = New System.Drawing.Point(0, 60)
        Me.btnModificarSucursal.Margin = New System.Windows.Forms.Padding(4)
        Me.btnModificarSucursal.Name = "btnModificarSucursal"
        Me.btnModificarSucursal.Padding = New System.Windows.Forms.Padding(48, 0, 0, 0)
        Me.btnModificarSucursal.Size = New System.Drawing.Size(327, 60)
        Me.btnModificarSucursal.TabIndex = 1
        Me.btnModificarSucursal.Text = "Modificar Sucursal"
        Me.btnModificarSucursal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnModificarSucursal.UseVisualStyleBackColor = True
        '
        'btnAltaSucursal
        '
        Me.btnAltaSucursal.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnAltaSucursal.FlatAppearance.BorderSize = 0
        Me.btnAltaSucursal.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnAltaSucursal.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnAltaSucursal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAltaSucursal.ForeColor = System.Drawing.Color.LightGray
        Me.btnAltaSucursal.Location = New System.Drawing.Point(0, 0)
        Me.btnAltaSucursal.Margin = New System.Windows.Forms.Padding(4)
        Me.btnAltaSucursal.Name = "btnAltaSucursal"
        Me.btnAltaSucursal.Padding = New System.Windows.Forms.Padding(48, 0, 0, 0)
        Me.btnAltaSucursal.Size = New System.Drawing.Size(327, 60)
        Me.btnAltaSucursal.TabIndex = 0
        Me.btnAltaSucursal.Text = "Ingresar Sucursal"
        Me.btnAltaSucursal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAltaSucursal.UseVisualStyleBackColor = True
        '
        'btnSucursal
        '
        Me.btnSucursal.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnSucursal.FlatAppearance.BorderSize = 0
        Me.btnSucursal.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(21, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.btnSucursal.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnSucursal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSucursal.ForeColor = System.Drawing.Color.LightGray
        Me.btnSucursal.Image = CType(resources.GetObject("btnSucursal.Image"), System.Drawing.Image)
        Me.btnSucursal.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSucursal.Location = New System.Drawing.Point(0, 634)
        Me.btnSucursal.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSucursal.Name = "btnSucursal"
        Me.btnSucursal.Padding = New System.Windows.Forms.Padding(7, 0, 0, 0)
        Me.btnSucursal.Size = New System.Drawing.Size(327, 68)
        Me.btnSucursal.TabIndex = 6
        Me.btnSucursal.Text = "  Sucursales"
        Me.btnSucursal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSucursal.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnSucursal.UseVisualStyleBackColor = True
        '
        'PanelClienteMenú
        '
        Me.PanelClienteMenú.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer))
        Me.PanelClienteMenú.Controls.Add(Me.btnEliminarCliente)
        Me.PanelClienteMenú.Controls.Add(Me.btnModificarCliente)
        Me.PanelClienteMenú.Controls.Add(Me.btnAltaCliente)
        Me.PanelClienteMenú.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelClienteMenú.Location = New System.Drawing.Point(0, 452)
        Me.PanelClienteMenú.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelClienteMenú.Name = "PanelClienteMenú"
        Me.PanelClienteMenú.Size = New System.Drawing.Size(327, 182)
        Me.PanelClienteMenú.TabIndex = 4
        '
        'btnEliminarCliente
        '
        Me.btnEliminarCliente.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnEliminarCliente.FlatAppearance.BorderSize = 0
        Me.btnEliminarCliente.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnEliminarCliente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnEliminarCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEliminarCliente.ForeColor = System.Drawing.Color.LightGray
        Me.btnEliminarCliente.Location = New System.Drawing.Point(0, 120)
        Me.btnEliminarCliente.Margin = New System.Windows.Forms.Padding(4)
        Me.btnEliminarCliente.Name = "btnEliminarCliente"
        Me.btnEliminarCliente.Padding = New System.Windows.Forms.Padding(48, 0, 0, 0)
        Me.btnEliminarCliente.Size = New System.Drawing.Size(327, 60)
        Me.btnEliminarCliente.TabIndex = 2
        Me.btnEliminarCliente.Text = "Eliminar Cliente"
        Me.btnEliminarCliente.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnEliminarCliente.UseVisualStyleBackColor = True
        '
        'btnModificarCliente
        '
        Me.btnModificarCliente.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnModificarCliente.FlatAppearance.BorderSize = 0
        Me.btnModificarCliente.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnModificarCliente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnModificarCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnModificarCliente.ForeColor = System.Drawing.Color.LightGray
        Me.btnModificarCliente.Location = New System.Drawing.Point(0, 60)
        Me.btnModificarCliente.Margin = New System.Windows.Forms.Padding(4)
        Me.btnModificarCliente.Name = "btnModificarCliente"
        Me.btnModificarCliente.Padding = New System.Windows.Forms.Padding(48, 0, 0, 0)
        Me.btnModificarCliente.Size = New System.Drawing.Size(327, 60)
        Me.btnModificarCliente.TabIndex = 1
        Me.btnModificarCliente.Text = "Modificar Cliente"
        Me.btnModificarCliente.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnModificarCliente.UseVisualStyleBackColor = True
        '
        'btnAltaCliente
        '
        Me.btnAltaCliente.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnAltaCliente.FlatAppearance.BorderSize = 0
        Me.btnAltaCliente.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnAltaCliente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(46, Byte), Integer))
        Me.btnAltaCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAltaCliente.ForeColor = System.Drawing.Color.LightGray
        Me.btnAltaCliente.Location = New System.Drawing.Point(0, 0)
        Me.btnAltaCliente.Margin = New System.Windows.Forms.Padding(4)
        Me.btnAltaCliente.Name = "btnAltaCliente"
        Me.btnAltaCliente.Padding = New System.Windows.Forms.Padding(48, 0, 0, 0)
        Me.btnAltaCliente.Size = New System.Drawing.Size(327, 60)
        Me.btnAltaCliente.TabIndex = 0
        Me.btnAltaCliente.Text = "Ingresar Cliente"
        Me.btnAltaCliente.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAltaCliente.UseVisualStyleBackColor = True
        '
        'btnCliente
        '
        Me.btnCliente.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnCliente.FlatAppearance.BorderSize = 0
        Me.btnCliente.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(21, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.btnCliente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCliente.ForeColor = System.Drawing.Color.LightGray
        Me.btnCliente.Image = CType(resources.GetObject("btnCliente.Image"), System.Drawing.Image)
        Me.btnCliente.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCliente.Location = New System.Drawing.Point(0, 384)
        Me.btnCliente.Margin = New System.Windows.Forms.Padding(4)
        Me.btnCliente.Name = "btnCliente"
        Me.btnCliente.Padding = New System.Windows.Forms.Padding(7, 0, 0, 0)
        Me.btnCliente.Size = New System.Drawing.Size(327, 68)
        Me.btnCliente.TabIndex = 3
        Me.btnCliente.Text = "  Clientes"
        Me.btnCliente.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCliente.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnCliente.UseVisualStyleBackColor = True
        '
        'PanelCuentaMenú
        '
        Me.PanelCuentaMenú.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer))
        Me.PanelCuentaMenú.Controls.Add(Me.btnEliminarCuenta)
        Me.PanelCuentaMenú.Controls.Add(Me.btnModificarCuenta)
        Me.PanelCuentaMenú.Controls.Add(Me.btnAltaCuenta)
        Me.PanelCuentaMenú.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelCuentaMenú.Location = New System.Drawing.Point(0, 206)
        Me.PanelCuentaMenú.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelCuentaMenú.Name = "PanelCuentaMenú"
        Me.PanelCuentaMenú.Size = New System.Drawing.Size(327, 178)
        Me.PanelCuentaMenú.TabIndex = 2
        '
        'btnCuenta
        '
        Me.btnCuenta.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnCuenta.FlatAppearance.BorderSize = 0
        Me.btnCuenta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(21, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.btnCuenta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnCuenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCuenta.ForeColor = System.Drawing.Color.LightGray
        Me.btnCuenta.Image = CType(resources.GetObject("btnCuenta.Image"), System.Drawing.Image)
        Me.btnCuenta.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCuenta.Location = New System.Drawing.Point(0, 138)
        Me.btnCuenta.Margin = New System.Windows.Forms.Padding(4)
        Me.btnCuenta.Name = "btnCuenta"
        Me.btnCuenta.Padding = New System.Windows.Forms.Padding(7, 0, 0, 0)
        Me.btnCuenta.Size = New System.Drawing.Size(327, 68)
        Me.btnCuenta.TabIndex = 1
        Me.btnCuenta.Text = "  Cuentas"
        Me.btnCuenta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCuenta.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnCuenta.UseVisualStyleBackColor = True
        '
        'PanelFormHijo
        '
        Me.PanelFormHijo.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.PanelFormHijo.Controls.Add(Me.PictureBoxLogo)
        Me.PanelFormHijo.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelFormHijo.Location = New System.Drawing.Point(344, 0)
        Me.PanelFormHijo.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelFormHijo.Name = "PanelFormHijo"
        Me.PanelFormHijo.Size = New System.Drawing.Size(940, 654)
        Me.PanelFormHijo.TabIndex = 2
        '
        'PictureBoxLogo
        '
        Me.PictureBoxLogo.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.PictureBoxLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBoxLogo.Image = CType(resources.GetObject("PictureBoxLogo.Image"), System.Drawing.Image)
        Me.PictureBoxLogo.Location = New System.Drawing.Point(330, 195)
        Me.PictureBoxLogo.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBoxLogo.Name = "PictureBoxLogo"
        Me.PictureBoxLogo.Size = New System.Drawing.Size(290, 230)
        Me.PictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBoxLogo.TabIndex = 0
        Me.PictureBoxLogo.TabStop = False
        '
        'FormMantenimiento
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 24.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1284, 727)
        Me.Controls.Add(Me.PanelFormHijo)
        Me.Controls.Add(Me.PanelAbajo)
        Me.Controls.Add(Me.PanelMenuSEW)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(6)
        Me.MinimumSize = New System.Drawing.Size(1300, 766)
        Me.Name = "FormMantenimiento"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Mantenimiento"
        Me.PanelLogo.ResumeLayout(False)
        Me.PanelLogo.PerformLayout()
        Me.PanelMenuSEW.ResumeLayout(False)
        Me.PanelTransacciónMenú.ResumeLayout(False)
        Me.PanelSucursalMenú.ResumeLayout(False)
        Me.PanelClienteMenú.ResumeLayout(False)
        Me.PanelCuentaMenú.ResumeLayout(False)
        Me.PanelFormHijo.ResumeLayout(False)
        Me.PanelFormHijo.PerformLayout()
        CType(Me.PictureBoxLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Private WithEvents PanelLogo As Panel
    Private WithEvents btnEliminarCuenta As Button
    Private WithEvents btnModificarCuenta As Button
    Private WithEvents PanelAbajo As Panel
    Private WithEvents btnAltaCuenta As Button
    Private WithEvents PanelMenuSEW As Panel
    Private WithEvents btnSalir As Button
    Private WithEvents PanelSucursalMenú As Panel
    Private WithEvents btnEliminarSucursal As Button
    Private WithEvents btnModificarSucursal As Button
    Private WithEvents btnAltaSucursal As Button
    Private WithEvents btnSucursal As Button
    Private WithEvents PanelClienteMenú As Panel
    Private WithEvents btnModificarCliente As Button
    Private WithEvents btnAltaCliente As Button
    Private WithEvents btnCliente As Button
    Private WithEvents PanelCuentaMenú As Panel
    Private WithEvents btnCuenta As Button
    Friend WithEvents PanelFormHijo As Panel
    Friend WithEvents PictureBoxLogo As PictureBox
    Friend WithEvents btnConsultas As System.Windows.Forms.Button
    Friend WithEvents LabelFuncionario As System.Windows.Forms.Label
    Private WithEvents btnEliminarCliente As System.Windows.Forms.Button
    Private WithEvents btnTransacción As System.Windows.Forms.Button
    Private WithEvents PanelTransacciónMenú As System.Windows.Forms.Panel
    Private WithEvents btnEliminarTransacción As System.Windows.Forms.Button
    Private WithEvents btnModificarTransacción As System.Windows.Forms.Button
    Private WithEvents btnAltaTransacción As System.Windows.Forms.Button
End Class
