﻿Imports System.Runtime.InteropServices
Imports MySql.Data.MySqlClient
Public Class FormSaldo

    Dim PinSaldo As String = FormSesión.PinCuenta.Text
    'Consultar tu saldo
    Private Sub btnConsultas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConsultas.Click
        Dim DTSaldo As New DataTable
        Dim SqlSaldo As String = "SELECT saldo,Moneda FROM cuenta WHERE Pin_Cuenta = '" & PinSaldo & "'"
        Dim SqlComandoSaldo = New MySqlCommand(SqlSaldo, FormSesión.Conexión)
        Dim LectorCuenta = New MySqlDataAdapter(SqlComandoSaldo)
        FormSesión.Conexión.Open()
        LectorCuenta.Fill(DTSaldo)
        LabelSaldo.Text = DTSaldo.Rows(0)("Saldo").ToString()
        LabelMoneda.Text = DTSaldo.Rows(0)("Moneda").ToString()
        FormSesión.Conexión.Close()
    End Sub

End Class