﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormModificarSucursal
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormModificarSucursal))
        Me.LabelNombre = New System.Windows.Forms.Label()
        Me.TextBoxNom = New System.Windows.Forms.TextBox()
        Me.btnBorrar = New System.Windows.Forms.Button()
        Me.TextBoxSuc = New System.Windows.Forms.TextBox()
        Me.LabelSucursal = New System.Windows.Forms.Label()
        Me.btnModificar = New System.Windows.Forms.Button()
        Me.LabelDireccion = New System.Windows.Forms.Label()
        Me.TextBoxDir = New System.Windows.Forms.TextBox()
        Me.LabelTítulo = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnBuscar = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'LabelNombre
        '
        Me.LabelNombre.AutoSize = True
        Me.LabelNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelNombre.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelNombre.Location = New System.Drawing.Point(59, 215)
        Me.LabelNombre.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelNombre.Name = "LabelNombre"
        Me.LabelNombre.Size = New System.Drawing.Size(65, 20)
        Me.LabelNombre.TabIndex = 24
        Me.LabelNombre.Text = "Nombre"
        '
        'TextBoxNom
        '
        Me.TextBoxNom.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxNom.Location = New System.Drawing.Point(227, 212)
        Me.TextBoxNom.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxNom.Name = "TextBoxNom"
        Me.TextBoxNom.Size = New System.Drawing.Size(330, 26)
        Me.TextBoxNom.TabIndex = 23
        '
        'btnBorrar
        '
        Me.btnBorrar.BackColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnBorrar.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBorrar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBorrar.ForeColor = System.Drawing.Color.LightGray
        Me.btnBorrar.Location = New System.Drawing.Point(303, 389)
        Me.btnBorrar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnBorrar.Name = "btnBorrar"
        Me.btnBorrar.Size = New System.Drawing.Size(206, 54)
        Me.btnBorrar.TabIndex = 22
        Me.btnBorrar.Text = "Borrar "
        Me.btnBorrar.UseVisualStyleBackColor = False
        '
        'TextBoxSuc
        '
        Me.TextBoxSuc.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxSuc.Location = New System.Drawing.Point(227, 152)
        Me.TextBoxSuc.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxSuc.MaxLength = 8
        Me.TextBoxSuc.Name = "TextBoxSuc"
        Me.TextBoxSuc.Size = New System.Drawing.Size(330, 26)
        Me.TextBoxSuc.TabIndex = 21
        '
        'LabelSucursal
        '
        Me.LabelSucursal.AutoSize = True
        Me.LabelSucursal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSucursal.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelSucursal.Location = New System.Drawing.Point(59, 152)
        Me.LabelSucursal.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelSucursal.Name = "LabelSucursal"
        Me.LabelSucursal.Size = New System.Drawing.Size(130, 20)
        Me.LabelSucursal.TabIndex = 20
        Me.LabelSucursal.Text = "Código_Sucursal"
        '
        'btnModificar
        '
        Me.btnModificar.BackColor = System.Drawing.Color.Red
        Me.btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnModificar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnModificar.ForeColor = System.Drawing.Color.LightGray
        Me.btnModificar.Location = New System.Drawing.Point(63, 389)
        Me.btnModificar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnModificar.Name = "btnModificar"
        Me.btnModificar.Size = New System.Drawing.Size(206, 54)
        Me.btnModificar.TabIndex = 19
        Me.btnModificar.Text = "Modificar"
        Me.btnModificar.UseVisualStyleBackColor = False
        '
        'LabelDireccion
        '
        Me.LabelDireccion.AutoSize = True
        Me.LabelDireccion.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelDireccion.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelDireccion.Location = New System.Drawing.Point(59, 277)
        Me.LabelDireccion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelDireccion.Name = "LabelDireccion"
        Me.LabelDireccion.Size = New System.Drawing.Size(75, 20)
        Me.LabelDireccion.TabIndex = 26
        Me.LabelDireccion.Text = "Direccion"
        '
        'TextBoxDir
        '
        Me.TextBoxDir.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxDir.Location = New System.Drawing.Point(227, 273)
        Me.TextBoxDir.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxDir.Name = "TextBoxDir"
        Me.TextBoxDir.Size = New System.Drawing.Size(330, 26)
        Me.TextBoxDir.TabIndex = 25
        '
        'LabelTítulo
        '
        Me.LabelTítulo.AutoSize = True
        Me.LabelTítulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelTítulo.ForeColor = System.Drawing.Color.Red
        Me.LabelTítulo.Location = New System.Drawing.Point(178, 31)
        Me.LabelTítulo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelTítulo.Name = "LabelTítulo"
        Me.LabelTítulo.Size = New System.Drawing.Size(281, 37)
        Me.LabelTítulo.TabIndex = 27
        Me.LabelTítulo.Text = "Modificar Sucursal"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.Control
        Me.Label1.Location = New System.Drawing.Point(565, 152)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(252, 20)
        Me.Label1.TabIndex = 57
        Me.Label1.Text = "Averiguar si existe la clave primaria"
        '
        'btnBuscar
        '
        Me.btnBuscar.BackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBuscar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBuscar.ForeColor = System.Drawing.Color.LightGray
        Me.btnBuscar.Location = New System.Drawing.Point(588, 195)
        Me.btnBuscar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnBuscar.Name = "btnBuscar"
        Me.btnBuscar.Size = New System.Drawing.Size(206, 54)
        Me.btnBuscar.TabIndex = 56
        Me.btnBuscar.Text = "Buscar"
        Me.btnBuscar.UseVisualStyleBackColor = False
        '
        'FormModificarSucursal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(878, 694)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnBuscar)
        Me.Controls.Add(Me.LabelTítulo)
        Me.Controls.Add(Me.LabelDireccion)
        Me.Controls.Add(Me.TextBoxDir)
        Me.Controls.Add(Me.LabelNombre)
        Me.Controls.Add(Me.TextBoxNom)
        Me.Controls.Add(Me.btnBorrar)
        Me.Controls.Add(Me.TextBoxSuc)
        Me.Controls.Add(Me.LabelSucursal)
        Me.Controls.Add(Me.btnModificar)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FormModificarSucursal"
        Me.Text = "Modificar Sucursales"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LabelNombre As System.Windows.Forms.Label
    Friend WithEvents TextBoxNom As System.Windows.Forms.TextBox
    Friend WithEvents btnBorrar As System.Windows.Forms.Button
    Friend WithEvents TextBoxSuc As System.Windows.Forms.TextBox
    Friend WithEvents LabelSucursal As System.Windows.Forms.Label
    Friend WithEvents btnModificar As System.Windows.Forms.Button
    Friend WithEvents LabelDireccion As System.Windows.Forms.Label
    Friend WithEvents TextBoxDir As System.Windows.Forms.TextBox
    Friend WithEvents LabelTítulo As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnBuscar As System.Windows.Forms.Button
End Class
