﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormAltaCliente
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormAltaCliente))
        Me.BotónBorrar = New System.Windows.Forms.Button()
        Me.LabelFec = New System.Windows.Forms.Label()
        Me.LabelNac = New System.Windows.Forms.Label()
        Me.LabelDom = New System.Windows.Forms.Label()
        Me.LabelNom = New System.Windows.Forms.Label()
        Me.LabelCliente = New System.Windows.Forms.Label()
        Me.LabelEs = New System.Windows.Forms.Label()
        Me.btnInsertar = New System.Windows.Forms.Button()
        Me.TextBoxNombre = New System.Windows.Forms.TextBox()
        Me.TextBoxDomicilio = New System.Windows.Forms.TextBox()
        Me.TextBoxNacionalidad = New System.Windows.Forms.TextBox()
        Me.TextBoxPin = New System.Windows.Forms.TextBox()
        Me.LabelSex = New System.Windows.Forms.Label()
        Me.ComboSexo = New System.Windows.Forms.ComboBox()
        Me.ComboCivil = New System.Windows.Forms.ComboBox()
        Me.LabelTítulo = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnBuscar = New System.Windows.Forms.Button()
        Me.FechaAltaCliente = New System.Windows.Forms.DateTimePicker()
        Me.SuspendLayout()
        '
        'BotónBorrar
        '
        Me.BotónBorrar.BackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BotónBorrar.FlatAppearance.BorderSize = 0
        Me.BotónBorrar.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BotónBorrar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotónBorrar.ForeColor = System.Drawing.Color.LightGray
        Me.BotónBorrar.Location = New System.Drawing.Point(336, 486)
        Me.BotónBorrar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BotónBorrar.Name = "BotónBorrar"
        Me.BotónBorrar.Size = New System.Drawing.Size(206, 54)
        Me.BotónBorrar.TabIndex = 30
        Me.BotónBorrar.Text = "Borrar "
        Me.BotónBorrar.UseVisualStyleBackColor = False
        '
        'LabelFec
        '
        Me.LabelFec.AutoSize = True
        Me.LabelFec.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelFec.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelFec.Location = New System.Drawing.Point(91, 326)
        Me.LabelFec.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelFec.Name = "LabelFec"
        Me.LabelFec.Size = New System.Drawing.Size(142, 20)
        Me.LabelFec.TabIndex = 28
        Me.LabelFec.Text = "Fecha_Nacimiento"
        '
        'LabelNac
        '
        Me.LabelNac.AutoSize = True
        Me.LabelNac.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelNac.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelNac.Location = New System.Drawing.Point(90, 271)
        Me.LabelNac.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelNac.Name = "LabelNac"
        Me.LabelNac.Size = New System.Drawing.Size(100, 20)
        Me.LabelNac.TabIndex = 27
        Me.LabelNac.Text = "Nacionalidad"
        '
        'LabelDom
        '
        Me.LabelDom.AutoSize = True
        Me.LabelDom.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelDom.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelDom.Location = New System.Drawing.Point(90, 216)
        Me.LabelDom.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelDom.Name = "LabelDom"
        Me.LabelDom.Size = New System.Drawing.Size(72, 20)
        Me.LabelDom.TabIndex = 25
        Me.LabelDom.Text = "Domicilio"
        '
        'LabelNom
        '
        Me.LabelNom.AutoSize = True
        Me.LabelNom.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelNom.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelNom.Location = New System.Drawing.Point(91, 153)
        Me.LabelNom.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelNom.Name = "LabelNom"
        Me.LabelNom.Size = New System.Drawing.Size(65, 20)
        Me.LabelNom.TabIndex = 24
        Me.LabelNom.Text = "Nombre"
        '
        'LabelCliente
        '
        Me.LabelCliente.AutoSize = True
        Me.LabelCliente.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelCliente.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelCliente.Location = New System.Drawing.Point(91, 93)
        Me.LabelCliente.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelCliente.Name = "LabelCliente"
        Me.LabelCliente.Size = New System.Drawing.Size(89, 20)
        Me.LabelCliente.TabIndex = 23
        Me.LabelCliente.Text = "Pin_Cliente"
        '
        'LabelEs
        '
        Me.LabelEs.AutoSize = True
        Me.LabelEs.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelEs.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelEs.Location = New System.Drawing.Point(90, 376)
        Me.LabelEs.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelEs.Name = "LabelEs"
        Me.LabelEs.Size = New System.Drawing.Size(96, 20)
        Me.LabelEs.TabIndex = 31
        Me.LabelEs.Text = "Estado_Civil"
        '
        'btnInsertar
        '
        Me.btnInsertar.BackColor = System.Drawing.Color.Red
        Me.btnInsertar.FlatAppearance.BorderSize = 0
        Me.btnInsertar.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnInsertar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInsertar.ForeColor = System.Drawing.Color.LightGray
        Me.btnInsertar.Location = New System.Drawing.Point(94, 486)
        Me.btnInsertar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnInsertar.Name = "btnInsertar"
        Me.btnInsertar.Size = New System.Drawing.Size(206, 54)
        Me.btnInsertar.TabIndex = 17
        Me.btnInsertar.Text = "Insertar"
        Me.btnInsertar.UseVisualStyleBackColor = False
        '
        'TextBoxNombre
        '
        Me.TextBoxNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.TextBoxNombre.Location = New System.Drawing.Point(272, 145)
        Me.TextBoxNombre.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxNombre.Name = "TextBoxNombre"
        Me.TextBoxNombre.Size = New System.Drawing.Size(330, 26)
        Me.TextBoxNombre.TabIndex = 19
        '
        'TextBoxDomicilio
        '
        Me.TextBoxDomicilio.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.TextBoxDomicilio.Location = New System.Drawing.Point(272, 208)
        Me.TextBoxDomicilio.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxDomicilio.MaxLength = 200
        Me.TextBoxDomicilio.Name = "TextBoxDomicilio"
        Me.TextBoxDomicilio.Size = New System.Drawing.Size(330, 26)
        Me.TextBoxDomicilio.TabIndex = 20
        '
        'TextBoxNacionalidad
        '
        Me.TextBoxNacionalidad.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.TextBoxNacionalidad.Location = New System.Drawing.Point(272, 260)
        Me.TextBoxNacionalidad.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxNacionalidad.Name = "TextBoxNacionalidad"
        Me.TextBoxNacionalidad.Size = New System.Drawing.Size(330, 26)
        Me.TextBoxNacionalidad.TabIndex = 22
        '
        'TextBoxPin
        '
        Me.TextBoxPin.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.TextBoxPin.Location = New System.Drawing.Point(272, 82)
        Me.TextBoxPin.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxPin.MaxLength = 4
        Me.TextBoxPin.Name = "TextBoxPin"
        Me.TextBoxPin.Size = New System.Drawing.Size(330, 26)
        Me.TextBoxPin.TabIndex = 18
        '
        'LabelSex
        '
        Me.LabelSex.AutoSize = True
        Me.LabelSex.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSex.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelSex.Location = New System.Drawing.Point(91, 433)
        Me.LabelSex.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelSex.Name = "LabelSex"
        Me.LabelSex.Size = New System.Drawing.Size(45, 20)
        Me.LabelSex.TabIndex = 34
        Me.LabelSex.Text = "Sexo"
        '
        'ComboSexo
        '
        Me.ComboSexo.AutoCompleteCustomSource.AddRange(New String() {"Masculino", "Femenino", "Otros"})
        Me.ComboSexo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.ComboSexo.FormattingEnabled = True
        Me.ComboSexo.Items.AddRange(New Object() {"Masculino", "Femenino", "Otros"})
        Me.ComboSexo.Location = New System.Drawing.Point(272, 429)
        Me.ComboSexo.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ComboSexo.Name = "ComboSexo"
        Me.ComboSexo.Size = New System.Drawing.Size(330, 28)
        Me.ComboSexo.TabIndex = 35
        '
        'ComboCivil
        '
        Me.ComboCivil.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.ComboCivil.FormattingEnabled = True
        Me.ComboCivil.Items.AddRange(New Object() {"Soltero", "Casado", "Divorciado", "Viudo"})
        Me.ComboCivil.Location = New System.Drawing.Point(272, 376)
        Me.ComboCivil.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ComboCivil.Name = "ComboCivil"
        Me.ComboCivil.Size = New System.Drawing.Size(330, 28)
        Me.ComboCivil.TabIndex = 36
        '
        'LabelTítulo
        '
        Me.LabelTítulo.AutoSize = True
        Me.LabelTítulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelTítulo.ForeColor = System.Drawing.Color.Red
        Me.LabelTítulo.Location = New System.Drawing.Point(189, 25)
        Me.LabelTítulo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelTítulo.Name = "LabelTítulo"
        Me.LabelTítulo.Size = New System.Drawing.Size(241, 37)
        Me.LabelTítulo.TabIndex = 38
        Me.LabelTítulo.Text = "Ingresar Cliente"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.Control
        Me.Label1.Location = New System.Drawing.Point(610, 86)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(252, 20)
        Me.Label1.TabIndex = 40
        Me.Label1.Text = "Averiguar si existe la clave primaria"
        '
        'btnBuscar
        '
        Me.btnBuscar.BackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBuscar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBuscar.ForeColor = System.Drawing.Color.LightGray
        Me.btnBuscar.Location = New System.Drawing.Point(630, 119)
        Me.btnBuscar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnBuscar.Name = "btnBuscar"
        Me.btnBuscar.Size = New System.Drawing.Size(206, 54)
        Me.btnBuscar.TabIndex = 39
        Me.btnBuscar.Text = "Buscar"
        Me.btnBuscar.UseVisualStyleBackColor = False
        '
        'FechaAltaCliente
        '
        Me.FechaAltaCliente.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FechaAltaCliente.Location = New System.Drawing.Point(272, 326)
        Me.FechaAltaCliente.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.FechaAltaCliente.Name = "FechaAltaCliente"
        Me.FechaAltaCliente.Size = New System.Drawing.Size(330, 26)
        Me.FechaAltaCliente.TabIndex = 41
        Me.FechaAltaCliente.Value = New Date(2019, 11, 14, 0, 0, 0, 0)
        '
        'FormAltaCliente
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(878, 694)
        Me.Controls.Add(Me.FechaAltaCliente)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnBuscar)
        Me.Controls.Add(Me.LabelTítulo)
        Me.Controls.Add(Me.ComboCivil)
        Me.Controls.Add(Me.ComboSexo)
        Me.Controls.Add(Me.LabelSex)
        Me.Controls.Add(Me.LabelEs)
        Me.Controls.Add(Me.BotónBorrar)
        Me.Controls.Add(Me.LabelFec)
        Me.Controls.Add(Me.LabelNac)
        Me.Controls.Add(Me.LabelDom)
        Me.Controls.Add(Me.LabelNom)
        Me.Controls.Add(Me.LabelCliente)
        Me.Controls.Add(Me.TextBoxNacionalidad)
        Me.Controls.Add(Me.TextBoxDomicilio)
        Me.Controls.Add(Me.TextBoxNombre)
        Me.Controls.Add(Me.TextBoxPin)
        Me.Controls.Add(Me.btnInsertar)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FormAltaCliente"
        Me.Text = "Crear Clientes"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BotónBorrar As System.Windows.Forms.Button
    Friend WithEvents LabelFec As System.Windows.Forms.Label
    Friend WithEvents LabelNac As System.Windows.Forms.Label
    Friend WithEvents LabelDom As System.Windows.Forms.Label
    Friend WithEvents LabelNom As System.Windows.Forms.Label
    Friend WithEvents LabelCliente As System.Windows.Forms.Label
    Friend WithEvents LabelEs As System.Windows.Forms.Label
    Friend WithEvents btnInsertar As System.Windows.Forms.Button
    Friend WithEvents TextBoxNombre As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxDomicilio As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxNacionalidad As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxPin As System.Windows.Forms.TextBox
    Friend WithEvents LabelSex As System.Windows.Forms.Label
    Friend WithEvents ComboSexo As System.Windows.Forms.ComboBox
    Friend WithEvents ComboCivil As System.Windows.Forms.ComboBox
    Friend WithEvents LabelTítulo As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnBuscar As System.Windows.Forms.Button
    Friend WithEvents FechaAltaCliente As System.Windows.Forms.DateTimePicker
End Class
