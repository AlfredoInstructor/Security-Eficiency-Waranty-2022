﻿Imports MySql.Data.MySqlClient
Public Class FormModificarSucursal
    Private Sub btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModificar.Click
        'Er es una variable de Error que nos señala cuando se repite la misma clave primaria y finaliza la tarea
        Dim Er As Integer = 0
        Dim SqlMS As String = "UPDATE sucursal SET Nombre = '" & TextBoxNom.Text & "'," & " Direccion = '" & TextBoxDir.Text & "'" & " WHERE Cod_Sucursal = " & TextBoxSuc.Text
        Dim Comando As New MySqlCommand(SqlMS, FormSesión.Conexión)
        If TextBoxSuc.Text = "" Then
            MsgBox("Ingrese clave primaria", vbExclamation, "Advertencia")
            Er = 1
        ElseIf TextBoxNom.Text = "" Or TextBoxDir.Text = "" Then
            MsgBox("Ingrese todos los registros correctamente", vbExclamation, "Advertencia")
            Er = 1
        End If
        Try
            FormSesión.Conexión.Open()
            'Casos al momento de borrar o no un dato
            Dim Respuesta As Integer = MsgBox("Desea modificar los datos ingresados?", vbYesNo + vbExclamation, "Advertencia")
            Select Case Respuesta
                Case vbYes
                    Comando.ExecuteNonQuery()
                    MsgBox("Se han modificado los datos correctamente", vbExclamation, "Advertencia")
                Case vbNo
                    MsgBox("Se ha cancelado la operación", vbExclamation, "Advertencia")
            End Select
        Catch ex As Exception
            MsgBox("Error" & ex.Message)
        End Try
        FormSesión.Conexión.Close()
    End Sub

    Private Sub btnBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
        Dim Respuesta As Integer = MsgBox("Desea borrar los datos ingresados?", vbYesNo + vbExclamation, "Advertencia")
        Select Case Respuesta
            Case vbYes
                MsgBox("Se han borrado los datos correctamente", vbExclamation, "Advertencia")
                TextBoxSuc.Text = ""
                TextBoxNom.Text = ""
                TextBoxDir.Text = ""
            Case vbNo
                MsgBox("Se ha cancelado la operación", vbExclamation, "Advertencia")
        End Select
    End Sub



    Private Sub FormModificarSucursal_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        Dim DTMSuc As New DataTable
        Dim SqlMSuc As String = "SELECT * FROM sucursal WHERE Cod_Sucursal = '" & TextBoxSuc.Text & "'"
        Dim SqlComandoMSuc = New MySqlCommand(SqlMSuc, FormSesión.Conexión)
        FormSesión.Conexión.Open()
        Dim LectorSuc = New MySqlDataAdapter(SqlComandoMSuc)
        LectorSuc.Fill(DTMSuc)


        Dim Cod_Sucursal As Integer = Val(TextBoxSuc.Text)


        If DTMSuc.Rows.Count = 0 Then
            MsgBox("No existen los datos", vbExclamation, "Advertencia")
        Else
            MsgBox("Existe la Clave Primaria", vbExclamation, "Advertencia")
            TextBoxSuc.Text = DTMSuc.Rows(0)("Cod_Sucursal").ToString()
            TextBoxNom.Text = DTMSuc.Rows(0)("Nombre").ToString()
            TextBoxDir.Text = DTMSuc.Rows(0)("Direccion").ToString()
        End If
        FormSesión.Conexión.Close()
    End Sub

End Class