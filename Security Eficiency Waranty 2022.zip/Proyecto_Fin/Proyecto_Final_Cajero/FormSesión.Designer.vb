﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormSesión
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormSesión))
        Me.BarraTítulo = New System.Windows.Forms.Panel()
        Me.LogoPicture = New System.Windows.Forms.PictureBox()
        Me.btnMinimize = New System.Windows.Forms.PictureBox()
        Me.BotonCerrar = New System.Windows.Forms.PictureBox()
        Me.LogoSEW = New System.Windows.Forms.PictureBox()
        Me.LabelPin = New System.Windows.Forms.Label()
        Me.PinCuenta = New System.Windows.Forms.TextBox()
        Me.BotonLogin = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PinCliente = New System.Windows.Forms.TextBox()
        Me.LabelPinCliente = New System.Windows.Forms.Label()
        Me.BarraTítulo.SuspendLayout()
        CType(Me.LogoPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnMinimize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BotonCerrar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LogoSEW, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BarraTítulo
        '
        Me.BarraTítulo.BackColor = System.Drawing.Color.FromArgb(CType(CType(123, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BarraTítulo.Controls.Add(Me.LogoPicture)
        Me.BarraTítulo.Controls.Add(Me.btnMinimize)
        Me.BarraTítulo.Controls.Add(Me.BotonCerrar)
        Me.BarraTítulo.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTítulo.Location = New System.Drawing.Point(0, 0)
        Me.BarraTítulo.Name = "BarraTítulo"
        Me.BarraTítulo.Size = New System.Drawing.Size(430, 40)
        Me.BarraTítulo.TabIndex = 0
        '
        'LogoPicture
        '
        Me.LogoPicture.BackgroundImage = CType(resources.GetObject("LogoPicture.BackgroundImage"), System.Drawing.Image)
        Me.LogoPicture.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.LogoPicture.Location = New System.Drawing.Point(0, -13)
        Me.LogoPicture.Name = "LogoPicture"
        Me.LogoPicture.Size = New System.Drawing.Size(40, 64)
        Me.LogoPicture.TabIndex = 11
        Me.LogoPicture.TabStop = False
        '
        'btnMinimize
        '
        Me.btnMinimize.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnMinimize.Image = CType(resources.GetObject("btnMinimize.Image"), System.Drawing.Image)
        Me.btnMinimize.Location = New System.Drawing.Point(347, 0)
        Me.btnMinimize.Name = "btnMinimize"
        Me.btnMinimize.Size = New System.Drawing.Size(40, 40)
        Me.btnMinimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.btnMinimize.TabIndex = 10
        Me.btnMinimize.TabStop = False
        '
        'BotonCerrar
        '
        Me.BotonCerrar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BotonCerrar.Image = CType(resources.GetObject("BotonCerrar.Image"), System.Drawing.Image)
        Me.BotonCerrar.Location = New System.Drawing.Point(390, 0)
        Me.BotonCerrar.Name = "BotonCerrar"
        Me.BotonCerrar.Size = New System.Drawing.Size(40, 40)
        Me.BotonCerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.BotonCerrar.TabIndex = 9
        Me.BotonCerrar.TabStop = False
        '
        'LogoSEW
        '
        Me.LogoSEW.Image = CType(resources.GetObject("LogoSEW.Image"), System.Drawing.Image)
        Me.LogoSEW.Location = New System.Drawing.Point(129, 46)
        Me.LogoSEW.Name = "LogoSEW"
        Me.LogoSEW.Size = New System.Drawing.Size(183, 210)
        Me.LogoSEW.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.LogoSEW.TabIndex = 1
        Me.LogoSEW.TabStop = False
        '
        'LabelPin
        '
        Me.LabelPin.AutoSize = True
        Me.LabelPin.Font = New System.Drawing.Font("Ebrima", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelPin.ForeColor = System.Drawing.Color.Silver
        Me.LabelPin.Location = New System.Drawing.Point(33, 346)
        Me.LabelPin.Name = "LabelPin"
        Me.LabelPin.Size = New System.Drawing.Size(88, 21)
        Me.LabelPin.TabIndex = 2
        Me.LabelPin.Text = "Pin_Cuenta"
        '
        'PinCuenta
        '
        Me.PinCuenta.BackColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.PinCuenta.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.PinCuenta.Font = New System.Drawing.Font("Ebrima", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PinCuenta.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.PinCuenta.Location = New System.Drawing.Point(37, 370)
        Me.PinCuenta.MaxLength = 10
        Me.PinCuenta.Name = "PinCuenta"
        Me.PinCuenta.Size = New System.Drawing.Size(350, 22)
        Me.PinCuenta.TabIndex = 3
        Me.PinCuenta.Text = "8798010101"
        '
        'BotonLogin
        '
        Me.BotonLogin.BackColor = System.Drawing.Color.FromArgb(CType(CType(155, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BotonLogin.FlatAppearance.BorderSize = 0
        Me.BotonLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BotonLogin.Font = New System.Drawing.Font("Ebrima", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonLogin.ForeColor = System.Drawing.Color.White
        Me.BotonLogin.Location = New System.Drawing.Point(37, 516)
        Me.BotonLogin.Name = "BotonLogin"
        Me.BotonLogin.Size = New System.Drawing.Size(350, 45)
        Me.BotonLogin.TabIndex = 7
        Me.BotonLogin.Text = "Ingresar"
        Me.BotonLogin.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 700)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(430, 10)
        Me.Panel2.TabIndex = 10
        '
        'PinCliente
        '
        Me.PinCliente.BackColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.PinCliente.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.PinCliente.Font = New System.Drawing.Font("Ebrima", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PinCliente.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.PinCliente.Location = New System.Drawing.Point(37, 434)
        Me.PinCliente.MaxLength = 4
        Me.PinCliente.Name = "PinCliente"
        Me.PinCliente.Size = New System.Drawing.Size(350, 22)
        Me.PinCliente.TabIndex = 11
        Me.PinCliente.Text = "2019"
        Me.PinCliente.UseSystemPasswordChar = True
        '
        'LabelPinCliente
        '
        Me.LabelPinCliente.AutoSize = True
        Me.LabelPinCliente.Font = New System.Drawing.Font("Ebrima", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelPinCliente.ForeColor = System.Drawing.Color.Silver
        Me.LabelPinCliente.Location = New System.Drawing.Point(33, 410)
        Me.LabelPinCliente.Name = "LabelPinCliente"
        Me.LabelPinCliente.Size = New System.Drawing.Size(87, 21)
        Me.LabelPinCliente.TabIndex = 12
        Me.LabelPinCliente.Text = "Pin_Cliente"
        '
        'FormSesión
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(430, 710)
        Me.Controls.Add(Me.LabelPinCliente)
        Me.Controls.Add(Me.PinCliente)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.BotonLogin)
        Me.Controls.Add(Me.PinCuenta)
        Me.Controls.Add(Me.LabelPin)
        Me.Controls.Add(Me.LogoSEW)
        Me.Controls.Add(Me.BarraTítulo)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FormSesión"
        Me.Opacity = 0.95R
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FormSesión"
        Me.BarraTítulo.ResumeLayout(False)
        Me.BarraTítulo.PerformLayout()
        CType(Me.LogoPicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnMinimize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BotonCerrar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LogoSEW, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BarraTítulo As Panel
    Friend WithEvents LogoSEW As PictureBox
    Friend WithEvents LabelPin As Label
    Friend WithEvents PinCuenta As TextBox
    Friend WithEvents BotonLogin As Button
    Friend WithEvents btnMinimize As PictureBox
    Friend WithEvents BotonCerrar As PictureBox
    Friend WithEvents LogoPicture As System.Windows.Forms.PictureBox
    Private WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents PinCliente As System.Windows.Forms.TextBox
    Friend WithEvents LabelPinCliente As System.Windows.Forms.Label
End Class
