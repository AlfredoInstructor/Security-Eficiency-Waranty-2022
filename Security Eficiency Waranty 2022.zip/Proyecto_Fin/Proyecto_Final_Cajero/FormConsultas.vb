﻿Imports MySql.Data.MySqlClient
Public Class FormConsultas
#Region "TextBoxs que solo acepten números"
    'Textbox que solo admite números y borrar
    Private Sub txtMS_TextKeypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtMS.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub
    'Textbox que solo admite números y borrar
    Private Sub TextSaldo_TextKeypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtSaldo.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub
    'Textbox que solo admite números y borrar
    Private Sub txtSuc_TextKeypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtSuc.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub
    'Textbox que solo admite números y borrar
    Private Sub txtCod_TextKeypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtCod.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub

#End Region
    'Buscar cuentas por Fecha de Apertura
    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        Dim FechaInicio As String = FechaMínima.Value.ToString("yyyy-MM-dd")
        Dim FechaFin As String = FechaMáxima.Value.ToString("yyyy-MM-dd")
        Dim SqlGridFecha As String = "Select * FROM cuenta WHERE Fecha_Apertura BETWEEN '" & FechaInicio & "' AND '" & FechaFin & "'"
        Dim DataGridCuentaFecha As New DataTable
        Dim AdaptadorFecha As New MySqlDataAdapter(SqlGridFecha, FormSesión.Conexión)
        Try
            If FechaFin < FechaInicio Then
                MsgBox("La Fecha Máxima(" & FechaFin & ")No puede ser menor que la Fecha Mínima(" & FechaInicio & ")", vbExclamation, "Advertencia")
            Else
                FormSesión.Conexión.Open()
                AdaptadorFecha.Fill(DataGridCuentaFecha)
                DataGridRegistros.DataSource = DataGridCuentaFecha
                AdaptadorFecha.Update(DataGridCuentaFecha)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        FormSesión.Conexión.Close()
    End Sub
    'Botón para volver al Form anterior
    Private Sub btnRetroceder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRetroceder.Click
        Me.Hide()
        FormMantenimiento.Show()
    End Sub

    'Buscar todas las cuentas
    Private Sub btnBuscarCuentas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscarCuentas.Click
        Dim SqlGridCuentas As String = "Select * FROM cuenta"
        Dim DataGridCuenta As New DataTable
        Dim AdaptadorCuentas As New MySqlDataAdapter(SqlGridCuentas, FormSesión.Conexión)
        Try
            FormSesión.Conexión.Open()
            AdaptadorCuentas.Fill(DataGridCuenta)
            DataGridRegistros.DataSource = DataGridCuenta
            AdaptadorCuentas.Update(DataGridCuenta)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        FormSesión.Conexión.Close()
    End Sub
    'Buscar cuentas con sucursal específica
    Private Sub btnSucursal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSucursal.Click
        Dim SqlGridSucursal As String = "Select * FROM cuenta WHERE Codigo_Sucursal = '" & txtCod.Text & "'"
        Dim DataGridCuentaSucursal As New DataTable
        Dim AdaptadorCuentasSuc As New MySqlDataAdapter(SqlGridSucursal, FormSesión.Conexión)
        Try
            If txtCod.Text = "" Then
                MsgBox("Ingrese la clave primaria", vbExclamation, "Advertencia")
            Else
                FormSesión.Conexión.Open()
                AdaptadorCuentasSuc.Fill(DataGridCuentaSucursal)
                DataGridRegistros.DataSource = DataGridCuentaSucursal
                AdaptadorCuentasSuc.Update(DataGridCuentaSucursal)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        FormSesión.Conexión.Close()
    End Sub
    'Buscar cuentas con fechas y sucursales en específico
    Private Sub btnBuscarFechaSucursal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscarFechaSucursal.Click
        Dim FechaInicio As String = FechaMínima.Value.ToString("yyyy-MM-dd")
        Dim FechaFin As String = FechaMáxima.Value.ToString("yyyy-MM-dd")
        Dim SqlGridSucursalFecha As String = "Select * FROM cuenta WHERE Fecha_Apertura BETWEEN '" & FechaInicio & "' AND '" & FechaFin & "'  AND  Codigo_Sucursal = '" & txtSuc.Text & "'"
        Dim DataGridFechaSucursal As New DataTable
        Dim AdaptadorCuentaFecSuc As New MySqlDataAdapter(SqlGridSucursalFecha, FormSesión.Conexión)
        Try
            If FechaFin < FechaInicio Then
                MsgBox("La Fecha Máxima(" & FechaFin & ")No puede ser menor que la Fecha Mínima(" & (FechaInicio) & ")", vbExclamation, "Advertencia")
            ElseIf txtCod.Text = "" Then
                MsgBox("Ingrese la clave primaria", vbExclamation, "Advertencia")
            Else
                FormSesión.Conexión.Open()
                AdaptadorCuentaFecSuc.Fill(DataGridFechaSucursal)
                DataGridRegistros.DataSource = DataGridFechaSucursal
                AdaptadorCuentaFecSuc.Update(DataGridFechaSucursal)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        FormSesión.Conexión.Close()
    End Sub
    'Buscar cuenta con saldo menor y moneda específica
    Private Sub btnMonedaSaldo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaldoMenor.Click
        Dim FechaInicio As String = FechaMínima.Value.ToString("yyyy-MM-dd")
        Dim FechaFin As String = FechaMáxima.Value.ToString("yyyy-MM-dd")
        Dim SqlGridSaldoMenor As String = "Select * FROM cuenta WHERE Fecha_Apertura BETWEEN '" & FechaInicio & "' AND '" & FechaFin & "'  AND  Saldo < " & txtMS.Text & " And Moneda = '" & ComboMonedaMenor.Text & "'"
        Dim DataGridSaldoMonMenor As New DataTable
        Dim AdaptadorSaldoMenor As New MySqlDataAdapter(SqlGridSaldoMenor, FormSesión.Conexión)
        Try
            If FechaFin < FechaInicio Then
                MsgBox("La Fecha Máxima(" & FechaFin & ")No puede ser menor que la Fecha Mínima(" & (FechaInicio) & ")", vbExclamation, "Advertencia")
            ElseIf ComboMonedaMenor.Text = "" And txtMS.Text = "" Then
                MsgBox("Ingrese los datos correctamente", vbExclamation, "Advertencia")
            Else
                FormSesión.Conexión.Open()
                AdaptadorSaldoMenor.Fill(DataGridSaldoMonMenor)
                DataGridRegistros.DataSource = DataGridSaldoMonMenor
                AdaptadorSaldoMenor.Update(DataGridSaldoMonMenor)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        FormSesión.Conexión.Close()
    End Sub

    'Buscar cuenta con saldo mayor y moneda específica
    Private Sub btnSaldoMayor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaldoMayor.Click
        Dim FechaInicio As String = FechaMínima.Value.ToString("yyyy-MM-dd")
        Dim FechaFin As String = FechaMáxima.Value.ToString("yyyy-MM-dd")
        Dim SqlGridSaldoMayor As String = "Select * FROM cuenta WHERE Fecha_Apertura BETWEEN '" & FechaInicio & "' AND '" & FechaFin & "'  AND  Saldo > " & txtSaldo.Text & " And Moneda = '" & ComboMonedaMayor.Text & "'"
        Dim DataGridSaldoMonMayor As New DataTable
        Dim AdaptadorSaldoMayor As New MySqlDataAdapter(SqlGridSaldoMayor, FormSesión.Conexión)
        Try
            If FechaFin < FechaInicio Then
                MsgBox("La Fecha Máxima(" & FechaFin & ")No puede ser menor que la Fecha Mínima(" & (FechaInicio) & ")", vbExclamation, "Advertencia")
            ElseIf ComboMonedaMayor.Text = "" And txtSaldo.Text = "" Then
                MsgBox("Ingrese los datos correctamente", vbExclamation, "Advertencia")
            Else
                FormSesión.Conexión.Open()
                AdaptadorSaldoMayor.Fill(DataGridSaldoMonMayor)
                DataGridRegistros.DataSource = DataGridSaldoMonMayor
                AdaptadorSaldoMayor.Update(DataGridSaldoMonMayor)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        FormSesión.Conexión.Close()
    End Sub
    'Buscar cuenta con moneda específica
    Private Sub btnCuentaMoneda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCuentaMoneda.Click
        Dim SqlGridMoneda As String = "Select * FROM cuenta WHERE Moneda = '" & ComboMonedaCuenta.Text & "'"
        Dim DataGridCuentaMoneda As New DataTable
        Dim AdaptadorCuentaMon As New MySqlDataAdapter(SqlGridMoneda, FormSesión.Conexión)
        Try
            If ComboMonedaCuenta.Text = "" Then
                MsgBox("Ingrese los datos correctamente", vbExclamation, "Advertencia")
            Else
                FormSesión.Conexión.Open()
                AdaptadorCuentaMon.Fill(DataGridCuentaMoneda)
                DataGridRegistros.DataSource = DataGridCuentaMoneda
                AdaptadorCuentaMon.Update(DataGridCuentaMoneda)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        FormSesión.Conexión.Close()
    End Sub
    'Buscar cuenta con tipo de cuenta(Caja de ahorros)específica
    Private Sub btnCaja_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCaja.Click
        Dim SqlGridCaja As String = "Select * FROM cuenta WHERE Tipo_Cuenta = '" & ComboCaja.Text & "'"
        Dim DataGridCaja As New DataTable
        Dim AdaptadorCaja As New MySqlDataAdapter(SqlGridCaja, FormSesión.Conexión)
        Try
            If ComboCaja.Text = "" Then
                MsgBox("Ingrese los datos correctamente", vbExclamation, "Advertencia")
            Else
                FormSesión.Conexión.Open()
                AdaptadorCaja.Fill(DataGridCaja)
                DataGridRegistros.DataSource = DataGridCaja
                AdaptadorCaja.Update(DataGridCaja)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        FormSesión.Conexión.Close()
    End Sub
    'Buscar cuenta con tipo de cuenta(Cuenta corriente)específica
    Private Sub btnCorriente_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCorriente.Click
        Dim SqlGridCorriente As String = "Select * FROM cuenta WHERE Tipo_Cuenta = '" & ComboCorriente.Text & "'"
        Dim DataGridCorriente As New DataTable
        Dim AdaptadorCorriente As New MySqlDataAdapter(SqlGridCorriente, FormSesión.Conexión)
        Try
            If ComboCorriente.Text = "" Then
                MsgBox("Ingrese los datos correctamente", vbExclamation, "Advertencia")
            Else
                FormSesión.Conexión.Open()
                AdaptadorCorriente.Fill(DataGridCorriente)
                DataGridRegistros.DataSource = DataGridCorriente
                AdaptadorCorriente.Update(DataGridCorriente)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        FormSesión.Conexión.Close()
    End Sub

    Private Sub FormConsultas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class