﻿Imports MySql.Data.MySqlClient
Public Class FormModificarTransacción
#Region "TextBoxs que solo acepten Números"
    'TextboxPin que solo admite números y borrar
    Private Sub TextBoxPin_TextKeypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxPin.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub
    Private Sub TextBoxCli_TextKeypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxID.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub
#End Region
#Region "ComboBoxs que solo acepten letras"
    'Textbox Tipo de cuenta
    Private Sub ComboTipo_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ComboTipo.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If

    End Sub


    'TextBox Moneda 
    Private Sub ComboMoneda_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ComboMoneda.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
        ComboMoneda.Text = Trim(Replace(ComboMoneda.Text, " ", ""))
        ComboMoneda.Select(ComboMoneda.Text.Length, 0)
    End Sub
#End Region
    'Modificar registros
    Private Sub btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModificar.Click
        'Er es una variable de Error que nos señala cuando se repite la misma clave primaria y finaliza la tarea
        Dim FechaTrans As String = FechaAltaTrans.Value.ToString("yyyy-MM-dd HH:mm:ss")
        Dim Er As Integer = 0
        Dim SqlMT As String = "UPDATE cuenta SET Monto = '" & TextBoxMonto.Text & "', Tipo = '" & ComboTipo.Text & "', Moneda = '" & ComboMoneda.Text & "',Pin_Cuenta = '" & TextBoxPin.Text & "', '" & FechaTrans & "' WHERE ID_TN = '" & TextBoxID.Text & "'"
        Dim ComandoModTransacción As New MySqlCommand(SqlMT, FormSesión.Conexión)
        FormSesión.Conexión.Open()
        If TextBoxID.Text = "" Then
            MsgBox("Ingrese clave primaria", vbExclamation, "Advertencia")
            Er = 1
            FormSesión.Conexión.Close()
        ElseIf ComboMoneda.Text = "" Or ComboTipo.Text = "" Or TextBoxMonto.Text = "" Or TextBoxPin.Text = "" Then
            MsgBox("Ingrese todos los registros correctamente", vbExclamation, "Advertencia")
            Er = 1
            FormSesión.Conexión.Close()
        End If
        FormSesión.Conexión.Close()
        'Casos al momento de ingresar o no los datos
        If Er = 0 Then
            Try
                FormSesión.Conexión.Open()
                Dim Respuesta As Integer = MsgBox("Desea modificar los siguientes datos?", vbYesNo + vbExclamation, "Advertencia")
                Select Case Respuesta
                    Case vbYes
                        MsgBox("Se han modificado los datos correctamente", vbExclamation, "Advertencia")
                        ComandoModTransacción.ExecuteNonQuery()
                    Case vbNo
                        MsgBox("Se ha cancelado la operación", vbExclamation, "Advertencia")
                End Select
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            FormSesión.Conexión.Close()
        End If
    End Sub
    'Buscar si existe una clave primaria
    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        Dim DTTransaccion As New DataTable
        Dim SqlMT As String = "SELECT * FROM transaccion WHERE ID_TN = '" & TextBoxID.Text & "'"
        Dim ComandoModTransacción = New MySqlCommand(SqlMT, FormSesión.Conexión)
        FormSesión.Conexión.Open()
        Dim LectorMTrans = New MySqlDataAdapter(ComandoModTransacción)
        LectorMTrans.Fill(DTTransaccion)
        If TextBoxID.Text = "" Then
            MsgBox("Ingrese la clave primaria", vbExclamation, "Advertencia")
        ElseIf DTTransaccion.Rows.Count = 0 Then
            MsgBox("No existen los datos", vbExclamation, "Advertencia")
        Else
            MsgBox("Existe la Clave Primaria", vbExclamation, "Advertencia")
            TextBoxID.Text = DTTransaccion.Rows(0)("ID_TN").ToString()
            TextBoxPin.Text = DTTransaccion.Rows(0)("Pin_Cuenta").ToString()
            TextBoxMonto.Text = DTTransaccion.Rows(0)("Monto").ToString()
            ComboTipo.Text = DTTransaccion.Rows(0)("Tipo").ToString()
            ComboMoneda.Text = DTTransaccion.Rows(0)("Moneda").ToString()
        End If
        FormSesión.Conexión.Close()
    End Sub
    'Borra todo lo escrito en los campos de texto
    Private Sub btnBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
        Dim Respuesta As String = MsgBox("Desea borrar los datos ingresados?", vbYesNo + vbExclamation, "Advertencia")
        Select Case Respuesta
            Case vbYes
                MsgBox("Se han borrado los datos correctamente", vbExclamation, "Advertencia")
                TextBoxID.Text = ""
                ComboMoneda.Text = ""
                TextBoxPin.Text = ""
                ComboTipo.Text = ""
                TextBoxMonto.Text = ""
            Case vbNo
                MsgBox("Se ha cancelado la operación", vbExclamation, "Advertencia")
        End Select
    End Sub

    Private Sub FechaAltaTrans_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FechaAltaTrans.ValueChanged

    End Sub
End Class
