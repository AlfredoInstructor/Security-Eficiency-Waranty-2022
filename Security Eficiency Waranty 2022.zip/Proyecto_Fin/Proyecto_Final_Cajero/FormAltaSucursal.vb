﻿Imports MySql.Data.MySqlClient
Public Class FormAltaSucursal
    'TextboxCod que solo admite números y borrar
    Private Sub Cod_TextKeypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxCód.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub

    Private Sub btnInsertar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsertar.Click
        'Er es una variable de Error que nos señala cuando se repite la misma clave primaria
        Dim Er As Integer = 0
        Dim Comando As MySqlCommand = New MySqlCommand
        Comando.Connection = FormSesión.Conexión
        Try
            FormSesión.Conexión.Open()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Comando.CommandText = "SELECT * FROM sucursal WHERE Cod_Sucursal = '" & TextBoxCód.Text & "'"
        Dim Resultado As MySqlDataReader
        Resultado = Comando.ExecuteReader
        If Resultado.HasRows Then
            MsgBox("Ya existe la clave primaria ingresada", vbExclamation, "Advertencia")
            Er = 1
            Resultado.Close()
        ElseIf TextBoxCód.Text = "" Then
            MsgBox("Ingrese clave primaria", vbExclamation, "Advertencia")
            Resultado.Close()
            Er = 1
        ElseIf TextBoxNom.Text = "" Or TextBoxDireccion.Text = "" Then
            MsgBox("Ingrese todos los registros correctamente", vbExclamation, "Advertencia")
            Resultado.Close()
            Er = 1
        End If
        FormSesión.Conexión.Close()
        'Insertar registros en la base de datos
        If Er = 0 Then
            Dim SqlAS As String = "INSERT INTO sucursal(Cod_Sucursal,Nombre,Direccion) VALUES(" & TextBoxCód.Text & ", '" & TextBoxNom.Text & "', '" & TextBoxDireccion.Text & "')"
            Dim Command As New MySqlCommand(SqlAS, FormSesión.Conexión)
            Try
                FormSesión.Conexión.Open()
                'Casos al momento de ingresar o no los datos
                Dim Respuesta As Integer = MsgBox("Desea ingresar los siguientes datos?", vbYesNo + vbExclamation, "Advertencia")
                Select Case Respuesta
                    Case vbYes
                        Command.ExecuteNonQuery()
                        MsgBox("Se han ingresado los datos correctamente", vbExclamation, "Advertencia")
                    Case vbNo
                        MsgBox("Se ha cancelado la operación", vbExclamation, "Advertencia")
                End Select
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            FormSesión.Conexión.Close()
        End If

    End Sub


    'Borra todo lo escrito en los TextBoxs
    Private Sub btnBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
        Dim Respuesta As Integer = MsgBox("Desea borrar los datos ingresados?", vbYesNo + vbExclamation, "Advertencia")
        Select Case Respuesta
            Case vbYes
                MsgBox("Se han borrado los datos correctamente", vbExclamation, "Advertencia")
                TextBoxCód.Text = ""
                TextBoxNom.Text = ""
                TextBoxDireccion.Text = ""
            Case vbNo
                MsgBox("Se ha cancelado la operación", vbExclamation, "Advertencia")
        End Select


    End Sub
    'Buscar registros de la clave primaria 
    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        Dim DTSuc As New DataTable
        Dim SqlBS As String = "SELECT * FROM sucursal WHERE Cod_Sucursal = '" & TextBoxCód.Text & "'"
        Dim SqlComandoSuc = New MySqlCommand(SqlBS, FormSesión.Conexión)
        FormSesión.Conexión.Open()
        Dim LectorSuc = New MySqlDataAdapter(SqlComandoSuc)
        LectorSuc.Fill(DTSuc)
        If TextBoxCód.Text = "" Then
            MsgBox("Ingrese la clave primaria", vbExclamation, "Advertencia")
        ElseIf DTSuc.Rows.Count = 0 Then
            MsgBox("No existen los datos", vbExclamation, "Advertencia")
        Else
            MsgBox("Existe la Clave Primaria", vbExclamation, "Advertencia")
            TextBoxCód.Text = DTSuc.Rows(0)("Cod_Sucursal").ToString()
            TextBoxNom.Text = DTSuc.Rows(0)("Nombre").ToString()
            TextBoxDireccion.Text = DTSuc.Rows(0)("Direccion").ToString()
        End If
        FormSesión.Conexión.Close()
    End Sub


    Private Sub FormAltaSucursal_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class