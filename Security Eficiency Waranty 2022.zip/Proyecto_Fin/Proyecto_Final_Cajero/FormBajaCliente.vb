﻿Imports MySql.Data.MySqlClient
Public Class FormBajaCliente
    Private Sub btnBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
        Dim SqlBCLI As String = "DELETE FROM cliente WHERE Pin_Cliente='" & TextPin.Text & "'"
        Dim Comando As New MySqlCommand(SqlBCLI, FormSesión.Conexión)
        Try
            FormSesión.Conexión.Open()
            'Casos al momento de borrar o no un dato
            Dim Respuesta As Integer = MsgBox("Desea borrar los datos ingresados?", vbYesNo + vbExclamation, "Advertencia")
            Select Case Respuesta
                Case vbYes
                    Comando.ExecuteNonQuery()
                    MsgBox("Se han borrado los datos correctamente", vbExclamation, "Advertencia")
                Case vbNo
                    MsgBox("Se ha cancelado la operación", vbExclamation, "Advertencia")
            End Select
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Advertencia")
        End Try
        FormSesión.Conexión.Close()
    End Sub


    Private Sub FormBajaCliente_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub



    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        Dim DTBajaCliente As New DataTable
        Dim SqlBCliente As String = "SELECT * FROM cliente WHERE Pin_Cliente = '" & TextPin.Text & "'"
        Dim SqlComandoCliente = New MySqlCommand(SqlBCliente, FormSesión.Conexión)
        FormSesión.Conexión.Open()
        Dim LectorCuenta = New MySqlDataAdapter(SqlComandoCliente)
        LectorCuenta.Fill(DTBajaCliente)

        If TextPin.Text = "" Then
            MsgBox("Ingrese la clave primaria", vbExclamation, "Advertencia")
        ElseIf DTBajaCliente.Rows.Count = 0 Then
            MsgBox("No existen los datos", vbExclamation, "Advertencia")
        Else
            MsgBox("Existe la Clave Primaria", vbExclamation, "Advertencia")
        End If
        FormSesión.Conexión.Close()
    End Sub


    Private Sub btnVolver_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub
End Class