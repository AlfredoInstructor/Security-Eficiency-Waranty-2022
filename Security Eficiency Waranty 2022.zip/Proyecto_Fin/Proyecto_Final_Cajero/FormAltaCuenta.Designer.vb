﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormAltaCuenta
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormAltaCuenta))
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.PanelCuenta = New System.Windows.Forms.Panel()
        Me.btnInsertar = New System.Windows.Forms.Button()
        Me.TextBoxPin = New System.Windows.Forms.TextBox()
        Me.TextBoxSaldo = New System.Windows.Forms.TextBox()
        Me.LabelPin = New System.Windows.Forms.Label()
        Me.LabelTipo = New System.Windows.Forms.Label()
        Me.LabelMoneda = New System.Windows.Forms.Label()
        Me.LabelFecha = New System.Windows.Forms.Label()
        Me.LabelSucursal = New System.Windows.Forms.Label()
        Me.TextBoxSuc = New System.Windows.Forms.TextBox()
        Me.btnBorrar = New System.Windows.Forms.Button()
        Me.TextBoxCli = New System.Windows.Forms.TextBox()
        Me.LabelCliente = New System.Windows.Forms.Label()
        Me.ComboMoneda = New System.Windows.Forms.ComboBox()
        Me.ComboTipo = New System.Windows.Forms.ComboBox()
        Me.btnBuscar = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LabelTítulo = New System.Windows.Forms.Label()
        Me.FechaAltaCuenta = New System.Windows.Forms.DateTimePicker()
        Me.LabelSaldo = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'textBox1
        '
        Me.textBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.textBox1.Location = New System.Drawing.Point(109, 115)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(239, 26)
        Me.textBox1.TabIndex = 9
        '
        'PanelCuenta
        '
        Me.PanelCuenta.BackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(21, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.PanelCuenta.Location = New System.Drawing.Point(0, 649)
        Me.PanelCuenta.Name = "PanelCuenta"
        Me.PanelCuenta.Size = New System.Drawing.Size(1123, 100)
        Me.PanelCuenta.TabIndex = 61
        '
        'btnInsertar
        '
        Me.btnInsertar.BackColor = System.Drawing.Color.Red
        Me.btnInsertar.FlatAppearance.BorderSize = 0
        Me.btnInsertar.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnInsertar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnInsertar.ForeColor = System.Drawing.Color.LightGray
        Me.btnInsertar.Location = New System.Drawing.Point(135, 512)
        Me.btnInsertar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnInsertar.Name = "btnInsertar"
        Me.btnInsertar.Size = New System.Drawing.Size(206, 54)
        Me.btnInsertar.TabIndex = 41
        Me.btnInsertar.Text = "Insertar"
        Me.btnInsertar.UseVisualStyleBackColor = False
        '
        'TextBoxPin
        '
        Me.TextBoxPin.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.TextBoxPin.Location = New System.Drawing.Point(314, 83)
        Me.TextBoxPin.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxPin.MaxLength = 10
        Me.TextBoxPin.Name = "TextBoxPin"
        Me.TextBoxPin.Size = New System.Drawing.Size(330, 26)
        Me.TextBoxPin.TabIndex = 42
        '
        'TextBoxSaldo
        '
        Me.TextBoxSaldo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.TextBoxSaldo.Location = New System.Drawing.Point(314, 143)
        Me.TextBoxSaldo.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxSaldo.Name = "TextBoxSaldo"
        Me.TextBoxSaldo.Size = New System.Drawing.Size(330, 26)
        Me.TextBoxSaldo.TabIndex = 43
        '
        'LabelPin
        '
        Me.LabelPin.AutoSize = True
        Me.LabelPin.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.LabelPin.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelPin.Location = New System.Drawing.Point(131, 89)
        Me.LabelPin.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelPin.Name = "LabelPin"
        Me.LabelPin.Size = New System.Drawing.Size(92, 20)
        Me.LabelPin.TabIndex = 44
        Me.LabelPin.Text = "Pin_Cuenta"
        '
        'LabelTipo
        '
        Me.LabelTipo.AutoSize = True
        Me.LabelTipo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.LabelTipo.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelTipo.Location = New System.Drawing.Point(130, 217)
        Me.LabelTipo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelTipo.Name = "LabelTipo"
        Me.LabelTipo.Size = New System.Drawing.Size(100, 20)
        Me.LabelTipo.TabIndex = 45
        Me.LabelTipo.Text = "Tipo_Cuenta"
        '
        'LabelMoneda
        '
        Me.LabelMoneda.AutoSize = True
        Me.LabelMoneda.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.LabelMoneda.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelMoneda.Location = New System.Drawing.Point(130, 280)
        Me.LabelMoneda.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelMoneda.Name = "LabelMoneda"
        Me.LabelMoneda.Size = New System.Drawing.Size(67, 20)
        Me.LabelMoneda.TabIndex = 46
        Me.LabelMoneda.Text = "Moneda"
        '
        'LabelFecha
        '
        Me.LabelFecha.AutoSize = True
        Me.LabelFecha.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.LabelFecha.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelFecha.Location = New System.Drawing.Point(130, 346)
        Me.LabelFecha.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelFecha.Name = "LabelFecha"
        Me.LabelFecha.Size = New System.Drawing.Size(125, 20)
        Me.LabelFecha.TabIndex = 47
        Me.LabelFecha.Text = "Fecha_Apertura"
        '
        'LabelSucursal
        '
        Me.LabelSucursal.AutoSize = True
        Me.LabelSucursal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.LabelSucursal.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelSucursal.Location = New System.Drawing.Point(130, 404)
        Me.LabelSucursal.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelSucursal.Name = "LabelSucursal"
        Me.LabelSucursal.Size = New System.Drawing.Size(130, 20)
        Me.LabelSucursal.TabIndex = 48
        Me.LabelSucursal.Text = "Código_Sucursal"
        '
        'TextBoxSuc
        '
        Me.TextBoxSuc.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.TextBoxSuc.Location = New System.Drawing.Point(314, 398)
        Me.TextBoxSuc.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxSuc.MaxLength = 8
        Me.TextBoxSuc.Name = "TextBoxSuc"
        Me.TextBoxSuc.Size = New System.Drawing.Size(330, 26)
        Me.TextBoxSuc.TabIndex = 49
        '
        'btnBorrar
        '
        Me.btnBorrar.BackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnBorrar.FlatAppearance.BorderSize = 0
        Me.btnBorrar.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBorrar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnBorrar.ForeColor = System.Drawing.Color.LightGray
        Me.btnBorrar.Location = New System.Drawing.Point(376, 512)
        Me.btnBorrar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnBorrar.Name = "btnBorrar"
        Me.btnBorrar.Size = New System.Drawing.Size(206, 54)
        Me.btnBorrar.TabIndex = 51
        Me.btnBorrar.Text = "Borrar "
        Me.btnBorrar.UseVisualStyleBackColor = False
        '
        'TextBoxCli
        '
        Me.TextBoxCli.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.TextBoxCli.Location = New System.Drawing.Point(314, 458)
        Me.TextBoxCli.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxCli.MaxLength = 4
        Me.TextBoxCli.Name = "TextBoxCli"
        Me.TextBoxCli.Size = New System.Drawing.Size(330, 26)
        Me.TextBoxCli.TabIndex = 52
        '
        'LabelCliente
        '
        Me.LabelCliente.AutoSize = True
        Me.LabelCliente.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.LabelCliente.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelCliente.Location = New System.Drawing.Point(130, 464)
        Me.LabelCliente.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelCliente.Name = "LabelCliente"
        Me.LabelCliente.Size = New System.Drawing.Size(89, 20)
        Me.LabelCliente.TabIndex = 53
        Me.LabelCliente.Text = "Pin_Cliente"
        '
        'ComboMoneda
        '
        Me.ComboMoneda.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.ComboMoneda.FormattingEnabled = True
        Me.ComboMoneda.Items.AddRange(New Object() {"Pesos", "Dólares"})
        Me.ComboMoneda.Location = New System.Drawing.Point(314, 272)
        Me.ComboMoneda.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ComboMoneda.Name = "ComboMoneda"
        Me.ComboMoneda.Size = New System.Drawing.Size(330, 28)
        Me.ComboMoneda.TabIndex = 54
        '
        'ComboTipo
        '
        Me.ComboTipo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.ComboTipo.FormattingEnabled = True
        Me.ComboTipo.Items.AddRange(New Object() {"Cuenta corriente en pesos", "Cuenta corriente en dólares", "Caja de ahorros en pesos", "Caja de ahorros en dólares"})
        Me.ComboTipo.Location = New System.Drawing.Point(314, 209)
        Me.ComboTipo.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ComboTipo.Name = "ComboTipo"
        Me.ComboTipo.Size = New System.Drawing.Size(330, 28)
        Me.ComboTipo.TabIndex = 55
        '
        'btnBuscar
        '
        Me.btnBuscar.BackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBuscar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnBuscar.ForeColor = System.Drawing.Color.LightGray
        Me.btnBuscar.Location = New System.Drawing.Point(675, 115)
        Me.btnBuscar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnBuscar.Name = "btnBuscar"
        Me.btnBuscar.Size = New System.Drawing.Size(206, 54)
        Me.btnBuscar.TabIndex = 56
        Me.btnBuscar.Text = "Buscar"
        Me.btnBuscar.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label1.ForeColor = System.Drawing.SystemColors.Control
        Me.Label1.Location = New System.Drawing.Point(652, 89)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(252, 20)
        Me.Label1.TabIndex = 57
        Me.Label1.Text = "Averiguar si existe la clave primaria"
        '
        'LabelTítulo
        '
        Me.LabelTítulo.AutoSize = True
        Me.LabelTítulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!)
        Me.LabelTítulo.ForeColor = System.Drawing.Color.Red
        Me.LabelTítulo.Location = New System.Drawing.Point(192, 20)
        Me.LabelTítulo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelTítulo.Name = "LabelTítulo"
        Me.LabelTítulo.Size = New System.Drawing.Size(246, 37)
        Me.LabelTítulo.TabIndex = 58
        Me.LabelTítulo.Text = "Ingresar Cuenta"
        '
        'FechaAltaCuenta
        '
        Me.FechaAltaCuenta.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FechaAltaCuenta.Location = New System.Drawing.Point(314, 340)
        Me.FechaAltaCuenta.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.FechaAltaCuenta.Name = "FechaAltaCuenta"
        Me.FechaAltaCuenta.Size = New System.Drawing.Size(330, 26)
        Me.FechaAltaCuenta.TabIndex = 59
        '
        'LabelSaldo
        '
        Me.LabelSaldo.AutoSize = True
        Me.LabelSaldo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSaldo.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelSaldo.Location = New System.Drawing.Point(130, 149)
        Me.LabelSaldo.Name = "LabelSaldo"
        Me.LabelSaldo.Size = New System.Drawing.Size(50, 20)
        Me.LabelSaldo.TabIndex = 60
        Me.LabelSaldo.Text = "Saldo"
        '
        'FormAltaCuenta
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1065, 595)
        Me.Controls.Add(Me.PanelCuenta)
        Me.Controls.Add(Me.LabelSaldo)
        Me.Controls.Add(Me.FechaAltaCuenta)
        Me.Controls.Add(Me.LabelTítulo)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnBuscar)
        Me.Controls.Add(Me.ComboTipo)
        Me.Controls.Add(Me.ComboMoneda)
        Me.Controls.Add(Me.LabelCliente)
        Me.Controls.Add(Me.TextBoxCli)
        Me.Controls.Add(Me.btnBorrar)
        Me.Controls.Add(Me.TextBoxSuc)
        Me.Controls.Add(Me.LabelSucursal)
        Me.Controls.Add(Me.LabelFecha)
        Me.Controls.Add(Me.LabelMoneda)
        Me.Controls.Add(Me.LabelTipo)
        Me.Controls.Add(Me.LabelPin)
        Me.Controls.Add(Me.TextBoxSaldo)
        Me.Controls.Add(Me.TextBoxPin)
        Me.Controls.Add(Me.btnInsertar)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "FormAltaCuenta"
        Me.Text = "Crear Cuentas"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents PanelCuenta As System.Windows.Forms.Panel
    Friend WithEvents btnInsertar As System.Windows.Forms.Button
    Friend WithEvents TextBoxPin As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxSaldo As System.Windows.Forms.TextBox
    Friend WithEvents LabelPin As System.Windows.Forms.Label
    Friend WithEvents LabelTipo As System.Windows.Forms.Label
    Friend WithEvents LabelMoneda As System.Windows.Forms.Label
    Friend WithEvents LabelFecha As System.Windows.Forms.Label
    Friend WithEvents LabelSucursal As System.Windows.Forms.Label
    Friend WithEvents TextBoxSuc As System.Windows.Forms.TextBox
    Friend WithEvents btnBorrar As System.Windows.Forms.Button
    Friend WithEvents TextBoxCli As System.Windows.Forms.TextBox
    Friend WithEvents LabelCliente As System.Windows.Forms.Label
    Friend WithEvents ComboMoneda As System.Windows.Forms.ComboBox
    Friend WithEvents ComboTipo As System.Windows.Forms.ComboBox
    Friend WithEvents btnBuscar As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LabelTítulo As System.Windows.Forms.Label
    Friend WithEvents FechaAltaCuenta As System.Windows.Forms.DateTimePicker
    Friend WithEvents LabelSaldo As System.Windows.Forms.Label
End Class
