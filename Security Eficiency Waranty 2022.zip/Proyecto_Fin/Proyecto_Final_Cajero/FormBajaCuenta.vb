﻿Imports MySql.Data.MySqlClient
Public Class FormBajaCuenta
    Private Sub TextBoxPin_TextKeypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextPin.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub
    Private Sub Borrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
        Dim SqlBC As String = "DELETE FROM cuenta WHERE Pin_Cuenta='" & TextPin.Text & "'"
        Dim ComandoBC As New MySqlCommand(SqlBC, FormSesión.Conexión)
        Try
            FormSesión.Conexión.Open()
            'Casos al momento de borrar o no un dato
            Dim Respuesta As Integer = MsgBox("Desea borrar los datos ingresados?", vbYesNo + vbExclamation, "Advertencia")
            Select Case Respuesta
                Case vbYes
                    ComandoBC.ExecuteNonQuery()
                    MsgBox("Se han borrado los datos correctamente", vbExclamation, "Advertencia")
                Case vbNo
                    MsgBox("Se ha cancelado la operación", vbExclamation, "Advertencia")
            End Select
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Advertencia")
        End Try
        FormSesión.Conexión.Close()
    End Sub


    Private Sub FormBajaCuenta_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
    'Buscar clave primaria
    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        Dim DTBajaCuenta As New DataTable
        Dim SqlBCuenta As String = "SELECT * FROM cuenta WHERE Pin_Cuenta = '" & TextPin.Text & "'"
        Dim SqlComandoCuenta = New MySqlCommand(SqlBCuenta, FormSesión.Conexión)
        FormSesión.Conexión.Open()
        Dim LectorCuenta = New MySqlDataAdapter(SqlComandoCuenta)
        LectorCuenta.Fill(DTBajaCuenta)

        If TextPin.Text = "" Then
            MsgBox("Ingrese la clave primaria", vbExclamation, "Advertencia")
        ElseIf DTBajaCuenta.Rows.Count = 0 Then
            MsgBox("No existen los datos", vbExclamation, "Advertencia")
        Else
            MsgBox("Existe la Clave Primaria", vbExclamation, "Advertencia")
        End If
        FormSesión.Conexión.Close()
    End Sub

    Private Sub btnVolver_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub
End Class