﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormConsultas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormConsultas))
        Me.btnRetroceder = New System.Windows.Forms.Button()
        Me.DataGridRegistros = New System.Windows.Forms.DataGridView()
        Me.btnBuscar = New System.Windows.Forms.Button()
        Me.LabelFechaMin = New System.Windows.Forms.Label()
        Me.FechaMínima = New System.Windows.Forms.DateTimePicker()
        Me.FechaMáxima = New System.Windows.Forms.DateTimePicker()
        Me.LabelFechaMax = New System.Windows.Forms.Label()
        Me.btnBuscarCuentas = New System.Windows.Forms.Button()
        Me.txtCod = New System.Windows.Forms.TextBox()
        Me.btnSucursal = New System.Windows.Forms.Button()
        Me.LabelSucursal = New System.Windows.Forms.Label()
        Me.LabelTítulo = New System.Windows.Forms.Label()
        Me.btnBuscarFechaSucursal = New System.Windows.Forms.Button()
        Me.LabelSucursalFec = New System.Windows.Forms.Label()
        Me.txtSuc = New System.Windows.Forms.TextBox()
        Me.btnSaldoMenor = New System.Windows.Forms.Button()
        Me.txtMS = New System.Windows.Forms.TextBox()
        Me.LabelSaldoMenor = New System.Windows.Forms.Label()
        Me.LabelMoneda = New System.Windows.Forms.Label()
        Me.GrupoSaldoMenor = New System.Windows.Forms.GroupBox()
        Me.ComboMonedaMenor = New System.Windows.Forms.ComboBox()
        Me.GrupoSaldoMayor = New System.Windows.Forms.GroupBox()
        Me.ComboMonedaMayor = New System.Windows.Forms.ComboBox()
        Me.btnSaldoMayor = New System.Windows.Forms.Button()
        Me.LabelMoneda2 = New System.Windows.Forms.Label()
        Me.LabelSaldoMayor = New System.Windows.Forms.Label()
        Me.txtSaldo = New System.Windows.Forms.TextBox()
        Me.GrupoCuentaSucursal = New System.Windows.Forms.GroupBox()
        Me.btnCuentaMoneda = New System.Windows.Forms.Button()
        Me.GrupoFecha = New System.Windows.Forms.GroupBox()
        Me.GrupoCuentas = New System.Windows.Forms.GroupBox()
        Me.GrupoCaja = New System.Windows.Forms.GroupBox()
        Me.btnCaja = New System.Windows.Forms.Button()
        Me.ComboCaja = New System.Windows.Forms.ComboBox()
        Me.GrupoCorriente = New System.Windows.Forms.GroupBox()
        Me.btnCorriente = New System.Windows.Forms.Button()
        Me.ComboCorriente = New System.Windows.Forms.ComboBox()
        Me.ComboMonedaCuenta = New System.Windows.Forms.ComboBox()
        Me.GrupoMoneda = New System.Windows.Forms.GroupBox()
        CType(Me.DataGridRegistros, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GrupoSaldoMenor.SuspendLayout()
        Me.GrupoSaldoMayor.SuspendLayout()
        Me.GrupoCuentaSucursal.SuspendLayout()
        Me.GrupoFecha.SuspendLayout()
        Me.GrupoCuentas.SuspendLayout()
        Me.GrupoCaja.SuspendLayout()
        Me.GrupoCorriente.SuspendLayout()
        Me.GrupoMoneda.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnRetroceder
        '
        Me.btnRetroceder.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(67, Byte), Integer))
        Me.btnRetroceder.FlatAppearance.BorderSize = 0
        Me.btnRetroceder.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRetroceder.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRetroceder.ForeColor = System.Drawing.Color.LightGray
        Me.btnRetroceder.Location = New System.Drawing.Point(1230, 580)
        Me.btnRetroceder.Name = "btnRetroceder"
        Me.btnRetroceder.Size = New System.Drawing.Size(116, 39)
        Me.btnRetroceder.TabIndex = 30
        Me.btnRetroceder.Text = "Retroceder"
        Me.btnRetroceder.UseVisualStyleBackColor = False
        '
        'DataGridRegistros
        '
        Me.DataGridRegistros.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.DataGridRegistros.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(5, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.DataGridRegistros.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DataGridRegistros.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(45, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.LightGray
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(16, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(45, Byte), Integer))
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridRegistros.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridRegistros.ColumnHeadersHeight = 30
        Me.DataGridRegistros.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridRegistros.EnableHeadersVisualStyles = False
        Me.DataGridRegistros.GridColor = System.Drawing.Color.MidnightBlue
        Me.DataGridRegistros.Location = New System.Drawing.Point(1, 149)
        Me.DataGridRegistros.Name = "DataGridRegistros"
        Me.DataGridRegistros.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(45, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(16, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(45, Byte), Integer))
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridRegistros.RowHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridRegistros.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(45, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.LightGray
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(16, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.DataGridRegistros.RowsDefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridRegistros.Size = New System.Drawing.Size(835, 433)
        Me.DataGridRegistros.TabIndex = 31
        '
        'btnBuscar
        '
        Me.btnBuscar.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(67, Byte), Integer))
        Me.btnBuscar.FlatAppearance.BorderSize = 0
        Me.btnBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBuscar.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBuscar.ForeColor = System.Drawing.Color.LightGray
        Me.btnBuscar.Location = New System.Drawing.Point(6, 27)
        Me.btnBuscar.Name = "btnBuscar"
        Me.btnBuscar.Size = New System.Drawing.Size(81, 64)
        Me.btnBuscar.TabIndex = 33
        Me.btnBuscar.Text = "Buscar por fecha"
        Me.btnBuscar.UseVisualStyleBackColor = False
        '
        'LabelFechaMin
        '
        Me.LabelFechaMin.AutoSize = True
        Me.LabelFechaMin.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelFechaMin.ForeColor = System.Drawing.Color.LightGray
        Me.LabelFechaMin.Location = New System.Drawing.Point(101, 22)
        Me.LabelFechaMin.Name = "LabelFechaMin"
        Me.LabelFechaMin.Size = New System.Drawing.Size(101, 18)
        Me.LabelFechaMin.TabIndex = 34
        Me.LabelFechaMin.Text = "Fecha Mínima"
        '
        'FechaMínima
        '
        Me.FechaMínima.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FechaMínima.Location = New System.Drawing.Point(215, 22)
        Me.FechaMínima.Name = "FechaMínima"
        Me.FechaMínima.Size = New System.Drawing.Size(240, 23)
        Me.FechaMínima.TabIndex = 36
        Me.FechaMínima.Value = New Date(2019, 1, 1, 0, 0, 0, 0)
        '
        'FechaMáxima
        '
        Me.FechaMáxima.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FechaMáxima.Location = New System.Drawing.Point(215, 68)
        Me.FechaMáxima.Name = "FechaMáxima"
        Me.FechaMáxima.Size = New System.Drawing.Size(240, 23)
        Me.FechaMáxima.TabIndex = 37
        Me.FechaMáxima.Value = New Date(2019, 12, 31, 0, 0, 0, 0)
        '
        'LabelFechaMax
        '
        Me.LabelFechaMax.AutoSize = True
        Me.LabelFechaMax.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelFechaMax.ForeColor = System.Drawing.Color.LightGray
        Me.LabelFechaMax.Location = New System.Drawing.Point(98, 68)
        Me.LabelFechaMax.Name = "LabelFechaMax"
        Me.LabelFechaMax.Size = New System.Drawing.Size(105, 18)
        Me.LabelFechaMax.TabIndex = 38
        Me.LabelFechaMax.Text = "Fecha Máxima"
        '
        'btnBuscarCuentas
        '
        Me.btnBuscarCuentas.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(67, Byte), Integer))
        Me.btnBuscarCuentas.FlatAppearance.BorderSize = 0
        Me.btnBuscarCuentas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBuscarCuentas.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBuscarCuentas.ForeColor = System.Drawing.Color.LightGray
        Me.btnBuscarCuentas.Location = New System.Drawing.Point(35, 22)
        Me.btnBuscarCuentas.Name = "btnBuscarCuentas"
        Me.btnBuscarCuentas.Size = New System.Drawing.Size(81, 64)
        Me.btnBuscarCuentas.TabIndex = 39
        Me.btnBuscarCuentas.Text = "Buscar todas las cuentas"
        Me.btnBuscarCuentas.UseVisualStyleBackColor = False
        '
        'txtCod
        '
        Me.txtCod.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCod.Location = New System.Drawing.Point(200, 32)
        Me.txtCod.MaxLength = 8
        Me.txtCod.Name = "txtCod"
        Me.txtCod.Size = New System.Drawing.Size(84, 23)
        Me.txtCod.TabIndex = 40
        '
        'btnSucursal
        '
        Me.btnSucursal.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(67, Byte), Integer))
        Me.btnSucursal.FlatAppearance.BorderSize = 0
        Me.btnSucursal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSucursal.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSucursal.ForeColor = System.Drawing.Color.LightGray
        Me.btnSucursal.Location = New System.Drawing.Point(6, 19)
        Me.btnSucursal.Name = "btnSucursal"
        Me.btnSucursal.Size = New System.Drawing.Size(124, 46)
        Me.btnSucursal.TabIndex = 41
        Me.btnSucursal.Text = "Buscar cuentas y sucursal"
        Me.btnSucursal.UseVisualStyleBackColor = False
        '
        'LabelSucursal
        '
        Me.LabelSucursal.AutoSize = True
        Me.LabelSucursal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSucursal.ForeColor = System.Drawing.Color.LightGray
        Me.LabelSucursal.Location = New System.Drawing.Point(131, 35)
        Me.LabelSucursal.Name = "LabelSucursal"
        Me.LabelSucursal.Size = New System.Drawing.Size(63, 17)
        Me.LabelSucursal.TabIndex = 42
        Me.LabelSucursal.Text = "Sucursal"
        '
        'LabelTítulo
        '
        Me.LabelTítulo.AutoSize = True
        Me.LabelTítulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelTítulo.ForeColor = System.Drawing.Color.Red
        Me.LabelTítulo.Location = New System.Drawing.Point(210, 7)
        Me.LabelTítulo.Name = "LabelTítulo"
        Me.LabelTítulo.Size = New System.Drawing.Size(301, 37)
        Me.LabelTítulo.TabIndex = 43
        Me.LabelTítulo.Text = "Hacer una Consulta"
        '
        'btnBuscarFechaSucursal
        '
        Me.btnBuscarFechaSucursal.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(67, Byte), Integer))
        Me.btnBuscarFechaSucursal.FlatAppearance.BorderSize = 0
        Me.btnBuscarFechaSucursal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBuscarFechaSucursal.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBuscarFechaSucursal.ForeColor = System.Drawing.Color.LightGray
        Me.btnBuscarFechaSucursal.Location = New System.Drawing.Point(6, 82)
        Me.btnBuscarFechaSucursal.Name = "btnBuscarFechaSucursal"
        Me.btnBuscarFechaSucursal.Size = New System.Drawing.Size(124, 46)
        Me.btnBuscarFechaSucursal.TabIndex = 44
        Me.btnBuscarFechaSucursal.Text = "Buscar con fecha y sucursal"
        Me.btnBuscarFechaSucursal.UseVisualStyleBackColor = False
        '
        'LabelSucursalFec
        '
        Me.LabelSucursalFec.AutoSize = True
        Me.LabelSucursalFec.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSucursalFec.ForeColor = System.Drawing.Color.LightGray
        Me.LabelSucursalFec.Location = New System.Drawing.Point(131, 97)
        Me.LabelSucursalFec.Name = "LabelSucursalFec"
        Me.LabelSucursalFec.Size = New System.Drawing.Size(63, 17)
        Me.LabelSucursalFec.TabIndex = 46
        Me.LabelSucursalFec.Text = "Sucursal"
        '
        'txtSuc
        '
        Me.txtSuc.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSuc.Location = New System.Drawing.Point(200, 91)
        Me.txtSuc.MaxLength = 8
        Me.txtSuc.Name = "txtSuc"
        Me.txtSuc.Size = New System.Drawing.Size(84, 23)
        Me.txtSuc.TabIndex = 45
        '
        'btnSaldoMenor
        '
        Me.btnSaldoMenor.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(67, Byte), Integer))
        Me.btnSaldoMenor.FlatAppearance.BorderSize = 0
        Me.btnSaldoMenor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSaldoMenor.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaldoMenor.ForeColor = System.Drawing.Color.LightGray
        Me.btnSaldoMenor.Location = New System.Drawing.Point(13, 17)
        Me.btnSaldoMenor.Name = "btnSaldoMenor"
        Me.btnSaldoMenor.Size = New System.Drawing.Size(81, 64)
        Me.btnSaldoMenor.TabIndex = 47
        Me.btnSaldoMenor.Text = "Buscar "
        Me.btnSaldoMenor.UseVisualStyleBackColor = False
        '
        'txtMS
        '
        Me.txtMS.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMS.Location = New System.Drawing.Point(188, 17)
        Me.txtMS.Name = "txtMS"
        Me.txtMS.Size = New System.Drawing.Size(84, 23)
        Me.txtMS.TabIndex = 48
        '
        'LabelSaldoMenor
        '
        Me.LabelSaldoMenor.AutoSize = True
        Me.LabelSaldoMenor.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSaldoMenor.ForeColor = System.Drawing.Color.LightGray
        Me.LabelSaldoMenor.Location = New System.Drawing.Point(100, 22)
        Me.LabelSaldoMenor.Name = "LabelSaldoMenor"
        Me.LabelSaldoMenor.Size = New System.Drawing.Size(44, 17)
        Me.LabelSaldoMenor.TabIndex = 50
        Me.LabelSaldoMenor.Text = "Saldo"
        '
        'LabelMoneda
        '
        Me.LabelMoneda.AutoSize = True
        Me.LabelMoneda.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMoneda.ForeColor = System.Drawing.Color.LightGray
        Me.LabelMoneda.Location = New System.Drawing.Point(100, 51)
        Me.LabelMoneda.Name = "LabelMoneda"
        Me.LabelMoneda.Size = New System.Drawing.Size(59, 17)
        Me.LabelMoneda.TabIndex = 51
        Me.LabelMoneda.Text = "Moneda"
        '
        'GrupoSaldoMenor
        '
        Me.GrupoSaldoMenor.Controls.Add(Me.ComboMonedaMenor)
        Me.GrupoSaldoMenor.Controls.Add(Me.btnSaldoMenor)
        Me.GrupoSaldoMenor.Controls.Add(Me.LabelMoneda)
        Me.GrupoSaldoMenor.Controls.Add(Me.LabelSaldoMenor)
        Me.GrupoSaldoMenor.Controls.Add(Me.txtMS)
        Me.GrupoSaldoMenor.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrupoSaldoMenor.ForeColor = System.Drawing.Color.LightGray
        Me.GrupoSaldoMenor.Location = New System.Drawing.Point(786, 47)
        Me.GrupoSaldoMenor.Name = "GrupoSaldoMenor"
        Me.GrupoSaldoMenor.Size = New System.Drawing.Size(276, 87)
        Me.GrupoSaldoMenor.TabIndex = 52
        Me.GrupoSaldoMenor.TabStop = False
        Me.GrupoSaldoMenor.Text = "Con Saldo Menor"
        '
        'ComboMonedaMenor
        '
        Me.ComboMonedaMenor.FormattingEnabled = True
        Me.ComboMonedaMenor.Items.AddRange(New Object() {"Pesos", "Dólares"})
        Me.ComboMonedaMenor.Location = New System.Drawing.Point(188, 46)
        Me.ComboMonedaMenor.Name = "ComboMonedaMenor"
        Me.ComboMonedaMenor.Size = New System.Drawing.Size(84, 26)
        Me.ComboMonedaMenor.TabIndex = 52
        '
        'GrupoSaldoMayor
        '
        Me.GrupoSaldoMayor.Controls.Add(Me.ComboMonedaMayor)
        Me.GrupoSaldoMayor.Controls.Add(Me.btnSaldoMayor)
        Me.GrupoSaldoMayor.Controls.Add(Me.LabelMoneda2)
        Me.GrupoSaldoMayor.Controls.Add(Me.LabelSaldoMayor)
        Me.GrupoSaldoMayor.Controls.Add(Me.txtSaldo)
        Me.GrupoSaldoMayor.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrupoSaldoMayor.ForeColor = System.Drawing.Color.LightGray
        Me.GrupoSaldoMayor.Location = New System.Drawing.Point(1070, 42)
        Me.GrupoSaldoMayor.Name = "GrupoSaldoMayor"
        Me.GrupoSaldoMayor.Size = New System.Drawing.Size(276, 87)
        Me.GrupoSaldoMayor.TabIndex = 53
        Me.GrupoSaldoMayor.TabStop = False
        Me.GrupoSaldoMayor.Text = "Con Saldo Mayor"
        '
        'ComboMonedaMayor
        '
        Me.ComboMonedaMayor.FormattingEnabled = True
        Me.ComboMonedaMayor.Items.AddRange(New Object() {"Pesos", "Dólares"})
        Me.ComboMonedaMayor.Location = New System.Drawing.Point(188, 48)
        Me.ComboMonedaMayor.Name = "ComboMonedaMayor"
        Me.ComboMonedaMayor.Size = New System.Drawing.Size(84, 26)
        Me.ComboMonedaMayor.TabIndex = 53
        '
        'btnSaldoMayor
        '
        Me.btnSaldoMayor.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(67, Byte), Integer))
        Me.btnSaldoMayor.FlatAppearance.BorderSize = 0
        Me.btnSaldoMayor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSaldoMayor.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaldoMayor.ForeColor = System.Drawing.Color.LightGray
        Me.btnSaldoMayor.Location = New System.Drawing.Point(13, 17)
        Me.btnSaldoMayor.Name = "btnSaldoMayor"
        Me.btnSaldoMayor.Size = New System.Drawing.Size(81, 64)
        Me.btnSaldoMayor.TabIndex = 47
        Me.btnSaldoMayor.Text = "Buscar "
        Me.btnSaldoMayor.UseVisualStyleBackColor = False
        '
        'LabelMoneda2
        '
        Me.LabelMoneda2.AutoSize = True
        Me.LabelMoneda2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMoneda2.ForeColor = System.Drawing.Color.LightGray
        Me.LabelMoneda2.Location = New System.Drawing.Point(100, 53)
        Me.LabelMoneda2.Name = "LabelMoneda2"
        Me.LabelMoneda2.Size = New System.Drawing.Size(59, 17)
        Me.LabelMoneda2.TabIndex = 51
        Me.LabelMoneda2.Text = "Moneda"
        '
        'LabelSaldoMayor
        '
        Me.LabelSaldoMayor.AutoSize = True
        Me.LabelSaldoMayor.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSaldoMayor.ForeColor = System.Drawing.Color.LightGray
        Me.LabelSaldoMayor.Location = New System.Drawing.Point(100, 22)
        Me.LabelSaldoMayor.Name = "LabelSaldoMayor"
        Me.LabelSaldoMayor.Size = New System.Drawing.Size(44, 17)
        Me.LabelSaldoMayor.TabIndex = 50
        Me.LabelSaldoMayor.Text = "Saldo"
        '
        'txtSaldo
        '
        Me.txtSaldo.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaldo.Location = New System.Drawing.Point(188, 19)
        Me.txtSaldo.Name = "txtSaldo"
        Me.txtSaldo.Size = New System.Drawing.Size(84, 23)
        Me.txtSaldo.TabIndex = 48
        '
        'GrupoCuentaSucursal
        '
        Me.GrupoCuentaSucursal.Controls.Add(Me.btnSucursal)
        Me.GrupoCuentaSucursal.Controls.Add(Me.txtCod)
        Me.GrupoCuentaSucursal.Controls.Add(Me.LabelSucursal)
        Me.GrupoCuentaSucursal.Controls.Add(Me.LabelSucursalFec)
        Me.GrupoCuentaSucursal.Controls.Add(Me.btnBuscarFechaSucursal)
        Me.GrupoCuentaSucursal.Controls.Add(Me.txtSuc)
        Me.GrupoCuentaSucursal.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrupoCuentaSucursal.ForeColor = System.Drawing.Color.LightGray
        Me.GrupoCuentaSucursal.Location = New System.Drawing.Point(1047, 386)
        Me.GrupoCuentaSucursal.Name = "GrupoCuentaSucursal"
        Me.GrupoCuentaSucursal.Size = New System.Drawing.Size(299, 137)
        Me.GrupoCuentaSucursal.TabIndex = 54
        Me.GrupoCuentaSucursal.TabStop = False
        Me.GrupoCuentaSucursal.Text = "Grupo de sucursal"
        '
        'btnCuentaMoneda
        '
        Me.btnCuentaMoneda.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(67, Byte), Integer))
        Me.btnCuentaMoneda.FlatAppearance.BorderSize = 0
        Me.btnCuentaMoneda.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCuentaMoneda.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCuentaMoneda.ForeColor = System.Drawing.Color.LightGray
        Me.btnCuentaMoneda.Location = New System.Drawing.Point(6, 19)
        Me.btnCuentaMoneda.Name = "btnCuentaMoneda"
        Me.btnCuentaMoneda.Size = New System.Drawing.Size(124, 46)
        Me.btnCuentaMoneda.TabIndex = 55
        Me.btnCuentaMoneda.Text = "Buscar cuentas y moneda"
        Me.btnCuentaMoneda.UseVisualStyleBackColor = False
        '
        'GrupoFecha
        '
        Me.GrupoFecha.Controls.Add(Me.LabelFechaMin)
        Me.GrupoFecha.Controls.Add(Me.btnBuscar)
        Me.GrupoFecha.Controls.Add(Me.FechaMínima)
        Me.GrupoFecha.Controls.Add(Me.FechaMáxima)
        Me.GrupoFecha.Controls.Add(Me.LabelFechaMax)
        Me.GrupoFecha.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrupoFecha.ForeColor = System.Drawing.Color.LightGray
        Me.GrupoFecha.Location = New System.Drawing.Point(41, 43)
        Me.GrupoFecha.Name = "GrupoFecha"
        Me.GrupoFecha.Size = New System.Drawing.Size(461, 100)
        Me.GrupoFecha.TabIndex = 56
        Me.GrupoFecha.TabStop = False
        Me.GrupoFecha.Text = "Grupo Fecha"
        '
        'GrupoCuentas
        '
        Me.GrupoCuentas.Controls.Add(Me.btnBuscarCuentas)
        Me.GrupoCuentas.Cursor = System.Windows.Forms.Cursors.Default
        Me.GrupoCuentas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GrupoCuentas.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrupoCuentas.ForeColor = System.Drawing.Color.Red
        Me.GrupoCuentas.Location = New System.Drawing.Point(866, 243)
        Me.GrupoCuentas.Name = "GrupoCuentas"
        Me.GrupoCuentas.Size = New System.Drawing.Size(151, 109)
        Me.GrupoCuentas.TabIndex = 57
        Me.GrupoCuentas.TabStop = False
        Me.GrupoCuentas.Text = "Todas las cuentas"
        '
        'GrupoCaja
        '
        Me.GrupoCaja.Controls.Add(Me.btnCaja)
        Me.GrupoCaja.Controls.Add(Me.ComboCaja)
        Me.GrupoCaja.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrupoCaja.ForeColor = System.Drawing.Color.LightGray
        Me.GrupoCaja.Location = New System.Drawing.Point(1069, 137)
        Me.GrupoCaja.Name = "GrupoCaja"
        Me.GrupoCaja.Size = New System.Drawing.Size(284, 100)
        Me.GrupoCaja.TabIndex = 58
        Me.GrupoCaja.TabStop = False
        Me.GrupoCaja.Text = "Caja de ahorros"
        '
        'btnCaja
        '
        Me.btnCaja.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(67, Byte), Integer))
        Me.btnCaja.FlatAppearance.BorderSize = 0
        Me.btnCaja.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCaja.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCaja.ForeColor = System.Drawing.Color.LightGray
        Me.btnCaja.Location = New System.Drawing.Point(6, 29)
        Me.btnCaja.Name = "btnCaja"
        Me.btnCaja.Size = New System.Drawing.Size(66, 53)
        Me.btnCaja.TabIndex = 52
        Me.btnCaja.Text = "Buscar "
        Me.btnCaja.UseVisualStyleBackColor = False
        '
        'ComboCaja
        '
        Me.ComboCaja.FormattingEnabled = True
        Me.ComboCaja.Items.AddRange(New Object() {"Caja de ahorros en pesos", "Caja de ahorros en dólares"})
        Me.ComboCaja.Location = New System.Drawing.Point(79, 40)
        Me.ComboCaja.Name = "ComboCaja"
        Me.ComboCaja.Size = New System.Drawing.Size(197, 26)
        Me.ComboCaja.TabIndex = 0
        '
        'GrupoCorriente
        '
        Me.GrupoCorriente.Controls.Add(Me.btnCorriente)
        Me.GrupoCorriente.Controls.Add(Me.ComboCorriente)
        Me.GrupoCorriente.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrupoCorriente.ForeColor = System.Drawing.Color.LightGray
        Me.GrupoCorriente.Location = New System.Drawing.Point(1069, 243)
        Me.GrupoCorriente.Name = "GrupoCorriente"
        Me.GrupoCorriente.Size = New System.Drawing.Size(283, 100)
        Me.GrupoCorriente.TabIndex = 59
        Me.GrupoCorriente.TabStop = False
        Me.GrupoCorriente.Text = "Cuenta Corriente"
        '
        'btnCorriente
        '
        Me.btnCorriente.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(67, Byte), Integer))
        Me.btnCorriente.FlatAppearance.BorderSize = 0
        Me.btnCorriente.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCorriente.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCorriente.ForeColor = System.Drawing.Color.LightGray
        Me.btnCorriente.Location = New System.Drawing.Point(6, 29)
        Me.btnCorriente.Name = "btnCorriente"
        Me.btnCorriente.Size = New System.Drawing.Size(66, 53)
        Me.btnCorriente.TabIndex = 52
        Me.btnCorriente.Text = "Buscar "
        Me.btnCorriente.UseVisualStyleBackColor = False
        '
        'ComboCorriente
        '
        Me.ComboCorriente.FormattingEnabled = True
        Me.ComboCorriente.Items.AddRange(New Object() {"Cuenta corriente en pesos", "Cuenta corriente en dólares"})
        Me.ComboCorriente.Location = New System.Drawing.Point(79, 40)
        Me.ComboCorriente.Name = "ComboCorriente"
        Me.ComboCorriente.Size = New System.Drawing.Size(197, 24)
        Me.ComboCorriente.TabIndex = 0
        '
        'ComboMonedaCuenta
        '
        Me.ComboMonedaCuenta.FormattingEnabled = True
        Me.ComboMonedaCuenta.Items.AddRange(New Object() {"Pesos", "Dólares"})
        Me.ComboMonedaCuenta.Location = New System.Drawing.Point(158, 32)
        Me.ComboMonedaCuenta.Name = "ComboMonedaCuenta"
        Me.ComboMonedaCuenta.Size = New System.Drawing.Size(84, 26)
        Me.ComboMonedaCuenta.TabIndex = 53
        '
        'GrupoMoneda
        '
        Me.GrupoMoneda.Controls.Add(Me.btnCuentaMoneda)
        Me.GrupoMoneda.Controls.Add(Me.ComboMonedaCuenta)
        Me.GrupoMoneda.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrupoMoneda.ForeColor = System.Drawing.Color.LightGray
        Me.GrupoMoneda.Location = New System.Drawing.Point(522, 55)
        Me.GrupoMoneda.Name = "GrupoMoneda"
        Me.GrupoMoneda.Size = New System.Drawing.Size(258, 73)
        Me.GrupoMoneda.TabIndex = 60
        Me.GrupoMoneda.TabStop = False
        Me.GrupoMoneda.Text = "Cuenta y Moneda"
        '
        'FormConsultas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(1, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1360, 666)
        Me.Controls.Add(Me.GrupoMoneda)
        Me.Controls.Add(Me.GrupoCorriente)
        Me.Controls.Add(Me.GrupoCaja)
        Me.Controls.Add(Me.GrupoCuentas)
        Me.Controls.Add(Me.GrupoFecha)
        Me.Controls.Add(Me.GrupoCuentaSucursal)
        Me.Controls.Add(Me.GrupoSaldoMayor)
        Me.Controls.Add(Me.GrupoSaldoMenor)
        Me.Controls.Add(Me.LabelTítulo)
        Me.Controls.Add(Me.btnRetroceder)
        Me.Controls.Add(Me.DataGridRegistros)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FormConsultas"
        Me.Text = "Consultas"
        CType(Me.DataGridRegistros, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GrupoSaldoMenor.ResumeLayout(False)
        Me.GrupoSaldoMenor.PerformLayout()
        Me.GrupoSaldoMayor.ResumeLayout(False)
        Me.GrupoSaldoMayor.PerformLayout()
        Me.GrupoCuentaSucursal.ResumeLayout(False)
        Me.GrupoCuentaSucursal.PerformLayout()
        Me.GrupoFecha.ResumeLayout(False)
        Me.GrupoFecha.PerformLayout()
        Me.GrupoCuentas.ResumeLayout(False)
        Me.GrupoCaja.ResumeLayout(False)
        Me.GrupoCorriente.ResumeLayout(False)
        Me.GrupoMoneda.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnRetroceder As System.Windows.Forms.Button
    Friend WithEvents DataGridRegistros As System.Windows.Forms.DataGridView
    Friend WithEvents btnBuscar As System.Windows.Forms.Button
    Friend WithEvents LabelFechaMin As System.Windows.Forms.Label
    Friend WithEvents FechaMínima As System.Windows.Forms.DateTimePicker
    Friend WithEvents FechaMáxima As System.Windows.Forms.DateTimePicker
    Friend WithEvents LabelFechaMax As System.Windows.Forms.Label
    Friend WithEvents btnBuscarCuentas As System.Windows.Forms.Button
    Friend WithEvents txtCod As System.Windows.Forms.TextBox
    Friend WithEvents btnSucursal As System.Windows.Forms.Button
    Friend WithEvents LabelSucursal As System.Windows.Forms.Label
    Friend WithEvents LabelTítulo As System.Windows.Forms.Label
    Friend WithEvents btnBuscarFechaSucursal As System.Windows.Forms.Button
    Friend WithEvents LabelSucursalFec As System.Windows.Forms.Label
    Friend WithEvents txtSuc As System.Windows.Forms.TextBox
    Friend WithEvents btnSaldoMenor As System.Windows.Forms.Button
    Friend WithEvents txtMS As System.Windows.Forms.TextBox
    Friend WithEvents LabelSaldoMenor As System.Windows.Forms.Label
    Friend WithEvents LabelMoneda As System.Windows.Forms.Label
    Friend WithEvents GrupoSaldoMenor As System.Windows.Forms.GroupBox
    Friend WithEvents GrupoSaldoMayor As System.Windows.Forms.GroupBox
    Friend WithEvents btnSaldoMayor As System.Windows.Forms.Button
    Friend WithEvents LabelMoneda2 As System.Windows.Forms.Label
    Friend WithEvents LabelSaldoMayor As System.Windows.Forms.Label
    Friend WithEvents txtSaldo As System.Windows.Forms.TextBox
    Friend WithEvents GrupoCuentaSucursal As System.Windows.Forms.GroupBox
    Friend WithEvents btnCuentaMoneda As System.Windows.Forms.Button
    Friend WithEvents GrupoFecha As System.Windows.Forms.GroupBox
    Friend WithEvents GrupoCuentas As System.Windows.Forms.GroupBox
    Friend WithEvents GrupoCaja As System.Windows.Forms.GroupBox
    Friend WithEvents btnCaja As System.Windows.Forms.Button
    Friend WithEvents ComboCaja As System.Windows.Forms.ComboBox
    Friend WithEvents GrupoCorriente As System.Windows.Forms.GroupBox
    Friend WithEvents btnCorriente As System.Windows.Forms.Button
    Friend WithEvents ComboCorriente As System.Windows.Forms.ComboBox
    Friend WithEvents ComboMonedaMenor As System.Windows.Forms.ComboBox
    Friend WithEvents ComboMonedaMayor As System.Windows.Forms.ComboBox
    Friend WithEvents ComboMonedaCuenta As System.Windows.Forms.ComboBox
    Friend WithEvents GrupoMoneda As System.Windows.Forms.GroupBox
End Class
