﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormModificarCuenta
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormModificarCuenta))
        Me.LabelSubTítulo = New System.Windows.Forms.Label()
        Me.btnBuscar = New System.Windows.Forms.Button()
        Me.LabelTítulo = New System.Windows.Forms.Label()
        Me.ComboTipo = New System.Windows.Forms.ComboBox()
        Me.ComboMoneda = New System.Windows.Forms.ComboBox()
        Me.LabelCliente = New System.Windows.Forms.Label()
        Me.TextBoxCli = New System.Windows.Forms.TextBox()
        Me.btnBorrar = New System.Windows.Forms.Button()
        Me.TextBoxSuc = New System.Windows.Forms.TextBox()
        Me.LabelSucursal = New System.Windows.Forms.Label()
        Me.LabelFecha = New System.Windows.Forms.Label()
        Me.LabelMoneda = New System.Windows.Forms.Label()
        Me.LabelTipo = New System.Windows.Forms.Label()
        Me.LabelSaldo = New System.Windows.Forms.Label()
        Me.LabelPin = New System.Windows.Forms.Label()
        Me.TextBoxSaldo = New System.Windows.Forms.TextBox()
        Me.TextBoxPin = New System.Windows.Forms.TextBox()
        Me.btnModificar = New System.Windows.Forms.Button()
        Me.FechaModificarCuenta = New System.Windows.Forms.DateTimePicker()
        Me.SuspendLayout()
        '
        'LabelSubTítulo
        '
        Me.LabelSubTítulo.AutoSize = True
        Me.LabelSubTítulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSubTítulo.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelSubTítulo.Location = New System.Drawing.Point(632, 88)
        Me.LabelSubTítulo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelSubTítulo.Name = "LabelSubTítulo"
        Me.LabelSubTítulo.Size = New System.Drawing.Size(252, 20)
        Me.LabelSubTítulo.TabIndex = 76
        Me.LabelSubTítulo.Text = "Averiguar si existe la clave primaria"
        '
        'btnBuscar
        '
        Me.btnBuscar.BackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBuscar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBuscar.ForeColor = System.Drawing.Color.LightGray
        Me.btnBuscar.Location = New System.Drawing.Point(660, 125)
        Me.btnBuscar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnBuscar.Name = "btnBuscar"
        Me.btnBuscar.Size = New System.Drawing.Size(206, 54)
        Me.btnBuscar.TabIndex = 75
        Me.btnBuscar.Text = "Buscar"
        Me.btnBuscar.UseVisualStyleBackColor = False
        '
        'LabelTítulo
        '
        Me.LabelTítulo.AutoSize = True
        Me.LabelTítulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelTítulo.ForeColor = System.Drawing.Color.Red
        Me.LabelTítulo.Location = New System.Drawing.Point(180, 9)
        Me.LabelTítulo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelTítulo.Name = "LabelTítulo"
        Me.LabelTítulo.Size = New System.Drawing.Size(259, 37)
        Me.LabelTítulo.TabIndex = 74
        Me.LabelTítulo.Text = "Modificar Cuenta"
        '
        'ComboTipo
        '
        Me.ComboTipo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboTipo.FormattingEnabled = True
        Me.ComboTipo.Items.AddRange(New Object() {"Cuenta Corriente en Pesos", "Cuenta Corriente en Dólares", "Caja de ahorros en Pesos", "Caja de ahorros en Dólares"})
        Me.ComboTipo.Location = New System.Drawing.Point(294, 218)
        Me.ComboTipo.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ComboTipo.Name = "ComboTipo"
        Me.ComboTipo.Size = New System.Drawing.Size(330, 28)
        Me.ComboTipo.TabIndex = 73
        '
        'ComboMoneda
        '
        Me.ComboMoneda.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboMoneda.FormattingEnabled = True
        Me.ComboMoneda.Items.AddRange(New Object() {"Pesos", "Dólares"})
        Me.ComboMoneda.Location = New System.Drawing.Point(294, 278)
        Me.ComboMoneda.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ComboMoneda.Name = "ComboMoneda"
        Me.ComboMoneda.Size = New System.Drawing.Size(330, 28)
        Me.ComboMoneda.TabIndex = 72
        '
        'LabelCliente
        '
        Me.LabelCliente.AutoSize = True
        Me.LabelCliente.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelCliente.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelCliente.Location = New System.Drawing.Point(82, 471)
        Me.LabelCliente.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelCliente.Name = "LabelCliente"
        Me.LabelCliente.Size = New System.Drawing.Size(89, 20)
        Me.LabelCliente.TabIndex = 71
        Me.LabelCliente.Text = "Pin_Cliente"
        '
        'TextBoxCli
        '
        Me.TextBoxCli.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxCli.Location = New System.Drawing.Point(294, 464)
        Me.TextBoxCli.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxCli.MaxLength = 4
        Me.TextBoxCli.Name = "TextBoxCli"
        Me.TextBoxCli.Size = New System.Drawing.Size(330, 26)
        Me.TextBoxCli.TabIndex = 70
        '
        'btnBorrar
        '
        Me.btnBorrar.BackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnBorrar.FlatAppearance.BorderSize = 0
        Me.btnBorrar.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBorrar.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBorrar.ForeColor = System.Drawing.Color.LightGray
        Me.btnBorrar.Location = New System.Drawing.Point(358, 514)
        Me.btnBorrar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnBorrar.Name = "btnBorrar"
        Me.btnBorrar.Size = New System.Drawing.Size(206, 54)
        Me.btnBorrar.TabIndex = 69
        Me.btnBorrar.Text = "Borrar "
        Me.btnBorrar.UseVisualStyleBackColor = False
        '
        'TextBoxSuc
        '
        Me.TextBoxSuc.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxSuc.Location = New System.Drawing.Point(294, 404)
        Me.TextBoxSuc.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxSuc.MaxLength = 8
        Me.TextBoxSuc.Name = "TextBoxSuc"
        Me.TextBoxSuc.Size = New System.Drawing.Size(330, 26)
        Me.TextBoxSuc.TabIndex = 67
        '
        'LabelSucursal
        '
        Me.LabelSucursal.AutoSize = True
        Me.LabelSucursal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSucursal.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelSucursal.Location = New System.Drawing.Point(82, 405)
        Me.LabelSucursal.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelSucursal.Name = "LabelSucursal"
        Me.LabelSucursal.Size = New System.Drawing.Size(130, 20)
        Me.LabelSucursal.TabIndex = 66
        Me.LabelSucursal.Text = "Código_Sucursal"
        '
        'LabelFecha
        '
        Me.LabelFecha.AutoSize = True
        Me.LabelFecha.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelFecha.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelFecha.Location = New System.Drawing.Point(81, 349)
        Me.LabelFecha.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelFecha.Name = "LabelFecha"
        Me.LabelFecha.Size = New System.Drawing.Size(125, 20)
        Me.LabelFecha.TabIndex = 65
        Me.LabelFecha.Text = "Fecha_Apertura"
        '
        'LabelMoneda
        '
        Me.LabelMoneda.AutoSize = True
        Me.LabelMoneda.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMoneda.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelMoneda.Location = New System.Drawing.Point(82, 283)
        Me.LabelMoneda.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelMoneda.Name = "LabelMoneda"
        Me.LabelMoneda.Size = New System.Drawing.Size(67, 20)
        Me.LabelMoneda.TabIndex = 64
        Me.LabelMoneda.Text = "Moneda"
        '
        'LabelTipo
        '
        Me.LabelTipo.AutoSize = True
        Me.LabelTipo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelTipo.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelTipo.Location = New System.Drawing.Point(81, 218)
        Me.LabelTipo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelTipo.Name = "LabelTipo"
        Me.LabelTipo.Size = New System.Drawing.Size(100, 20)
        Me.LabelTipo.TabIndex = 63
        Me.LabelTipo.Text = "Tipo_Cuenta"
        '
        'LabelSaldo
        '
        Me.LabelSaldo.AutoSize = True
        Me.LabelSaldo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSaldo.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelSaldo.Location = New System.Drawing.Point(82, 155)
        Me.LabelSaldo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelSaldo.Name = "LabelSaldo"
        Me.LabelSaldo.Size = New System.Drawing.Size(50, 20)
        Me.LabelSaldo.TabIndex = 62
        Me.LabelSaldo.Text = "Saldo"
        '
        'LabelPin
        '
        Me.LabelPin.AutoSize = True
        Me.LabelPin.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelPin.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelPin.Location = New System.Drawing.Point(82, 95)
        Me.LabelPin.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelPin.Name = "LabelPin"
        Me.LabelPin.Size = New System.Drawing.Size(92, 20)
        Me.LabelPin.TabIndex = 61
        Me.LabelPin.Text = "Pin_Cuenta"
        '
        'TextBoxSaldo
        '
        Me.TextBoxSaldo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxSaldo.Location = New System.Drawing.Point(294, 155)
        Me.TextBoxSaldo.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxSaldo.Name = "TextBoxSaldo"
        Me.TextBoxSaldo.Size = New System.Drawing.Size(330, 26)
        Me.TextBoxSaldo.TabIndex = 59
        '
        'TextBoxPin
        '
        Me.TextBoxPin.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxPin.Location = New System.Drawing.Point(294, 89)
        Me.TextBoxPin.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxPin.MaxLength = 10
        Me.TextBoxPin.Name = "TextBoxPin"
        Me.TextBoxPin.Size = New System.Drawing.Size(330, 26)
        Me.TextBoxPin.TabIndex = 58
        '
        'btnModificar
        '
        Me.btnModificar.BackColor = System.Drawing.Color.Red
        Me.btnModificar.FlatAppearance.BorderSize = 0
        Me.btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnModificar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnModificar.ForeColor = System.Drawing.Color.LightGray
        Me.btnModificar.Location = New System.Drawing.Point(87, 514)
        Me.btnModificar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnModificar.Name = "btnModificar"
        Me.btnModificar.Size = New System.Drawing.Size(206, 54)
        Me.btnModificar.TabIndex = 57
        Me.btnModificar.Text = "Modificar"
        Me.btnModificar.UseVisualStyleBackColor = False
        '
        'FechaModificarCuenta
        '
        Me.FechaModificarCuenta.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FechaModificarCuenta.Location = New System.Drawing.Point(294, 343)
        Me.FechaModificarCuenta.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.FechaModificarCuenta.Name = "FechaModificarCuenta"
        Me.FechaModificarCuenta.Size = New System.Drawing.Size(330, 26)
        Me.FechaModificarCuenta.TabIndex = 77
        '
        'FormModificarCuenta
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1026, 663)
        Me.Controls.Add(Me.FechaModificarCuenta)
        Me.Controls.Add(Me.LabelSubTítulo)
        Me.Controls.Add(Me.btnBuscar)
        Me.Controls.Add(Me.LabelTítulo)
        Me.Controls.Add(Me.ComboTipo)
        Me.Controls.Add(Me.ComboMoneda)
        Me.Controls.Add(Me.LabelCliente)
        Me.Controls.Add(Me.TextBoxCli)
        Me.Controls.Add(Me.btnBorrar)
        Me.Controls.Add(Me.TextBoxSuc)
        Me.Controls.Add(Me.LabelSucursal)
        Me.Controls.Add(Me.LabelFecha)
        Me.Controls.Add(Me.LabelMoneda)
        Me.Controls.Add(Me.LabelTipo)
        Me.Controls.Add(Me.LabelSaldo)
        Me.Controls.Add(Me.LabelPin)
        Me.Controls.Add(Me.TextBoxSaldo)
        Me.Controls.Add(Me.TextBoxPin)
        Me.Controls.Add(Me.btnModificar)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "FormModificarCuenta"
        Me.Text = "Modificar Cuentas"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LabelSubTítulo As System.Windows.Forms.Label
    Friend WithEvents btnBuscar As System.Windows.Forms.Button
    Friend WithEvents LabelTítulo As System.Windows.Forms.Label
    Friend WithEvents ComboTipo As System.Windows.Forms.ComboBox
    Friend WithEvents ComboMoneda As System.Windows.Forms.ComboBox
    Friend WithEvents LabelCliente As System.Windows.Forms.Label
    Friend WithEvents TextBoxCli As System.Windows.Forms.TextBox
    Friend WithEvents btnBorrar As System.Windows.Forms.Button
    Friend WithEvents TextBoxSuc As System.Windows.Forms.TextBox
    Friend WithEvents LabelSucursal As System.Windows.Forms.Label
    Friend WithEvents LabelFecha As System.Windows.Forms.Label
    Friend WithEvents LabelMoneda As System.Windows.Forms.Label
    Friend WithEvents LabelTipo As System.Windows.Forms.Label
    Friend WithEvents LabelSaldo As System.Windows.Forms.Label
    Friend WithEvents LabelPin As System.Windows.Forms.Label
    Friend WithEvents TextBoxSaldo As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxPin As System.Windows.Forms.TextBox
    Friend WithEvents btnModificar As System.Windows.Forms.Button
    Friend WithEvents FechaModificarCuenta As System.Windows.Forms.DateTimePicker
End Class
