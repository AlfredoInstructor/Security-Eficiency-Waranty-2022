﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormModificarCliente
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormModificarCliente))
        Me.LabelTítulo = New System.Windows.Forms.Label()
        Me.btnBorrar = New System.Windows.Forms.Button()
        Me.btnModificar = New System.Windows.Forms.Button()
        Me.ComboCivil = New System.Windows.Forms.ComboBox()
        Me.ComboSexo = New System.Windows.Forms.ComboBox()
        Me.LabelSex = New System.Windows.Forms.Label()
        Me.LabelEs = New System.Windows.Forms.Label()
        Me.LabelFec = New System.Windows.Forms.Label()
        Me.LabelNac = New System.Windows.Forms.Label()
        Me.LabelDom = New System.Windows.Forms.Label()
        Me.LabelNom = New System.Windows.Forms.Label()
        Me.LabelCliente = New System.Windows.Forms.Label()
        Me.TextBoxNac = New System.Windows.Forms.TextBox()
        Me.TextBoxDom = New System.Windows.Forms.TextBox()
        Me.TextBoxNom = New System.Windows.Forms.TextBox()
        Me.TextBoxPin = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnBuscar = New System.Windows.Forms.Button()
        Me.FechaModificarCliente = New System.Windows.Forms.DateTimePicker()
        Me.SuspendLayout()
        '
        'LabelTítulo
        '
        Me.LabelTítulo.AutoSize = True
        Me.LabelTítulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelTítulo.ForeColor = System.Drawing.Color.Red
        Me.LabelTítulo.Location = New System.Drawing.Point(185, 18)
        Me.LabelTítulo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelTítulo.Name = "LabelTítulo"
        Me.LabelTítulo.Size = New System.Drawing.Size(254, 37)
        Me.LabelTítulo.TabIndex = 37
        Me.LabelTítulo.Text = "Modificar Cliente"
        '
        'btnBorrar
        '
        Me.btnBorrar.BackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnBorrar.FlatAppearance.BorderSize = 0
        Me.btnBorrar.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBorrar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBorrar.ForeColor = System.Drawing.Color.LightGray
        Me.btnBorrar.Location = New System.Drawing.Point(344, 484)
        Me.btnBorrar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnBorrar.Name = "btnBorrar"
        Me.btnBorrar.Size = New System.Drawing.Size(206, 54)
        Me.btnBorrar.TabIndex = 32
        Me.btnBorrar.Text = "Borrar "
        Me.btnBorrar.UseVisualStyleBackColor = False
        '
        'btnModificar
        '
        Me.btnModificar.BackColor = System.Drawing.Color.Red
        Me.btnModificar.FlatAppearance.BorderSize = 0
        Me.btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnModificar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnModificar.ForeColor = System.Drawing.Color.LightGray
        Me.btnModificar.Location = New System.Drawing.Point(103, 484)
        Me.btnModificar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnModificar.Name = "btnModificar"
        Me.btnModificar.Size = New System.Drawing.Size(206, 54)
        Me.btnModificar.TabIndex = 29
        Me.btnModificar.Text = "Modificar"
        Me.btnModificar.UseVisualStyleBackColor = False
        '
        'ComboCivil
        '
        Me.ComboCivil.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboCivil.FormattingEnabled = True
        Me.ComboCivil.Items.AddRange(New Object() {"Soltero", "Casado", "Divorciado", "Viudo"})
        Me.ComboCivil.Location = New System.Drawing.Point(274, 372)
        Me.ComboCivil.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ComboCivil.Name = "ComboCivil"
        Me.ComboCivil.Size = New System.Drawing.Size(330, 28)
        Me.ComboCivil.TabIndex = 52
        '
        'ComboSexo
        '
        Me.ComboSexo.AutoCompleteCustomSource.AddRange(New String() {"Masculino", "Femenino", "Otros"})
        Me.ComboSexo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboSexo.FormattingEnabled = True
        Me.ComboSexo.Items.AddRange(New Object() {"Masculino", "Femenino", "Otros"})
        Me.ComboSexo.Location = New System.Drawing.Point(274, 429)
        Me.ComboSexo.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ComboSexo.Name = "ComboSexo"
        Me.ComboSexo.Size = New System.Drawing.Size(330, 28)
        Me.ComboSexo.TabIndex = 51
        '
        'LabelSex
        '
        Me.LabelSex.AutoSize = True
        Me.LabelSex.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSex.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelSex.Location = New System.Drawing.Point(100, 429)
        Me.LabelSex.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelSex.Name = "LabelSex"
        Me.LabelSex.Size = New System.Drawing.Size(45, 20)
        Me.LabelSex.TabIndex = 50
        Me.LabelSex.Text = "Sexo"
        '
        'LabelEs
        '
        Me.LabelEs.AutoSize = True
        Me.LabelEs.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelEs.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelEs.Location = New System.Drawing.Point(98, 374)
        Me.LabelEs.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelEs.Name = "LabelEs"
        Me.LabelEs.Size = New System.Drawing.Size(96, 20)
        Me.LabelEs.TabIndex = 49
        Me.LabelEs.Text = "Estado_Civil"
        '
        'LabelFec
        '
        Me.LabelFec.AutoSize = True
        Me.LabelFec.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelFec.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelFec.Location = New System.Drawing.Point(100, 325)
        Me.LabelFec.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelFec.Name = "LabelFec"
        Me.LabelFec.Size = New System.Drawing.Size(142, 20)
        Me.LabelFec.TabIndex = 47
        Me.LabelFec.Text = "Fecha_Nacimiento"
        '
        'LabelNac
        '
        Me.LabelNac.AutoSize = True
        Me.LabelNac.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelNac.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelNac.Location = New System.Drawing.Point(98, 270)
        Me.LabelNac.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelNac.Name = "LabelNac"
        Me.LabelNac.Size = New System.Drawing.Size(100, 20)
        Me.LabelNac.TabIndex = 46
        Me.LabelNac.Text = "Nacionalidad"
        '
        'LabelDom
        '
        Me.LabelDom.AutoSize = True
        Me.LabelDom.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelDom.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelDom.Location = New System.Drawing.Point(98, 214)
        Me.LabelDom.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelDom.Name = "LabelDom"
        Me.LabelDom.Size = New System.Drawing.Size(72, 20)
        Me.LabelDom.TabIndex = 45
        Me.LabelDom.Text = "Domicilio"
        '
        'LabelNom
        '
        Me.LabelNom.AutoSize = True
        Me.LabelNom.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelNom.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelNom.Location = New System.Drawing.Point(100, 151)
        Me.LabelNom.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelNom.Name = "LabelNom"
        Me.LabelNom.Size = New System.Drawing.Size(65, 20)
        Me.LabelNom.TabIndex = 44
        Me.LabelNom.Text = "Nombre"
        '
        'LabelCliente
        '
        Me.LabelCliente.AutoSize = True
        Me.LabelCliente.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelCliente.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelCliente.Location = New System.Drawing.Point(100, 91)
        Me.LabelCliente.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelCliente.Name = "LabelCliente"
        Me.LabelCliente.Size = New System.Drawing.Size(89, 20)
        Me.LabelCliente.TabIndex = 43
        Me.LabelCliente.Text = "Pin_Cliente"
        '
        'TextBoxNac
        '
        Me.TextBoxNac.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxNac.Location = New System.Drawing.Point(274, 257)
        Me.TextBoxNac.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxNac.Name = "TextBoxNac"
        Me.TextBoxNac.Size = New System.Drawing.Size(330, 26)
        Me.TextBoxNac.TabIndex = 42
        '
        'TextBoxDom
        '
        Me.TextBoxDom.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxDom.Location = New System.Drawing.Point(274, 205)
        Me.TextBoxDom.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxDom.MaxLength = 200
        Me.TextBoxDom.Name = "TextBoxDom"
        Me.TextBoxDom.Size = New System.Drawing.Size(330, 26)
        Me.TextBoxDom.TabIndex = 41
        '
        'TextBoxNom
        '
        Me.TextBoxNom.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxNom.Location = New System.Drawing.Point(274, 142)
        Me.TextBoxNom.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxNom.Name = "TextBoxNom"
        Me.TextBoxNom.Size = New System.Drawing.Size(330, 26)
        Me.TextBoxNom.TabIndex = 40
        '
        'TextBoxPin
        '
        Me.TextBoxPin.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxPin.Location = New System.Drawing.Point(274, 78)
        Me.TextBoxPin.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxPin.MaxLength = 4
        Me.TextBoxPin.Name = "TextBoxPin"
        Me.TextBoxPin.Size = New System.Drawing.Size(330, 26)
        Me.TextBoxPin.TabIndex = 39
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.Control
        Me.Label1.Location = New System.Drawing.Point(607, 82)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(252, 20)
        Me.Label1.TabIndex = 58
        Me.Label1.Text = "Averiguar si existe la clave primaria"
        '
        'btnBuscar
        '
        Me.btnBuscar.BackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBuscar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBuscar.ForeColor = System.Drawing.Color.LightGray
        Me.btnBuscar.Location = New System.Drawing.Point(624, 114)
        Me.btnBuscar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnBuscar.Name = "btnBuscar"
        Me.btnBuscar.Size = New System.Drawing.Size(206, 54)
        Me.btnBuscar.TabIndex = 57
        Me.btnBuscar.Text = "Buscar"
        Me.btnBuscar.UseVisualStyleBackColor = False
        '
        'FechaModificarCliente
        '
        Me.FechaModificarCliente.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FechaModificarCliente.Location = New System.Drawing.Point(274, 319)
        Me.FechaModificarCliente.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.FechaModificarCliente.Name = "FechaModificarCliente"
        Me.FechaModificarCliente.Size = New System.Drawing.Size(330, 26)
        Me.FechaModificarCliente.TabIndex = 78
        '
        'FormModificarCliente
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(878, 694)
        Me.Controls.Add(Me.FechaModificarCliente)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnBuscar)
        Me.Controls.Add(Me.ComboCivil)
        Me.Controls.Add(Me.ComboSexo)
        Me.Controls.Add(Me.LabelSex)
        Me.Controls.Add(Me.LabelEs)
        Me.Controls.Add(Me.LabelFec)
        Me.Controls.Add(Me.LabelNac)
        Me.Controls.Add(Me.LabelDom)
        Me.Controls.Add(Me.LabelNom)
        Me.Controls.Add(Me.LabelCliente)
        Me.Controls.Add(Me.TextBoxNac)
        Me.Controls.Add(Me.TextBoxDom)
        Me.Controls.Add(Me.TextBoxNom)
        Me.Controls.Add(Me.TextBoxPin)
        Me.Controls.Add(Me.LabelTítulo)
        Me.Controls.Add(Me.btnBorrar)
        Me.Controls.Add(Me.btnModificar)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FormModificarCliente"
        Me.Text = "FormModificarCliente"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LabelTítulo As System.Windows.Forms.Label
    Friend WithEvents btnBorrar As System.Windows.Forms.Button
    Friend WithEvents btnModificar As System.Windows.Forms.Button
    Friend WithEvents ComboCivil As System.Windows.Forms.ComboBox
    Friend WithEvents ComboSexo As System.Windows.Forms.ComboBox
    Friend WithEvents LabelSex As System.Windows.Forms.Label
    Friend WithEvents LabelEs As System.Windows.Forms.Label
    Friend WithEvents LabelFec As System.Windows.Forms.Label
    Friend WithEvents LabelNac As System.Windows.Forms.Label
    Friend WithEvents LabelDom As System.Windows.Forms.Label
    Friend WithEvents LabelNom As System.Windows.Forms.Label
    Friend WithEvents LabelCliente As System.Windows.Forms.Label
    Friend WithEvents TextBoxNac As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxDom As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxNom As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxPin As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnBuscar As System.Windows.Forms.Button
    Friend WithEvents FechaModificarCliente As System.Windows.Forms.DateTimePicker
End Class
