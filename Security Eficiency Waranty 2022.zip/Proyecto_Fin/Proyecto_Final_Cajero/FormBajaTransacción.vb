﻿Imports MySql.Data.MySqlClient
Public Class FormBajaTransacción
    Private Sub TextID_TextKeypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextID.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub
    Private Sub Borrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
        Dim SqlBT As String = "DELETE FROM Transacción WHERE Pin_Cuenta='" & TextID.Text & "'"
        Dim ComandoBT As New MySqlCommand(SqlBT, FormSesión.Conexión)
        Try
            FormSesión.Conexión.Open()
            'Casos al momento de borrar o no un dato
            Dim Respuesta As Integer = MsgBox("Desea borrar los datos ingresados?", vbYesNo + vbExclamation, "Advertencia")
            Select Case Respuesta
                Case vbYes
                    ComandoBT.ExecuteNonQuery()
                    MsgBox("Se han borrado los datos correctamente", vbExclamation, "Advertencia")
                Case vbNo
                    MsgBox("Se ha cancelado la operación", vbExclamation, "Advertencia")
            End Select
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Advertencia")
        End Try
        FormSesión.Conexión.Close()
    End Sub

    'Buscar clave primaria
    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        Dim DTBajaTransacción As New DataTable
        Dim SqlBTransacción As String = "SELECT * FROM transaccion WHERE ID_TN = '" & TextID.Text & "'"
        Dim SqlComandoTransacción = New MySqlCommand(SqlBTransacción, FormSesión.Conexión)
        FormSesión.Conexión.Open()
        Dim LectorBTrans = New MySqlDataAdapter(SqlComandoTransacción)
        LectorBTrans.Fill(DTBajaTransacción)
        If TextID.Text = "" Then
            MsgBox("Ingrese la clave primaria", vbExclamation, "Advertencia")
        ElseIf DTBajaTransacción.Rows.Count = 0 Then
            MsgBox("No existen los datos", vbExclamation, "Advertencia")
        Else
            MsgBox("Existe la Clave Primaria", vbExclamation, "Advertencia")
        End If
        FormSesión.Conexión.Close()
    End Sub

End Class