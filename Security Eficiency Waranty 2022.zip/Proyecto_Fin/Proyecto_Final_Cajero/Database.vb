﻿
Namespace DAO
    Class Database

        Function OpenRecordset(ByVal mySql As String, ByVal p2 As Object) As Recordset
            Throw New NotImplementedException
        End Function

    End Class
End Namespace
