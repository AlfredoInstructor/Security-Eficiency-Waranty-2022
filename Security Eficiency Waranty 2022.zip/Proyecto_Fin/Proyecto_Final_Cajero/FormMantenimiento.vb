﻿Public Class FormMantenimiento
#Region "Botones Submenu"
    Private Sub btnConsultas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConsultas.Click
        Me.Hide()
        FormConsultas.Show()
    End Sub
    Private Sub btnAltaCuenta_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAltaCuenta.Click
        AbrirFormEnPanel(New FormAltaCuenta)
        OcultarSubmenú()
    End Sub

    Private Sub btnModificarCuenta_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnModificarCuenta.Click
        AbrirFormEnPanel(New FormModificarCuenta)
        OcultarSubmenú()
    End Sub

    Private Sub btnEliminarCuenta_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnEliminarCuenta.Click
        AbrirFormEnPanel(New FormBajaCuenta)
        OcultarSubmenú()
    End Sub

    Private Sub btnAltaCliente_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAltaCliente.Click
        AbrirFormEnPanel(New FormAltaCliente)
        OcultarSubmenú()
    End Sub

    Private Sub btnModificarCliente_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnModificarCliente.Click
        AbrirFormEnPanel(New FormModificarCliente)
        OcultarSubmenú()
    End Sub

    Private Sub btnEliminarCliente_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnEliminarCliente.Click
        AbrirFormEnPanel(New FormBajaCliente)
        OcultarSubmenú()
    End Sub


    Private Sub btnAltaSucursal_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAltaSucursal.Click
        AbrirFormEnPanel(New FormAltaSucursal)
        OcultarSubmenú()
    End Sub

    Private Sub btnModificarSucursal_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnModificarSucursal.Click
        AbrirFormEnPanel(New FormModificarSucursal)
        OcultarSubmenú()
    End Sub

    Private Sub btnEliminarSucursal_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnEliminarSucursal.Click
        AbrirFormEnPanel(New FormBajaSucursal)
        OcultarSubmenú()
    End Sub

    Private Sub btnAltaTransacción_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAltaTransacción.Click
        AbrirFormEnPanel(New FormAltaTransacción)
        OcultarSubmenú()
    End Sub

    Private Sub btnModificarTransacción_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModificarTransacción.Click
        AbrirFormEnPanel(New FormModificarTransacción)
        OcultarSubmenú()
    End Sub

    Private Sub btnEliminarTransacción_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminarTransacción.Click
        AbrirFormEnPanel(New FormBajaTransacción)
        OcultarSubmenú()
    End Sub

#End Region

    Private Sub FormMantenimiento_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        OcultarSubmenú()
    End Sub

    Private Sub OcultarSubmenú()
        PanelCuentaMenú.Visible = False
        PanelClienteMenú.Visible = False
        PanelSucursalMenú.Visible = False
        PanelTransacciónMenú.Visible = False
    End Sub

    Private Sub verSubmenú(ByVal submenu As Panel)
        If submenu.Visible = False Then
            OcultarSubmenú()
            submenu.Visible = True
        Else
            submenu.Visible = False
        End If
    End Sub
#Region "Abrir panel con los botones"
    Private Sub btnCuenta_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnCuenta.Click
        verSubmenú(PanelCuentaMenú)
    End Sub

    Private Sub btnCliente_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnCliente.Click
        verSubmenú(PanelClienteMenú)
    End Sub

    Private Sub btnSucursal_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSucursal.Click
        verSubmenú(PanelSucursalMenú)
    End Sub

    Private Sub btnTransacción_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTransacción.Click
        verSubmenú(PanelTransacciónMenú)
    End Sub
#End Region
    Private ActualForm As Form = Nothing
    Private Sub AbrirFormEnPanel(ByVal FormHijo As Form)
        If ActualForm IsNot Nothing Then ActualForm.Close()
        ActualForm = FormHijo
        FormHijo.TopLevel = False
        FormHijo.FormBorderStyle = FormBorderStyle.None
        FormHijo.Dock = DockStyle.Fill
        PanelFormHijo.Controls.Add(FormHijo)
        PanelFormHijo.Tag = FormHijo
        FormHijo.BringToFront()
        FormHijo.Show()
    End Sub

    Private Sub btnSalir_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSalir.Click
        Me.Hide()
        FormSesión.Show()
    End Sub
End Class
