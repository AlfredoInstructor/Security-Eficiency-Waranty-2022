﻿Imports MySql.Data.MySqlClient
Public Class FormAltaCliente

#Region "Textbox que solo acepten letras"
    'TextBox Nacionalidad
    Private Sub TextBoxNacionalidad_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxNacionalidad.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub
    'TextBox Nombre 
    Private Sub TextBoxNombre_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxNombre.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub
    'TextBox Civil

#End Region
    'TextboxPin que solo admite números y borrar
    Private Sub Pin_TextKeypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxPin.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub
    Private Sub ComboCivil_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ComboCivil.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If

        ComboCivil.Text = Trim(Replace(ComboCivil.Text, " ", ""))
        ComboCivil.Select(ComboCivil.Text.Length, 0)
    End Sub
    Private Sub btnIngresar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsertar.Click
        'Er es una variable de Error que nos señala cuando se repite la misma clave primaria
        Dim Er As Integer = 0
        Dim Comando As MySqlCommand = New MySqlCommand
        Comando.Connection = FormSesión.Conexión
        Try
            FormSesión.Conexión.Open()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Comando.CommandText = "SELECT * FROM cliente WHERE Pin_Cliente = '" & TextBoxPin.Text & "'"
        Dim Resultado As MySqlDataReader
        Resultado = Comando.ExecuteReader
        If Resultado.HasRows Then
            MsgBox("Ya existe la clave primaria ingresada", vbExclamation, "Advertencia")
            Er = 1
            Resultado.Close()
        ElseIf TextBoxPin.Text = "" Then
            MsgBox("Ingrese clave primaria", vbExclamation, "Advertencia")
            Resultado.Close()
            Er = 1
        ElseIf TextBoxDomicilio.Text = "" Or TextBoxNacionalidad.Text = "" Or TextBoxNombre.Text = "" Or ComboCivil.Text = "" Or ComboSexo.Text = "" Then
            MsgBox("Ingrese todos los registros correctamente", vbExclamation, "Advertencia")
            Resultado.Close()
            Er = 1
        End If
        FormSesión.Conexión.Close()
        'Si Er es 0,entonces se ejecuta todo el comando
        If Er = 0 Then
            Dim FechaCliente As String = FechaAltaCliente.Value.ToString("yyyy-MM-dd")
            Dim SqlACLI As String = "INSERT INTO cliente(Pin_Cliente,Nombre,Domicilio,Nacionalidad,Fecha_Nacimiento,Estado_Civil,Sexo) VALUES(" & TextBoxPin.Text & ", '" & TextBoxNombre.Text & "', '" & TextBoxDomicilio.Text & "','" & TextBoxNacionalidad.Text & "','" & FechaCliente & "', '" & ComboCivil.Text & "', '" & ComboSexo.Text & "')"
            Dim Command As New MySqlCommand(SqlACLI, FormSesión.Conexión)
            Try
                FormSesión.Conexión.Open()
                'Casos al momento de ingresar o no los datos
                Dim Respuesta As Integer = MsgBox("Desea ingresar los siguientes datos?", vbYesNo + vbExclamation, "Advertencia")
                Select Case Respuesta
                    Case vbYes
                        Command.ExecuteNonQuery()
                        MsgBox("Se han ingresado los datos correctamente", vbExclamation, "Advertencia")
                    Case vbNo
                        MsgBox("Se ha cancelado la operación", vbExclamation, "Advertencia")
                End Select
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            FormSesión.Conexión.Close()
        End If

    End Sub
    Private Sub FormAltaCliente_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
    'Borra todos los datos ingresados en los Textbox
    Private Sub BotónBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BotónBorrar.Click
        Dim Respuesta As Integer = MsgBox("Desea borrar los datos ingresados?", vbYesNo + vbExclamation, "Advertencia")
        Select Case Respuesta
            Case vbYes
                MsgBox("Se han borrado los datos correctamente", vbExclamation, "Advertencia")
                TextBoxDomicilio.Text = ""
                TextBoxPin.Text = ""
                TextBoxNombre.Text = ""
                ComboCivil.Text = ""
                TextBoxNacionalidad.Text = ""
                ComboSexo.Text = ""
            Case vbNo
                MsgBox("Se ha cancelado la operación", vbExclamation, "Advertencia")
        End Select
    End Sub

    'Buscar si existen registros de clave primaria
    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        Dim DTCliente As New DataTable
        Dim SqlACLI As String = "SELECT * FROM cliente WHERE Pin_Cliente = '" & TextBoxPin.Text & "'"
        Dim SqlComandoCliente = New MySqlCommand(SqlACLI, FormSesión.Conexión)
        FormSesión.Conexión.Open()
        Dim LectorCliente = New MySqlDataAdapter(SqlComandoCliente)
        LectorCliente.Fill(DTCliente)

        If TextBoxPin.Text = "" Then
            MsgBox("Ingrese la clave primaria", vbExclamation, "Advertencia")
        ElseIf DTCliente.Rows.Count = 0 Then
            MsgBox("No existen los datos", vbExclamation, "Advertencia")
        Else
            MsgBox("Existe la Clave Primaria", vbExclamation, "Advertencia")
            TextBoxPin.Text = DTCliente.Rows(0)("Pin_Cliente").ToString()
            TextBoxNombre.Text = DTCliente.Rows(0)("Nombre").ToString()
            TextBoxDomicilio.Text = DTCliente.Rows(0)("Domicilio").ToString()
            TextBoxNacionalidad.Text = DTCliente.Rows(0)("Nacionalidad").ToString()
            FechaAltaCliente.Value = DTCliente.Rows(0)("Fecha_Nacimiento").ToString()
            ComboCivil.Text = DTCliente.Rows(0)("Estado_Civil").ToString()
            ComboSexo.Text = DTCliente.Rows(0)("Sexo").ToString()
        End If
        FormSesión.Conexión.Close()
    End Sub
End Class
