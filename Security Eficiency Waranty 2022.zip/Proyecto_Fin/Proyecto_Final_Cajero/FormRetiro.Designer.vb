﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormRetiro
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnRetiro = New System.Windows.Forms.Button()
        Me.LabelRetiro = New System.Windows.Forms.Label()
        Me.TextBoxRetiro = New System.Windows.Forms.TextBox()
        Me.LabelMoneda = New System.Windows.Forms.Label()
        Me.LabelSaldo = New System.Windows.Forms.Label()
        Me.ProgresoRetiro = New System.Windows.Forms.ProgressBar()
        Me.DateTimeR = New System.Windows.Forms.DateTimePicker()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Gray
        Me.Label2.Location = New System.Drawing.Point(251, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(334, 55)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Solicitar Retiro"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.LightGray
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel3.Location = New System.Drawing.Point(0, 460)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(930, 100)
        Me.Panel3.TabIndex = 6
        '
        'btnRetiro
        '
        Me.btnRetiro.BackColor = System.Drawing.Color.DarkSlateGray
        Me.btnRetiro.FlatAppearance.BorderSize = 0
        Me.btnRetiro.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRetiro.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRetiro.ForeColor = System.Drawing.Color.LightGray
        Me.btnRetiro.Location = New System.Drawing.Point(314, 283)
        Me.btnRetiro.Name = "btnRetiro"
        Me.btnRetiro.Size = New System.Drawing.Size(145, 54)
        Me.btnRetiro.TabIndex = 32
        Me.btnRetiro.Text = "Retirar"
        Me.btnRetiro.UseVisualStyleBackColor = False
        '
        'LabelRetiro
        '
        Me.LabelRetiro.AutoSize = True
        Me.LabelRetiro.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelRetiro.Location = New System.Drawing.Point(276, 148)
        Me.LabelRetiro.Name = "LabelRetiro"
        Me.LabelRetiro.Size = New System.Drawing.Size(226, 25)
        Me.LabelRetiro.TabIndex = 37
        Me.LabelRetiro.Text = "Ingrese cantidad a retirar"
        '
        'TextBoxRetiro
        '
        Me.TextBoxRetiro.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxRetiro.Location = New System.Drawing.Point(295, 210)
        Me.TextBoxRetiro.Name = "TextBoxRetiro"
        Me.TextBoxRetiro.Size = New System.Drawing.Size(183, 26)
        Me.TextBoxRetiro.TabIndex = 38
        '
        'LabelMoneda
        '
        Me.LabelMoneda.AutoSize = True
        Me.LabelMoneda.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMoneda.Location = New System.Drawing.Point(77, 183)
        Me.LabelMoneda.Name = "LabelMoneda"
        Me.LabelMoneda.Size = New System.Drawing.Size(0, 37)
        Me.LabelMoneda.TabIndex = 41
        '
        'LabelSaldo
        '
        Me.LabelSaldo.AutoSize = True
        Me.LabelSaldo.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSaldo.Location = New System.Drawing.Point(77, 148)
        Me.LabelSaldo.Name = "LabelSaldo"
        Me.LabelSaldo.Size = New System.Drawing.Size(0, 37)
        Me.LabelSaldo.TabIndex = 40
        '
        'ProgresoRetiro
        '
        Me.ProgresoRetiro.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ProgresoRetiro.Cursor = System.Windows.Forms.Cursors.Default
        Me.ProgresoRetiro.ForeColor = System.Drawing.Color.Black
        Me.ProgresoRetiro.Location = New System.Drawing.Point(323, 242)
        Me.ProgresoRetiro.Name = "ProgresoRetiro"
        Me.ProgresoRetiro.Size = New System.Drawing.Size(125, 23)
        Me.ProgresoRetiro.TabIndex = 42
        '
        'DateTimeR
        '
        Me.DateTimeR.Location = New System.Drawing.Point(588, 212)
        Me.DateTimeR.Name = "DateTimeR"
        Me.DateTimeR.Size = New System.Drawing.Size(200, 20)
        Me.DateTimeR.TabIndex = 43
        Me.DateTimeR.Visible = False
        '
        'FormRetiro
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(930, 560)
        Me.Controls.Add(Me.DateTimeR)
        Me.Controls.Add(Me.ProgresoRetiro)
        Me.Controls.Add(Me.LabelMoneda)
        Me.Controls.Add(Me.LabelSaldo)
        Me.Controls.Add(Me.TextBoxRetiro)
        Me.Controls.Add(Me.LabelRetiro)
        Me.Controls.Add(Me.btnRetiro)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Label2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "FormRetiro"
        Me.Text = "FormRetiro"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents btnRetiro As System.Windows.Forms.Button
    Friend WithEvents LabelRetiro As System.Windows.Forms.Label
    Friend WithEvents TextBoxRetiro As System.Windows.Forms.TextBox
    Friend WithEvents LabelMoneda As System.Windows.Forms.Label
    Friend WithEvents LabelSaldo As System.Windows.Forms.Label
    Friend WithEvents ProgresoRetiro As System.Windows.Forms.ProgressBar
    Friend WithEvents DateTimeR As System.Windows.Forms.DateTimePicker
End Class
