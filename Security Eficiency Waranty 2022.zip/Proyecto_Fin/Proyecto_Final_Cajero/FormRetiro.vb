﻿Imports MySql.Data.MySqlClient
Public Class FormRetiro
    'Variable de tipo de transacción
    Dim TipoR As String = "Retiro"
    'Er es una variable de Error que nos señala cuando se repite la misma clave primaria y finaliza la tarea
    Dim Er As Integer = 0
    Private Sub TextBoxRetiro_TextKeypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxRetiro.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub
    'Variable para llamar los datos escritos en el TextBox PinCuenta del form Lógin
    Dim PinRetiro As String = Val(FormSesión.PinCuenta.Text)
    'Botón de Depósito para poder retirar(Actualizar) nuestro saldo
    Private Sub btnRetiro_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRetiro.Click
        'Variable para la fecha de transacción
        Dim FechaR As String = DateTimeR.Value.ToString("yyyy-MM-dd HH:mm:ss")
        'Consultar Saldo
        Dim DTSR As New DataTable
        Dim SqlSR As String = "SELECT saldo,Moneda FROM cuenta WHERE Pin_Cuenta = '" & PinRetiro & "'"
        Dim SqlComandoSR = New MySqlCommand(SqlSR, FormSesión.Conexión)
        Dim LectorSR = New MySqlDataAdapter(SqlComandoSR)
        Try
            FormSesión.Conexión.Open()
            LectorSR.Fill(DTSR)
            LabelSaldo.Text = DTSR.Rows(0)("Saldo").ToString()
            LabelMoneda.Text = DTSR.Rows(0)("Moneda").ToString()
            FormSesión.Conexión.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        'Retirar saldo
        Dim SqlRetiro As String = "UPDATE cuenta SET Saldo = Saldo - '" & TextBoxRetiro.Text & "' WHERE Pin_Cuenta = '" & PinRetiro & "'"
        Dim ComandoRetiro As New MySqlCommand
        ComandoRetiro = New MySqlCommand(SqlRetiro, FormSesión.Conexión)
        Try
            If TextBoxRetiro.Text = "" Then
                MsgBox("Ingrese un valor", vbExclamation, "Information")
                Er = 1
            ElseIf Val(TextBoxRetiro.Text) > Val(LabelSaldo.Text) Then
                MsgBox("No puede retirar más saldo del que tiene", vbInformation, "Retiro")
                Er = 1
            ElseIf Val(TextBoxRetiro.Text) > 500000 And LabelMoneda.Text = "Pesos" Then
                MsgBox("El saldo a retirar no puede ser mayor a 5000000", vbExclamation, "Advertencia")
                Er = 1
            ElseIf Val(TextBoxRetiro.Text) > 500000 And LabelMoneda.Text = "Dolares" Then
                MsgBox("El saldo a retirar no puede ser mayor a 5000000", vbExclamation, "Advertencia")
                Er = 1
            Else
                FormSesión.Conexión.Open()
                ComandoRetiro.ExecuteNonQuery()
                ComandoRetiro.CommandText = SqlRetiro
                ComandoRetiro.Connection = FormSesión.Conexión
                ProgresoRetiro.Value = 100
                MsgBox("Su dinero se ha retirado con exito", vbInformation, "Depósito")
                ProgresoRetiro.Value = 0

            End If
        Catch ex As Exception
            ProgresoRetiro.Value = 50
            MsgBox(ex.Message)
        End Try
        FormSesión.Conexión.Close()
        If Er = 0 Then
            Try
                FormSesión.Conexión.Open()
                Dim SQLTrans As String = "INSERT INTO transaccion(Monto,Moneda,Fecha_Transaccion,Tipo,Pin_Cuenta) VALUES('" & TextBoxRetiro.Text & "','" & LabelMoneda.Text & "','" & FechaR & "', '" & TipoR & "', '" & PinRetiro & "')"
                Dim ComandoTrans As New MySqlCommand(SQLTrans, FormSesión.Conexión)
                ComandoTrans.Connection = FormSesión.Conexión
                ComandoTrans.CommandText = SQLTrans
                ComandoTrans.ExecuteNonQuery()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
        FormSesión.Conexión.Close()
    End Sub

End Class