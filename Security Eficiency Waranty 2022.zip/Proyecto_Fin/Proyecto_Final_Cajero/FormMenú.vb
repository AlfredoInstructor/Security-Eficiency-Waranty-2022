﻿Imports System.Runtime.InteropServices
Public Class FormMenú
#Region "Mover form"
    'Nos servirá para mover un formulario al pulsar en cualquier parte del mismo, incluso en cualquier control que tenga dicho formulario
    <DllImport("user32.DLL", EntryPoint:="ReleaseCapture")>
    Private Shared Sub ReleaseCapture()
    End Sub

    <DllImport("user32.DLL", EntryPoint:="SendMessage")>
    Private Shared Sub SendMessage(ByVal hWnd As System.IntPtr, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer)
    End Sub

    Private Sub PanelCabecera_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles PanelCabecera.MouseMove
        ReleaseCapture()
        SendMessage(Me.Handle, &H112&, &HF012&, 0)
    End Sub
#End Region


    'Para poder abrir un form en un panel
    Private Sub AbrirFormEnPanel(ByVal Formhijo As Object)
        If Me.PanelContenedor.Controls.Count > 0 Then Me.PanelContenedor.Controls.RemoveAt(0)
        Dim FormEstilo As Form = TryCast(Formhijo, Form)
        FormEstilo.TopLevel = False
        FormEstilo.FormBorderStyle = FormBorderStyle.None
        FormEstilo.Dock = DockStyle.Fill
        Me.PanelContenedor.Controls.Add(FormEstilo)
        Me.PanelContenedor.Tag = FormEstilo
        FormEstilo.Show()
    End Sub
    'TimerOcultar
    Private Sub tmOCULTAR_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles tmOCULTAR.Tick
        If PanelMenú.Width <= 60 Then
            Me.tmOCULTAR.Enabled = False
        Else
            Me.PanelMenú.Width = PanelMenú.Width - 20
        End If
    End Sub
    'TimerMostrar
    Private Sub tmMOSTRAR_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles tmMOSTRAR.Tick
        If PanelMenú.Width >= 220 Then
            Me.tmMOSTRAR.Enabled = False
        Else
            Me.PanelMenú.Width = PanelMenú.Width + 20
        End If
    End Sub
    'Botón del menú con efecto deslizable
    Private Sub btnMenu_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnMenu.Click
        If PanelMenú.Width = 220 Then
            tmOCULTAR.Enabled = True
        ElseIf PanelMenú.Width = 60 Then
            tmMOSTRAR.Enabled = True
        End If
    End Sub

    'Boton cerrar,abre el form anterior(Sesión)
    Private Sub btnCerrar_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnCerrar.Click
        Me.Hide()
        FormSesión.PinCuenta.Clear()
        FormSesión.PinCliente.Clear()
        FormSesión.Show()
    End Sub
    'Botón maximizar el form ménu
    Private Sub btnMaximizar_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnMaximizar.Click
        btnMaximizar.Visible = False
        btnRestaurar.Visible = True
        Me.WindowState = FormWindowState.Maximized

    End Sub
    'Botón restaurar,al maximizar el form menú se hace visible y se oculta el otro botón
    Private Sub btnRestaurar_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnRestaurar.Click
        Me.WindowState = FormWindowState.Normal
        btnRestaurar.Visible = False
        btnMaximizar.Visible = True
    End Sub
    'Botón minimizar el form menú
    Private Sub btnMinimizar_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnMinimizar.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    'Al presionar el botón Depósito se abrirá el FormDepósito
    Private Sub btnDeposito_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDeposito.Click
        AbrirFormEnPanel(New FormDepósito)
    End Sub

    'Al presionar el botón Reitro se abrirá el FormbtnRetiro
    Private Sub btnRetiro_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRetiro.Click
        AbrirFormEnPanel(New FormRetiro)
    End Sub
    'Al presionar el botón Saldo se abrirá el FormSaldo
    Private Sub btnSaldo_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSaldo.Click
        AbrirFormEnPanel(New FormSaldo)
    End Sub



End Class
