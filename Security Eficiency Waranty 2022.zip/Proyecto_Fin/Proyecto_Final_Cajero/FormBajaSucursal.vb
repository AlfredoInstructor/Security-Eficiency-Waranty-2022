﻿Imports MySql.Data.MySqlClient
Public Class FormBajaSucursal


    Private Sub btnBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
        Dim SqlBS As String = "DELETE FROM sucursal WHERE Cod_Sucursal='" & TextCod.Text & "'"
        Dim Comando As New MySqlCommand(SqlBS, FormSesión.Conexión)
        Try
            FormSesión.Conexión.Open()
            'Casos al momento de borrar o no un dato
            Dim Respuesta As Integer = MsgBox("Desea borrar los datos ingresados?", vbYesNo + vbExclamation, "Advertencia")
            Select Case Respuesta
                Case vbYes
                    Comando.ExecuteNonQuery()
                    MsgBox("Se han borrado los datos correctamente", vbExclamation, "Advertencia")
                Case vbNo
                    MsgBox("Se ha cancelado la operación", vbExclamation, "Advertencia")
            End Select
        Catch ex As Exception
            MsgBox("Error" & ex.Message)
        End Try
        FormSesión.Conexión.Close()
    End Sub



    Private Sub TextCod_TextKeypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextCod.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub


    Private Sub FormBajaSucursal_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
    'Buscar clave primaria
    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        Dim DTBuscarSucursal As New DataTable
        Dim SqlAC As String = "SELECT * FROM sucursal WHERE Cod_Sucursal = '" & TextCod.Text & "'"
        Dim SqlComandoBS = New MySqlCommand(SqlAC, FormSesión.Conexión)
        FormSesión.Conexión.Open()
        Dim LectorCuenta = New MySqlDataAdapter(SqlComandoBS)
        LectorCuenta.Fill(DTBuscarSucursal)

        If TextCod.Text = "" Then
            MsgBox("Ingrese la clave primaria", vbExclamation, "Advertencia")
        ElseIf DTBuscarSucursal.Rows.Count = 0 Then
            MsgBox("No existen los datos", vbExclamation, "Advertencia")
        Else
            MsgBox("Existe la Clave Primaria", vbExclamation, "Advertencia")
        End If
        FormSesión.Conexión.Close()
    End Sub
End Class