﻿Imports MySql.Data.MySqlClient
Public Class FormAltaCuenta
#Region "ComboBoxs que solo acepten letras"
    'Textbox Tipo de cuenta
    Private Sub ComboTipo_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ComboTipo.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If

    End Sub


    'TextBox Moneda 
    Private Sub ComboMoneda_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ComboMoneda.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
        ComboMoneda.Text = Trim(Replace(ComboMoneda.Text, " ", ""))
        ComboMoneda.Select(ComboMoneda.Text.Length, 0)
    End Sub
#End Region
#Region "TextBoxs que solo acepten Números"
    'TextboxPin que solo admite números y borrar
    Private Sub TextBoxPin_TextKeypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxPin.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub
    Private Sub TextBoxCli_TextKeypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxCli.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub
    Private Sub TextBoxSuc_TextKeypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxSuc.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub
#End Region

    Private Sub btnInsertar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsertar.Click
        'Er es una variable de Error que nos señala cuando se repite la misma clave primaria y finaliza la tarea
        Dim Er As Integer = 0
        Dim Comando As MySqlCommand = New MySqlCommand
        Comando.Connection = FormSesión.Conexión
        Try
            FormSesión.Conexión.Open()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Comando.CommandText = "SELECT * FROM cuenta WHERE Pin_Cuenta = '" & TextBoxPin.Text & "'"
        Dim Resultado As MySqlDataReader
        Resultado = Comando.ExecuteReader
        If Resultado.HasRows Then
            MsgBox("Ya existe la clave primaria ingresada", vbExclamation, "Advertencia")
            Er = 1
            Resultado.Close()
            FormSesión.Conexión.Close()
        ElseIf TextBoxPin.Text = "" Then
            MsgBox("Ingrese clave primaria", vbExclamation, "Advertencia")
            Resultado.Close()
            Er = 1
            FormSesión.Conexión.Close()
        ElseIf ComboMoneda.Text = "" Or ComboTipo.Text = "" Or TextBoxCli.Text = "" Or TextBoxSuc.Text = "" Or TextBoxSaldo.Text = "" Then
            MsgBox("Ingrese todos los registros correctamente", vbExclamation, "Advertencia")
            Resultado.Close()
            Er = 1
            FormSesión.Conexión.Close()
        End If
        FormSesión.Conexión.Close()
        'Continua con la función
        If Er = 0 Then
            Dim FechaCuentaAlta As String = FechaAltaCuenta.Value.ToString("yyyy-MM-dd")
            Dim SqlACLI As String = "INSERT INTO cuenta(Pin_Cuenta,Saldo,Tipo_Cuenta,Moneda,Fecha_Apertura,Codigo_Sucursal,Pin_Cli) VALUES('" & TextBoxPin.Text & "', '" & TextBoxSaldo.Text & "', '" & ComboTipo.Text & "','" & ComboMoneda.Text & "','" & FechaCuentaAlta & "', '" & TextBoxSuc.Text & "','" & TextBoxCli.Text & "')"
            Dim Command As New MySqlCommand(SqlACLI, FormSesión.Conexión)
            Try
                FormSesión.Conexión.Open()
                'Casos al momento de ingresar o no los datos
                Dim Respuesta As String = MsgBox("Desea ingresar los siguientes datos?", vbYesNo + vbExclamation, "Advertencia")
                Select Case Respuesta
                    Case vbYes
                        Command.ExecuteNonQuery()
                        MsgBox("Se han ingresado los datos correctamente", vbExclamation, "Advertencia")
                    Case vbNo
                        MsgBox("Se ha cancelado la operación", vbExclamation, "Advertencia")
                End Select
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            FormSesión.Conexión.Close()
        End If
    End Sub

    Private Sub AltaCuenta_Load(ByVal sender As System.Object, ByVal e As System.EventArgs)
    End Sub
    'Borra todo lo escrito en los campos de texto
    Private Sub btnBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
        Dim Respuesta As String = MsgBox("Desea borrar los datos ingresados?", vbYesNo + vbExclamation, "Advertencia")
        Select Case Respuesta
            Case vbYes
                MsgBox("Se han borrado los datos correctamente", vbExclamation, "Advertencia")
                ComboMoneda.Text = ""
                TextBoxPin.Text = ""
                TextBoxSaldo.Text = ""
                ComboTipo.Text = ""
                TextBoxSuc.Text = ""
                TextBoxCli.Text = ""
            Case vbNo
                MsgBox("Se ha cancelado la operación", vbExclamation, "Advertencia")
        End Select
    End Sub

    Private Sub FormAltaCuenta_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
    'Buscar si existe una clave primaria
    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        Dim DTCuenta As New DataTable
        Dim SqlAC As String = "SELECT * FROM cuenta WHERE Pin_Cuenta = '" & TextBoxPin.Text & "'"
        Dim SqlComandoCuenta = New MySqlCommand(SqlAC, FormSesión.Conexión)
        FormSesión.Conexión.Open()
        Dim LectorCuenta = New MySqlDataAdapter(SqlComandoCuenta)
        LectorCuenta.Fill(DTCuenta)

        If TextBoxPin.Text = "" Then
            MsgBox("Ingrese la clave primaria", vbExclamation, "Advertencia")
        ElseIf DTCuenta.Rows.Count = 0 Then
            MsgBox("No existen los datos", vbExclamation, "Advertencia")
        Else
            MsgBox("Existe la Clave Primaria", vbExclamation, "Advertencia")
            TextBoxPin.Text = DTCuenta.Rows(0)("Pin_Cuenta").ToString()
            TextBoxSaldo.Text = DTCuenta.Rows(0)("Saldo").ToString()
            ComboTipo.Text = DTCuenta.Rows(0)("Tipo_Cuenta").ToString()
            ComboMoneda.Text = DTCuenta.Rows(0)("Moneda").ToString()
            FechaAltaCuenta.Value = DTCuenta.Rows(0)("Fecha_Apertura").ToString()
            TextBoxSuc.Text = DTCuenta.Rows(0)("Codigo_Sucursal").ToString()
            TextBoxCli.Text = DTCuenta.Rows(0)("Pin_Cli").ToString()
        End If
        FormSesión.Conexión.Close()
    End Sub


End Class
