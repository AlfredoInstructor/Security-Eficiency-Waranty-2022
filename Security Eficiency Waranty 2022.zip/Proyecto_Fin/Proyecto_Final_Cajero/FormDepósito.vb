﻿Imports MySql.Data.MySqlClient
Public Class FormDepósito

    'Variable de tipo de transacción
    Dim TipoD As String = "Depósito"
    'Textbox que solo admite números y borrar
    Private Sub TextBoxDepósito_TextKeypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxDeposito.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub
    'Er es una variable de Error que nos señala cuando se repite la misma clave primaria y finaliza la tarea
    Dim Er As Integer = 0
    'Variable para llamar los datos escritos en el TextBox PinCuenta del form Lógin
    Dim PinDepósito As String = FormSesión.PinCuenta.Text
    'Botón de Depósito para moder depositar(Actualizar) nuestro saldo
    Private Sub btnDepósito_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDepósito.Click
        'Variable para la fecha de transacción
        Dim FechaD As String = DateTimeD.Value.ToString("yyyy-MM-dd HH:mm:ss")
        'Consultar Saldo
        Dim DTSD As New DataTable
        Dim SqlSD As String = "SELECT saldo,Moneda FROM cuenta WHERE Pin_Cuenta = '" & PinDepósito & "'"
        Dim SqlComandoSD = New MySqlCommand(SqlSD, FormSesión.Conexión)
        Dim LectorSR = New MySqlDataAdapter(SqlComandoSD)
        Try
            FormSesión.Conexión.Open()
            LectorSR.Fill(DTSD)
            LabelSaldo.Text = DTSD.Rows(0)("Saldo").ToString()
            LabelMoneda.Text = DTSD.Rows(0)("Moneda").ToString()
            FormSesión.Conexión.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Dim SqlDepósito As String = "UPDATE cuenta SET Saldo = Saldo + '" & TextBoxDeposito.Text & "' WHERE Pin_Cuenta = '" & PinDepósito & "'"
        Dim ComandoDepósito As New MySqlCommand
        ComandoDepósito = New MySqlCommand(SqlDepósito, FormSesión.Conexión)
        Try
            FormSesión.Conexión.Open()
            ComandoDepósito.CommandText = SqlDepósito
            ComandoDepósito.Connection = FormSesión.Conexión
            If TextBoxDeposito.Text = "" Then
                MsgBox("Ingrese un valor", vbInformation, "Depósito")
                ProgresoDepósito.Value = 0
                Er = 1
            ElseIf Val(TextBoxDeposito.Text) > 500000 Then
                MsgBox("El saldo a retirar no puede ser mayor a 5000000", vbExclamation, "Advertencia")
            ElseIf Val(TextBoxDeposito.Text) > 500000 Then
                MsgBox("El saldo a retirar no puede ser mayor a 5000000", vbExclamation, "Advertencia")
            Else
                ComandoDepósito.ExecuteNonQuery()
                ProgresoDepósito.Value = 100
                MsgBox("Su dinero se ha depositado con exito", vbInformation, "Depósito")
                ProgresoDepósito.Value = 0

            End If
        Catch ex As Exception
            ProgresoDepósito.Value = 50
            MsgBox(ex.Message)
        End Try
        FormSesión.Conexión.Close()
        If Er = 0 Then
            Try
                FormSesión.Conexión.Open()
                Dim SQLTrans As String = "INSERT INTO transaccion(Monto,Moneda,Fecha_Transaccion,Tipo,Pin_Cuenta) VALUES('" & TextBoxDeposito.Text & "','" & LabelMoneda.Text & "','" & FechaD & "', '" & TipoD & "', '" & PinDepósito & "')"
                Dim ComandoTrans As New MySqlCommand(SQLTrans, FormSesión.Conexión)
                ComandoTrans.Connection = FormSesión.Conexión
                ComandoTrans.CommandText = SQLTrans
                ComandoTrans.ExecuteNonQuery()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
        FormSesión.Conexión.Close()
    End Sub

    Private Sub FormDepósito_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class