﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormDepósito
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnDepósito = New System.Windows.Forms.Button()
        Me.TextBoxDeposito = New System.Windows.Forms.TextBox()
        Me.LabelDepósito = New System.Windows.Forms.Label()
        Me.ProgresoDepósito = New System.Windows.Forms.ProgressBar()
        Me.LabelMoneda = New System.Windows.Forms.Label()
        Me.LabelSaldo = New System.Windows.Forms.Label()
        Me.DateTimeD = New System.Windows.Forms.DateTimePicker()
        Me.SuspendLayout()
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.LightGray
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel3.Location = New System.Drawing.Point(0, 460)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(930, 100)
        Me.Panel3.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Gray
        Me.Label1.Location = New System.Drawing.Point(176, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(404, 55)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Ingresar Depósito"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'btnDepósito
        '
        Me.btnDepósito.BackColor = System.Drawing.Color.DarkSlateGray
        Me.btnDepósito.FlatAppearance.BorderSize = 0
        Me.btnDepósito.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDepósito.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDepósito.ForeColor = System.Drawing.Color.LightGray
        Me.btnDepósito.Location = New System.Drawing.Point(309, 280)
        Me.btnDepósito.Name = "btnDepósito"
        Me.btnDepósito.Size = New System.Drawing.Size(145, 54)
        Me.btnDepósito.TabIndex = 33
        Me.btnDepósito.Text = "Depositar"
        Me.btnDepósito.UseVisualStyleBackColor = False
        '
        'TextBoxDeposito
        '
        Me.TextBoxDeposito.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxDeposito.Location = New System.Drawing.Point(293, 202)
        Me.TextBoxDeposito.Name = "TextBoxDeposito"
        Me.TextBoxDeposito.Size = New System.Drawing.Size(183, 26)
        Me.TextBoxDeposito.TabIndex = 35
        '
        'LabelDepósito
        '
        Me.LabelDepósito.AutoSize = True
        Me.LabelDepósito.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelDepósito.Location = New System.Drawing.Point(260, 153)
        Me.LabelDepósito.Name = "LabelDepósito"
        Me.LabelDepósito.Size = New System.Drawing.Size(257, 25)
        Me.LabelDepósito.TabIndex = 36
        Me.LabelDepósito.Text = "Ingrese cantidad a depositar"
        '
        'ProgresoDepósito
        '
        Me.ProgresoDepósito.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ProgresoDepósito.Cursor = System.Windows.Forms.Cursors.Default
        Me.ProgresoDepósito.ForeColor = System.Drawing.Color.Black
        Me.ProgresoDepósito.Location = New System.Drawing.Point(319, 251)
        Me.ProgresoDepósito.Name = "ProgresoDepósito"
        Me.ProgresoDepósito.Size = New System.Drawing.Size(125, 23)
        Me.ProgresoDepósito.TabIndex = 37
        '
        'LabelMoneda
        '
        Me.LabelMoneda.AutoSize = True
        Me.LabelMoneda.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMoneda.Location = New System.Drawing.Point(38, 188)
        Me.LabelMoneda.Name = "LabelMoneda"
        Me.LabelMoneda.Size = New System.Drawing.Size(0, 37)
        Me.LabelMoneda.TabIndex = 43
        '
        'LabelSaldo
        '
        Me.LabelSaldo.AutoSize = True
        Me.LabelSaldo.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSaldo.Location = New System.Drawing.Point(38, 153)
        Me.LabelSaldo.Name = "LabelSaldo"
        Me.LabelSaldo.Size = New System.Drawing.Size(0, 37)
        Me.LabelSaldo.TabIndex = 42
        '
        'DateTimeD
        '
        Me.DateTimeD.Location = New System.Drawing.Point(596, 202)
        Me.DateTimeD.Name = "DateTimeD"
        Me.DateTimeD.Size = New System.Drawing.Size(200, 20)
        Me.DateTimeD.TabIndex = 44
        Me.DateTimeD.Visible = False
        '
        'FormDepósito
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(930, 560)
        Me.Controls.Add(Me.DateTimeD)
        Me.Controls.Add(Me.LabelMoneda)
        Me.Controls.Add(Me.LabelSaldo)
        Me.Controls.Add(Me.ProgresoDepósito)
        Me.Controls.Add(Me.LabelDepósito)
        Me.Controls.Add(Me.TextBoxDeposito)
        Me.Controls.Add(Me.btnDepósito)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel3)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "FormDepósito"
        Me.Text = "FormDepósito"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnDepósito As System.Windows.Forms.Button
    Friend WithEvents TextBoxDeposito As System.Windows.Forms.TextBox
    Friend WithEvents LabelDepósito As System.Windows.Forms.Label
    Friend WithEvents ProgresoDepósito As System.Windows.Forms.ProgressBar
    Friend WithEvents LabelMoneda As System.Windows.Forms.Label
    Friend WithEvents LabelSaldo As System.Windows.Forms.Label
    Friend WithEvents DateTimeD As System.Windows.Forms.DateTimePicker
End Class
