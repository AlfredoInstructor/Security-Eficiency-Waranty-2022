﻿Imports MySql.Data.MySqlClient
Public Class FormModificarCuenta
    'Modificar registros
    Private Sub btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModificar.Click
        'Er es una variable de Error que nos señala cuando se repite la misma clave primaria y finaliza la tarea
        Dim Er As Integer = 0
        Dim FechaModificar As String = FechaModificarCuenta.Value.ToString("yyyy-MM-dd")
        Dim SqlMC As String = "UPDATE cuenta SET Saldo = '" & TextBoxSaldo.Text & "', Tipo_Cuenta = '" & ComboTipo.Text & "', Moneda = '" & ComboMoneda.Text & "', Fecha_Apertura = '" & FechaModificar & "',Codigo_Sucursal = '" & TextBoxSuc.Text & "',Pin_Cli = '" & TextBoxCli.Text & "' WHERE Pin_Cuenta = " & TextBoxPin.Text & ""
        Dim ComandoModCuenta As New MySqlCommand(SqlMC, FormSesión.Conexión)
        FormSesión.Conexión.Open()
        If TextBoxPin.Text = "" Then
            MsgBox("Ingrese clave primaria", vbExclamation, "Advertencia")
            Er = 1
            FormSesión.Conexión.Close()
        ElseIf ComboMoneda.Text = "" Or ComboTipo.Text = "" Or TextBoxCli.Text = "" Or TextBoxSuc.Text = "" Or TextBoxSaldo.Text = "" Then
            MsgBox("Ingrese todos los registros correctamente", vbExclamation, "Advertencia")
            Er = 1
            FormSesión.Conexión.Close()
        End If
        FormSesión.Conexión.Close()
        'Casos al momento de ingresar o no los datos
        If Er = 0 Then
            Try
                FormSesión.Conexión.Open()
                Dim Respuesta As Integer = MsgBox("Desea modificar los siguientes datos?", vbYesNo + vbExclamation, "Advertencia")
                Select Case Respuesta
                    Case vbYes
                        MsgBox("Se han modificado los datos correctamente", vbExclamation, "Advertencia")
                        ComandoModCuenta.ExecuteNonQuery()
                    Case vbNo
                        MsgBox("Se ha cancelado la operación", vbExclamation, "Advertencia")
                End Select
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            FormSesión.Conexión.Close()
        End If
    End Sub

    Private Sub btnBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
        Dim Respuesta As Integer = MsgBox("Desea borrar los datos ingresados?", vbYesNo + vbExclamation, "Advertencia")
        Select Case Respuesta
            Case vbYes
                MsgBox("Se han borrado los datos correctamente", vbExclamation, "Advertencia")
                ComboMoneda.Text = ""
                TextBoxPin.Text = ""
                TextBoxSaldo.Text = ""
                ComboTipo.Text = ""
                TextBoxSuc.Text = ""
                TextBoxCli.Text = ""
            Case vbNo
                MsgBox("Se ha cancelado la operación", vbExclamation, "Advertencia")
        End Select
    End Sub

    Private Sub FormModificarCuenta_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
    'Buscar la clave primaria
    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        Dim DTModificarCuenta As New DataTable
        Dim SqlMC As String = "SELECT * FROM cuenta WHERE Pin_Cuenta = '" & TextBoxPin.Text & "'"
        Dim SqlComandoMCuenta = New MySqlCommand(SqlMC, FormSesión.Conexión)
        FormSesión.Conexión.Open()
        Dim LectorCuenta = New MySqlDataAdapter(SqlComandoMCuenta)
        LectorCuenta.Fill(DTModificarCuenta)

        If TextBoxPin.Text = "" Then
            MsgBox("Ingrese la clave primaria", vbExclamation, "Advertencia")
        ElseIf DTModificarCuenta.Rows.Count = 0 Then
            MsgBox("No existen los datos", vbExclamation, "Advertencia")
        Else
            MsgBox("Existe la Clave Primaria", vbExclamation, "Advertencia")
            TextBoxPin.Text = DTModificarCuenta.Rows(0)("Pin_Cuenta").ToString()
            TextBoxSaldo.Text = DTModificarCuenta.Rows(0)("Saldo").ToString()
            ComboTipo.Text = DTModificarCuenta.Rows(0)("Tipo_Cuenta").ToString()
            ComboMoneda.Text = DTModificarCuenta.Rows(0)("Moneda").ToString()
            FechaModificarCuenta.Value = DTModificarCuenta.Rows(0)("Fecha_Apertura").ToString()
            TextBoxSuc.Text = DTModificarCuenta.Rows(0)("Codigo_Sucursal").ToString()
            TextBoxCli.Text = DTModificarCuenta.Rows(0)("Pin_Cli").ToString()
        End If
        FormSesión.Conexión.Close()
    End Sub
End Class
