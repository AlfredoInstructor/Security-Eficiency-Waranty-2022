﻿Imports MySql.Data.MySqlClient
Public Class FormModificarCliente

    Private Sub btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModificar.Click
        'Er es una variable de Error que nos señala cuando se repite la misma clave primaria
        Dim Er As Integer = 0
        Dim FechaCliente As String = FechaModificarCliente.Value.ToString("yyyy-MM-dd")
        Dim SqlMCLI As String = "UPDATE cliente SET Nombre = '" & TextBoxNom.Text & "', Domicilio = '" & TextBoxDom.Text & "', Nacionalidad = '" & TextBoxNac.Text & "', Fecha_Nacimiento = '" & FechaCliente & "', Estado_Civil = '" & ComboCivil.Text & "', Sexo = '" & ComboSexo.Text & "' WHERE Pin_Cliente = " & TextBoxPin.Text & ""
        Dim ComandoModCliente As New MySqlCommand(SqlMCLI, FormSesión.Conexión)
        FormSesión.Conexión.Open()
        If TextBoxPin.Text = "" Then
            MsgBox("Ingrese clave primaria", vbExclamation, "Advertencia")
            Er = 1
            FormSesión.Conexión.Close()
        ElseIf TextBoxDom.Text = "" Or TextBoxNac.Text = "" Or TextBoxNom.Text = "" Or ComboCivil.Text = "" Or ComboSexo.Text = "" Then
            MsgBox("Ingrese todos los registros correctamente", vbExclamation, "Advertencia")
            Er = 1
            FormSesión.Conexión.Close()
        End If
        FormSesión.Conexión.Close()
        'Si Er es 0,entonces se ejecuta todo el comando
        If Er = 0 Then
            Try
                FormSesión.Conexión.Open()
                'Casos al momento de ingresar o no los datos
                Dim Respuesta As Integer = MsgBox("Desea ingresar los siguientes datos?", vbYesNo + vbExclamation, "Advertencia")
                Select Case Respuesta
                    Case vbYes
                        MsgBox("Se han ingresado los datos correctamente", vbExclamation, "Advertencia")
                        ComandoModCliente.ExecuteNonQuery()
                    Case vbNo
                        MsgBox("Se ha cancelado la operación", vbExclamation, "Advertencia")
                End Select
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            FormSesión.Conexión.Close()
        End If
    End Sub


    'Borrar datos ingresados
    Private Sub btnBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
        Dim Respuesta As Integer = MsgBox("Desea borrar los datos ingresados?", vbYesNo + vbExclamation, "Advertencia")
        Select Case Respuesta
            Case vbYes
                MsgBox("Se han borrado los datos correctamente", vbExclamation, "Advertencia")
                TextBoxPin.Text = ""
                TextBoxNom.Text = ""
                TextBoxDom.Text = ""
                TextBoxNac.Text = ""
                ComboCivil.Text = ""
                ComboSexo.Text = ""
            Case vbNo
                MsgBox("Se ha cancelado la operación", vbExclamation, "Advertencia")
        End Select
    End Sub

    'Buscar registros de la clave primaria
    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        Dim DTModificarCliente As New DataTable
        Dim SqlMCLI As String = "SELECT * FROM cliente WHERE Pin_Cliente = '" & TextBoxPin.Text & "'"
        Dim SqlComandoMCliente = New MySqlCommand(SqlMCLI, FormSesión.Conexión)
        Dim LectorCliente = New MySqlDataAdapter(SqlComandoMCliente)
        LectorCliente.Fill(DTModificarCliente)
        Dim Pin_Cliente As Integer = Val(TextBoxPin.Text)
        FormSesión.Conexión.Open()
        If DTModificarCliente.Rows.Count = 0 Then
            MsgBox("No existen los datos", vbExclamation, "Advertencia")
        Else
            MsgBox("Existe la Clave Primaria", vbExclamation, "Advertencia")
            TextBoxPin.Text = DTModificarCliente.Rows(0)("Pin_Cliente").ToString()
            TextBoxNom.Text = DTModificarCliente.Rows(0)("Nombre").ToString()
            TextBoxDom.Text = DTModificarCliente.Rows(0)("Domicilio").ToString()
            TextBoxNac.Text = DTModificarCliente.Rows(0)("Nacionalidad").ToString()
            FechaModificarCliente.Value = DTModificarCliente.Rows(0)("Fecha_Nacimiento").ToString()
            ComboCivil.Text = DTModificarCliente.Rows(0)("Estado_Civil").ToString()
            ComboSexo.Text = DTModificarCliente.Rows(0)("Sexo").ToString()
        End If
        FormSesión.Conexión.Close()
    End Sub

    Private Sub FormModificarCliente_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class