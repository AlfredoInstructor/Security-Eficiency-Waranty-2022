﻿
Namespace DAO
    Class Recordset

        Function Fields(ByVal p1 As Integer) As Object
            Throw New NotImplementedException
        End Function

    End Class
End Namespace
