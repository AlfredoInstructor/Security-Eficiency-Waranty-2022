﻿Imports System.Runtime.InteropServices
Imports MySql.Data.MySqlClient
Public Class FormSesión
    Public Conexión As MySqlConnection = New MySqlConnection
#Region "Solo Números"
    'Textbox que solo admite números y borrar
    Private Sub PinCuenta_TextKeypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles PinCuenta.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub
    'Textbox que solo admite números y borrar
    Private Sub PinCliente_TextKeypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles PinCliente.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub
#End Region
#Region "Personalizar Controles"


    Private Sub CustomizeComponents()
        'PinCuenta
        PinCuenta.AutoSize = False
        PinCuenta.Size = New Size(350, 30)
        'PinCliente
        PinCliente.AutoSize = False
        PinCliente.Size = New Size(350, 30)
    End Sub
    'Personalizar botón de Ingresar
    Private Sub BotonLogin_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles BotonLogin.Paint
        Dim BotonTrayectoria As Drawing2D.GraphicsPath = New Drawing2D.GraphicsPath()
        Dim Rectángulo As Rectangle = BotonLogin.ClientRectangle
        Rectángulo.Inflate(0, 30)
        BotonTrayectoria.AddEllipse(Rectángulo)
        BotonLogin.Region = New Region(BotonTrayectoria)
    End Sub

#End Region
#Region "Cerrar y Minimizar Formulario"
    'Botón cerrar
    Private Sub BotonCerrar_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BotonCerrar.Click
        Application.Exit()
    End Sub
    'Botón Minimizar
    Private Sub btnMinimize_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnMinimize.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub
#End Region
#Region "Arrastrar/ mover Formulario"

    <DllImport("user32.DLL", EntryPoint:="ReleaseCapture")>
    Private Shared Sub ReleaseCapture()
    End Sub
    <DllImport("user32.DLL", EntryPoint:="SendMessage")>
    Private Shared Sub SendMessage(ByVal hWnd As IntPtr, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer)
    End Sub

    Private Sub BarraTítulo_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles BarraTítulo.MouseDown
        ReleaseCapture()
        SendMessage(Me.Handle, &H112&, &HF012&, 0)
    End Sub

    Private Sub Form1_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseDown
        ReleaseCapture()
        SendMessage(Me.Handle, &H112&, &HF012&, 0)
    End Sub

#End Region

    Private Sub FormSesión_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        CustomizeComponents()
    End Sub

    'Abrir el form menú o mantenimiento con el login
    Private Sub BotonLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BotonLogin.Click
        Dim Pin_Cuenta As String = PinCuenta.Text
        Dim Pin_Cliente As String = PinCliente.Text
        Dim ComandoLogin As MySqlCommand = New MySqlCommand
        ComandoLogin.Connection = Conexión
        Try
            Conexión.ConnectionString() = "server=localhost;port=3306;userid=root;password=1914;database=sew;"
            Conexión.Open()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        ComandoLogin.CommandText = "SELECT * FROM cuenta WHERE Pin_Cuenta='" & Pin_Cuenta & "' AND Pin_Cli = '" & Pin_Cliente & "'"
        Dim Respuesta As MySqlDataReader
        Respuesta = ComandoLogin.ExecuteReader
        If Respuesta.HasRows Then
            Me.Hide()
            FormMenú.Show()
            Respuesta.Close()
        ElseIf PinCuenta.Text = "" And PinCliente.Text = "" Then
            MsgBox("Ingrese sus datos", vbExclamation, "Advertencia")
        ElseIf PinCuenta.Text = "8798010101" And PinCliente.Text = "2019" Then
            Me.Hide()
            FormMantenimiento.Show()
            Respuesta.Close()
        Else
            MsgBox("Datos Incorrectos", vbExclamation, "Advertencia")
            Respuesta.Close()
        End If
        Conexión.Close()
    End Sub

    Private Sub PinCuenta_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PinCuenta.TextChanged

    End Sub
End Class
